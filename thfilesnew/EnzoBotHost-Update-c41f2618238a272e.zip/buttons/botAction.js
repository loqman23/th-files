const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Bot = require('../database/models/Bot');
const fs = require('fs-extra');
const path = require('path');
const { fork } = require('child_process');
const CryptoJS = require('crypto-js');

module.exports = {
  customId: 'botAction',
  
  async execute(interaction, client) {
    try {
      await interaction.deferReply({ ephemeral: true });
      
      // Parse customId to get action and botName
      const [_, action, botName] = interaction.customId.split(':');
      
      // Get bot from database
      const bot = await Bot.findOne({ name: botName, owner: interaction.user.id });
      
      if (!bot) {
        return interaction.editReply({
          content: 'لم يتم العثور على البوت. ربما تم حذفه.',
          ephemeral: true
        });
      }
      
      // Check if user is the bot owner or an admin
      const isOwner = bot.owner === interaction.user.id;
      const isAdmin = interaction.member.roles.cache.has(process.env.ADMIN_ROLE_ID);
      
      if (!isOwner && !isAdmin) {
        return interaction.editReply({
          content: 'ليس لديك صلاحية للتحكم بهذا البوت.',
          ephemeral: true
        });
      }
      
      // Handle different actions
      switch (action) {
        case 'start':
          await startBot(interaction, client, bot);
          break;
        case 'stop':
          await stopBot(interaction, client, bot);
          break;
        case 'restart':
          await restartBot(interaction, client, bot);
          break;
        case 'delete':
          await deleteBot(interaction, client, bot);
          break;
        case 'logs':
          await viewLogs(interaction, bot);
          break;
        default:
          await interaction.editReply({
            content: 'إجراء غير صالح.',
            ephemeral: true
          });
      }
    } catch (error) {
      console.error(`Error handling bot action (${interaction.customId}):`, error);
      await interaction.editReply({
        content: 'حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.',
        ephemeral: true
      });
    }
  }
};

// Function to start a bot
async function startBot(interaction, client, bot) {
  try {
    // Check if bot is already running
    if (client.botProcesses.has(bot.name)) {
      return interaction.editReply({
        content: `البوت ${bot.name} قيد التشغيل بالفعل.`,
        ephemeral: true
      });
    }
    
    // Check if bot directory exists
    if (!fs.existsSync(bot.path)) {
      return interaction.editReply({
        content: `لم يتم العثور على مجلد البوت. ربما تم حذف البوت.`,
        ephemeral: true
      });
    }
    
    // Create logs directory if it doesn't exist
    const logsDir = path.join(__dirname, '..', 'logs');
    await fs.ensureDir(logsDir);
    
    // Get or create log file path
    let logPath;
    if (bot.logPath) {
      // If it's a relative path, make it absolute
      if (!path.isAbsolute(bot.logPath)) {
        logPath = path.join(__dirname, '..', bot.logPath);
      } else {
        logPath = bot.logPath;
      }
    } else {
      // Create a default path and update the database
      logPath = path.join(logsDir, `${bot.name}.log`);
      bot.logPath = path.relative(path.join(__dirname, '..'), logPath);
      await bot.save();
    }
    
    // Append to log file
    await fs.appendFile(
      logPath,
      `\n[${new Date().toISOString()}] Bot started by ${interaction.user.tag}\n`
    );
    
    // Start the bot process
    const botProcess = fork(path.join(bot.path, 'index.js'), [], {
      cwd: bot.path,
      stdio: ['ignore', 'pipe', 'pipe', 'ipc']
    });
    
    // Handle stdout and stderr
    botProcess.stdout.on('data', (data) => {
      fs.appendFileSync(logPath, `[STDOUT] ${data.toString()}`);
    });
    
    botProcess.stderr.on('data', (data) => {
      fs.appendFileSync(logPath, `[STDERR] ${data.toString()}`);
    });
    
    // Handle process exit
    botProcess.on('exit', (code, signal) => {
      const exitMessage = `Bot exited with code ${code} and signal ${signal} at ${new Date().toISOString()}\n`;
      fs.appendFileSync(logPath, exitMessage);
      
      client.botProcesses.delete(bot.name);
      if (client.botStats) {
        client.botStats.botsRunning--;
        client.botStats.crashedBots++;
      }
      
      // Update bot status in database
      Bot.findOneAndUpdate(
        { botId: bot.botId },
        { status: 'crashed' },
        { new: true }
      ).catch(err => console.error(`Error updating bot status: ${err}`));
      
      // Notify the user if this wasn't a manual stop
      if (code !== 0) {
        interaction.user.createDM().then(dmChannel => {
          dmChannel.send({
            embeds: [
              new EmbedBuilder()
                .setTitle('🔴 Bot Crashed')
                .setDescription(`Your bot **${bot.name}** has crashed.`)
                .addFields(
                  { name: 'Exit Code', value: code ? code.toString() : 'Unknown', inline: true },
                  { name: 'Signal', value: signal || 'None', inline: true }
                )
                .setColor('#e74c3c')
                .setTimestamp()
            ]
          });
        }).catch(err => console.error('Failed to send crash DM:', err));
      }
    });
    
    // Store bot info
    const botInfo = {
      process: botProcess,
      owner: bot.owner,
      startTime: Date.now()
    };
    
    client.botProcesses.set(bot.name, botInfo);
    client.botStats.botsRunning++;
    
    // Update unique users count
    const uniqueUsers = new Set([...client.botProcesses.values()].map(b => b.owner));
    client.botStats.usersHosting = uniqueUsers.size;
    
    // Update bot status in database
    await Bot.findOneAndUpdate(
      { botId: bot.botId },
      { status: 'running', startTime: Date.now() },
      { new: true }
    );
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ تم تشغيل البوت')
          .setDescription(`تم تشغيل البوت **${bot.name}** بنجاح.`)
          .setColor('#2ecc71')
          .setTimestamp()
      ],
      ephemeral: true
    });
  } catch (error) {
    console.error(`Error starting bot ${bot.botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء تشغيل البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to stop a bot
async function stopBot(interaction, client, bot) {
  try {
    // Check if bot is running
    const runningBot = client.botProcesses.get(bot.name);
    
    if (!runningBot) {
      return interaction.editReply({
        content: `البوت ${bot.name} غير قيد التشغيل حاليًا.`,
        ephemeral: true
      });
    }
    
    // Get log file path
    let logPath;
    if (bot.logPath) {
      // If it's a relative path, make it absolute
      if (!path.isAbsolute(bot.logPath)) {
        logPath = path.join(__dirname, '..', bot.logPath);
      } else {
        logPath = bot.logPath;
      }
    } else {
      const logsDir = path.join(__dirname, '..', 'logs');
      logPath = path.join(logsDir, `${bot.name}.log`);
    }
    
    // Append to log file if it exists
    try {
      if (fs.existsSync(logPath)) {
        fs.appendFileSync(
          logPath,
          `\n[${new Date().toISOString()}] Bot stopped by ${interaction.user.tag}\n`
        );
      }
    } catch (logError) {
      console.error(`Error writing to log file: ${logError.message}`);
    }
    
    // Kill the process
    runningBot.process.kill();
    
    // Remove from running bots
    client.botProcesses.delete(bot.name);
    
    // Update bot stats if they exist
    if (client.botStats) {
      client.botStats.botsRunning--;
      
      // Update unique users count
      const uniqueUsers = new Set([...client.botProcesses.values()].map(b => b.owner));
      client.botStats.usersHosting = uniqueUsers.size;
    }
    
    // Update bot status in database
    await Bot.findOneAndUpdate(
      { botId: bot.botId },
      { status: 'stopped' },
      { new: true }
    );
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('⏹️ تم إيقاف البوت')
          .setDescription(`تم إيقاف البوت **${bot.name}** بنجاح.`)
          .setColor('#e74c3c')
          .setTimestamp()
      ],
      ephemeral: true
    });
  } catch (error) {
    console.error(`Error stopping bot ${bot.botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء إيقاف البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to restart a bot
async function restartBot(interaction, client, bot) {
  try {
    // Check if bot is running
    const runningBot = client.botProcesses.get(bot.name);
    if (!runningBot) {
      return interaction.editReply({
        content: `البوت ${bot.name} غير قيد التشغيل حاليًا. استخدم زر التشغيل بدلاً من ذلك.`,
        ephemeral: true
      });
    }
    
    // Create logs directory if it doesn't exist
    const logsDir = path.join(__dirname, '..', 'logs');
    await fs.ensureDir(logsDir);
    
    // Create log file path
    const logPath = path.join(logsDir, `${bot.name}.log`);
    
    // Append to log file
    await fs.appendFile(
      logPath,
      `\n[${new Date().toISOString()}] Bot restarted by ${interaction.user.tag}\n`
    );
    
    // Kill the process
    runningBot.process.kill();
    
    // Remove from running bots
    client.runningBots.delete(bot.botId);
    
    // Increment restart counter
    client.botStats.totalRestarts++;
    
    // Update bot in database
    await Bot.findOneAndUpdate(
      { botId: bot.botId },
      { 
        $inc: { restarts: 1 },
        lastRestart: Date.now()
      },
      { new: true }
    );
    
    // Start the bot again
    await startBot(interaction, client, bot);
  } catch (error) {
    console.error(`Error restarting bot ${bot.botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء إعادة تشغيل البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to delete a bot
async function deleteBot(interaction, client, bot) {
  try {
    // First check if bot is running and stop it
    const runningBot = client.botProcesses.get(bot.name);
    if (runningBot && runningBot.process) {
      console.log(`Stopping running bot: ${bot.name} before deletion`);
      runningBot.process.kill('SIGTERM');
      client.botProcesses.delete(bot.name);
      
      // Wait a moment for the process to clean up
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update bot stats if they exist
      if (client.botStats) {
        client.botStats.botsRunning--;
        
        // Update unique users count
        const uniqueUsers = new Set([...client.botProcesses.values()].map(b => b.owner));
        client.botStats.usersHosting = uniqueUsers.size;
      }
    }
    
    // Delete bot files using the safe delete helper
    const { safeDeleteBotDirectory } = require('../index');
    if (fs.existsSync(bot.path)) {
      const deleted = await safeDeleteBotDirectory(bot.path);
      if (!deleted) {
        console.warn(`Could not delete bot directory: ${bot.path}. It will be deleted on next server restart.`);
      }
    }
    
    // Delete log file
    if (fs.existsSync(bot.logPath)) {
      try {
        fs.unlinkSync(bot.logPath);
      } catch (logError) {
        console.error(`Error deleting log file: ${logError.message}`);
      }
    }
    
    // Delete bot from database
    await Bot.findOneAndDelete({ botId: bot.botId });
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle('🗑️ تم حذف البوت')
          .setDescription(`تم حذف البوت **${bot.name}** بنجاح.`)
          .setColor('#e74c3c')
          .setTimestamp()
      ],
      ephemeral: true
    });
  } catch (error) {
    console.error(`Error deleting bot ${bot.botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء حذف البوت: ${error.message}`,
      ephemeral: true
    });
  }
}

// Function to view bot logs
async function viewLogs(interaction, bot) {
  try {
    // Create log file path
    const logsDir = path.join(__dirname, '..', 'logs');
    let logPath;
    
    // Check if bot has a log path in the database
    if (bot.logPath) {
      // If it's a relative path, make it absolute
      if (!path.isAbsolute(bot.logPath)) {
        logPath = path.join(__dirname, '..', bot.logPath);
      } else {
        logPath = bot.logPath;
      }
    } else {
      // Fallback to a default path
      logPath = path.join(logsDir, `${bot.name}.log`);
    }
    
    // Check if log file exists
    if (!await fs.pathExists(logPath)) {
      return interaction.editReply({
        content: `لم يتم العثور على ملف السجل للبوت ${bot.name}.`,
        ephemeral: true
      });
    }
    
    // Read log file
    let logContent = await fs.readFile(logPath, 'utf8');
    
    // Trim log content if it's too long
    if (logContent.length > 1900) {
      logContent = logContent.substring(logContent.length - 1900);
      logContent = '... (truncated) ...\n' + logContent;
    }
    
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle(`📄 سجلات البوت ${bot.name}`)
          .setDescription(`\`\`\`\n${logContent || 'لا توجد سجلات متاحة.'}\n\`\`\``)
          .setColor('#3498db')
          .setFooter({ text: `معرف البوت: ${bot.botId}` })
          .setTimestamp()
      ],
      components: [
        new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`botAction:logs:${bot.botId}`)
              .setLabel('🔄 تحديث السجلات')
              .setStyle(ButtonStyle.Secondary)
          )
      ],
      ephemeral: true
    });
  } catch (error) {
    console.error(`Error viewing logs for bot ${bot.botId}:`, error);
    await interaction.editReply({
      content: `حدث خطأ أثناء عرض السجلات: ${error.message}`,
      ephemeral: true
    });
  }
}
