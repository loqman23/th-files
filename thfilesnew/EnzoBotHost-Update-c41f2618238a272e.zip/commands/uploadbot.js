const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const User = require('../database/models/User');
const Bot = require('../database/models/Bot');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uploadbot')
    .setDescription('Upload a new Discord bot to the host'),
  
  async execute(interaction, client) {
    try {
      // Check if user is banned
      const user = await User.findOne({ userId: interaction.user.id });
      if (user && user.isBanned) {
        return interaction.reply({
          content: `You are banned from using this service. Reason: ${user.banReason || 'No reason provided'}`,
          ephemeral: true
        });
      }
      
      // Check user's bot limit
      const userBots = await Bot.find({ owner: interaction.user.id });
      const userTier = user ? user.tier : 'free';
      const botLimit = getBotLimit(userTier);
      
      if (userBots.length >= botLimit) {
        return interaction.reply({
          content: `You have reached your bot limit (${botLimit}). Please upgrade your tier or remove an existing bot.`,
          ephemeral: true
        });
      }
      
      // Generate a default bot name
      const botName = `Bot-${Date.now()}`;
      
      // Store user's upload request with default values
      client.userBotUploads.set(interaction.user.id, {
        botName,
        timestamp: Date.now()
      });
      
      // Simply ask for file upload directly
      await interaction.reply({ 
        content: 'Please check your DMs to upload your bot file.',
        flags: 64 // Using flags: 64 instead of ephemeral: true
      });
      
      try {
        const dmChannel = await interaction.user.createDM();
        await dmChannel.send({
          embeds: [
            new EmbedBuilder()
              .setTitle('🔼 Upload Your Bot')
              .setDescription(`Please upload your bot file.\nAccepted formats: \`.zip\` or \`.js\`\nThe file will be automatically extracted and run.`)
              .setColor('#3498db')
              .setFooter({ text: 'Your upload will expire in 5 minutes' })
          ]
        });
        
        // Set a timeout to clear the upload request after 5 minutes
        setTimeout(() => {
          if (client.userBotUploads.has(interaction.user.id)) {
            client.userBotUploads.delete(interaction.user.id);
            dmChannel.send('Your bot upload request has expired. Please try again.');
          }
        }, 5 * 60 * 1000);
      } catch (error) {
        console.error('Failed to send DM:', error);
        await interaction.followUp({ 
          content: 'I was unable to send you a DM. Please make sure your DMs are open.',
          ephemeral: true 
        });
        client.userBotUploads.delete(interaction.user.id);
      }
      
      // Create or update user in database
      if (!user) {
        await User.create({
          userId: interaction.user.id,
          username: interaction.user.tag,
          tier: 'free',
          lastActive: Date.now()
        });
      } else {
        user.lastActive = Date.now();
        await user.save();
      }
    } catch (error) {
      console.error('Error handling upload bot command:', error);
      await interaction.reply({
        content: 'An error occurred while processing your request. Please try again.',
        ephemeral: true
      });
    }
  }
};

// Helper function to get bot limit based on tier
function getBotLimit(tier) {
  switch (tier) {
    case 'premium':
      return 5;
    case 'ultimate':
      return 10;
    case 'free':
    default:
      return 1;
  }
}
