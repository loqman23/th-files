const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const StatsChannel = require('../database/models/StatsChannel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dashboard')
    .setDescription('Creates or updates the bot host dashboard'),
  
  async execute(interaction, client) {
    await interaction.deferReply();
    
    try {
      // Create dashboard embed
      const embed = new EmbedBuilder()
        .setTitle('🤖 Bot Host Dashboard')
        .setDescription('Upload, manage, and run your Discord bots directly from Discord!')
        .addFields(
          { name: '🤖 Bots Running', value: client.botStats.botsRunning.toString(), inline: true },
          { name: '👥 Users Hosting', value: client.botStats.usersHosting.toString(), inline: true },
          { name: '🔁 Total Restarts', value: client.botStats.totalRestarts.toString(), inline: true },
          { name: '🛑 Crashed Bots', value: client.botStats.crashedBots.toString(), inline: true }
        )
        .setColor('#3498db')
        .setFooter({ text: `Last updated: ${new Date().toLocaleString()}` });
      
      // Create dashboard buttons
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('uploadBot:main')
            .setLabel('🔼 Upload Bot')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('myBots:main')
            .setLabel('🧾 My Bots')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('adminPanel:main')
            .setLabel('⚙️ Admin Panel')
            .setStyle(ButtonStyle.Danger)
        );
      
      // Send dashboard message
      const message = await interaction.channel.send({
        embeds: [embed],
        components: [row]
      });
      
      // Save dashboard message to database
      await StatsChannel.findOneAndUpdate(
        { guildId: interaction.guild.id },
        {
          channelId: interaction.channel.id,
          messageId: message.id,
          updatedAt: Date.now()
        },
        { upsert: true, new: true }
      );
      
      await interaction.editReply({
        content: 'Dashboard created successfully! You can now use the buttons to interact with the bot host.',
        ephemeral: true
      });
    } catch (error) {
      console.error('Error creating dashboard:', error);
      await interaction.editReply({
        content: 'An error occurred while creating the dashboard. Please try again.',
        ephemeral: true
      });
    }
  }
};
