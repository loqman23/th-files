const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Bot = require('../database/models/Bot');
const fs = require('fs-extra');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stopbot')
    .setDescription('Stop one of your bots')
    .addStringOption(option =>
      option.setName('botid')
        .setDescription('The ID of the bot to stop')
        .setRequired(true)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
      const botId = interaction.options.getString('botid');
      
      // Get bot from database
      const bot = await Bot.findOne({ botId });
      
      if (!bot) {
        return interaction.editReply({
          content: 'Bot not found. Please check the ID and try again.',
          ephemeral: true
        });
      }
      
      // Check if user is the bot owner or an admin
      const isOwner = bot.owner === interaction.user.id;
      const isAdmin = interaction.member.roles.cache.has(process.env.ADMIN_ROLE_ID);
      
      if (!isOwner && !isAdmin) {
        return interaction.editReply({
          content: 'You do not have permission to stop this bot.',
          ephemeral: true
        });
      }
      
      // Check if bot is running
      const runningBot = client.runningBots.get(botId);
      if (!runningBot) {
        return interaction.editReply({
          content: `Bot ${bot.name} is not currently running.`,
          ephemeral: true
        });
      }
      
      // Append to log file
      fs.appendFileSync(
        bot.logPath,
        `\n[${new Date().toISOString()}] Bot stopped by ${interaction.user.tag}\n`
      );
      
      // Kill the process
      runningBot.process.kill();
      
      // Remove from running bots
      client.runningBots.delete(botId);
      client.botStats.botsRunning--;
      
      // Update unique users count
      const uniqueUsers = new Set([...client.runningBots.values()].map(b => b.owner));
      client.botStats.usersHosting = uniqueUsers.size;
      
      // Update bot status in database
      await Bot.findOneAndUpdate(
        { botId },
        { status: 'stopped' },
        { new: true }
      );
      
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('⏹️ Bot Stopped')
            .setDescription(`Your bot **${bot.name}** has been stopped successfully.`)
            .setColor('#e74c3c')
            .setTimestamp()
        ],
        ephemeral: true
      });
    } catch (error) {
      console.error('Error stopping bot:', error);
      await interaction.editReply({
        content: `An error occurred while stopping the bot: ${error.message}`,
        ephemeral: true
      });
    }
  }
};
