const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setrole')
    .setDescription('Set role IDs for different tiers')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(subcommand =>
      subcommand
        .setName('premium')
        .setDescription('Set premium role ID')
        .addRoleOption(option =>
          option.setName('role')
                .setDescription('Premium role')
                .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('ultimate')
        .setDescription('Set ultimate role ID')
        .addRoleOption(option =>
          option.setName('role')
                .setDescription('Ultimate role')
                .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('admin')
        .setDescription('Add an admin role ID')
        .addRoleOption(option =>
          option.setName('role')
                .setDescription('Admin role')
                .setRequired(true))),
  
  async execute(interaction, client) {
    try {
      await interaction.deferReply({ ephemeral: true });
      
      // Check if user has admin permissions
      const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [process.env.ADMIN_ROLE_ID];
      const isAdmin = adminRoleIds.some(roleId => interaction.member.roles.cache.has(roleId));
      
      if (!isAdmin && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.editReply({
          content: 'ليس لديك صلاحيات للوصول إلى أمر إعداد الرتب.',
          ephemeral: true
        });
      }
      
      const subcommand = interaction.options.getSubcommand();
      const role = interaction.options.getRole('role');
      const roleId = role.id;
      
      // Load current env values
      const envPath = path.resolve(process.cwd(), '.env');
      const envConfig = dotenv.parse(fs.readFileSync(envPath));
      
      // Update the appropriate role ID
      if (subcommand === 'premium') {
        envConfig.PREMIUM_ROLE_ID = roleId;
        await updateEnvFile(envConfig, envPath);
        
        await interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle('✅ تم تعيين رتبة البريميوم')
              .setDescription(`تم تعيين رتبة البريميوم: <@&${roleId}>`)
              .setColor('#9b59b6')
              .setTimestamp()
          ]
        });
      } else if (subcommand === 'ultimate') {
        envConfig.ULTIMATE_ROLE_ID = roleId;
        await updateEnvFile(envConfig, envPath);
        
        await interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle('✅ تم تعيين رتبة الألتميت')
              .setDescription(`تم تعيين رتبة الألتميت: <@&${roleId}>`)
              .setColor('#f1c40f')
              .setTimestamp()
          ]
        });
      } else if (subcommand === 'admin') {
        // Check if ADMIN_ROLE_IDS exists and has values
        if (!envConfig.ADMIN_ROLE_IDS || envConfig.ADMIN_ROLE_IDS.trim() === '') {
          envConfig.ADMIN_ROLE_IDS = roleId;
        } else {
          // Split current IDs, check if role ID already exists
          const currentAdminRoles = envConfig.ADMIN_ROLE_IDS.split(',');
          if (!currentAdminRoles.includes(roleId)) {
            currentAdminRoles.push(roleId);
            envConfig.ADMIN_ROLE_IDS = currentAdminRoles.join(',');
          }
        }
        
        await updateEnvFile(envConfig, envPath);
        
        await interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle('✅ تم إضافة رتبة الإدارة')
              .setDescription(`تم إضافة رتبة الإدارة: <@&${roleId}>`)
              .setColor('#e74c3c')
              .setTimestamp()
          ]
        });
      }
      
      // Reload environment variables
      Object.keys(envConfig).forEach(key => {
        process.env[key] = envConfig[key];
      });
      
    } catch (error) {
      console.error('Error setting role ID:', error);
      await interaction.editReply({
        content: `حدث خطأ أثناء تعيين الرتبة: ${error.message}`,
        ephemeral: true
      });
    }
  }
};

// Helper function to update .env file
async function updateEnvFile(envConfig, envPath) {
  const envContent = Object.keys(envConfig)
    .map(key => `${key}=${envConfig[key]}`)
    .join('\n');
  
  await fs.promises.writeFile(envPath, envContent);
} 