const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Bot = require('../database/models/Bot');
const fs = require('fs-extra');
const path = require('path');
const { fork } = require('child_process');
const crypto = require('crypto-js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('restartbot')
    .setDescription('Restart one of your bots')
    .addStringOption(option =>
      option.setName('botid')
        .setDescription('The ID of the bot to restart')
        .setRequired(true)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
      const botId = interaction.options.getString('botid');
      
      // Get bot from database
      const bot = await Bot.findOne({ botId });
      
      if (!bot) {
        return interaction.editReply({
          content: 'Bot not found. Please check the ID and try again.',
          ephemeral: true
        });
      }
      
      // Check if user is the bot owner or an admin
      const isOwner = bot.owner === interaction.user.id;
      const isAdmin = interaction.member.roles.cache.has(process.env.ADMIN_ROLE_ID);
      
      if (!isOwner && !isAdmin) {
        return interaction.editReply({
          content: 'You do not have permission to restart this bot.',
          ephemeral: true
        });
      }
      
      // Check if bot is running
      const runningBot = client.runningBots.get(botId);
      if (!runningBot) {
        return interaction.editReply({
          content: `Bot ${bot.name} is not currently running. Use the /startbot command instead.`,
          ephemeral: true
        });
      }
      
      // Append to log file
      fs.appendFileSync(
        bot.logPath,
        `\n[${new Date().toISOString()}] Bot restarted by ${interaction.user.tag}\n`
      );
      
      // Kill the process
      runningBot.process.kill();
      
      // Remove from running bots
      client.runningBots.delete(botId);
      
      // Increment restart counter
      client.botStats.totalRestarts++;
      
      // Update bot in database
      await Bot.findOneAndUpdate(
        { botId },
        { 
          $inc: { restarts: 1 },
          lastRestart: Date.now()
        },
        { new: true }
      );
      
      // Create .env file with bot token
      const decryptedToken = crypto.AES.decrypt(bot.token, process.env.TOKEN).toString(crypto.enc.Utf8);
      fs.writeFileSync(
        path.join(bot.path, '.env'),
        `TOKEN=${decryptedToken}`
      );
      
      // Fork the process to run the bot
      const botProcess = fork(path.join(bot.path, bot.mainFile), [], {
        cwd: bot.path,
        stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
        env: { ...process.env, TOKEN: decryptedToken }
      });
      
      // Handle stdout and stderr
      botProcess.stdout.on('data', (data) => {
        fs.appendFileSync(bot.logPath, `[STDOUT] ${data.toString()}`);
      });
      
      botProcess.stderr.on('data', (data) => {
        fs.appendFileSync(bot.logPath, `[STDERR] ${data.toString()}`);
      });
      
      // Handle process exit
      botProcess.on('exit', (code, signal) => {
        const exitMessage = `Bot exited with code ${code} and signal ${signal} at ${new Date().toISOString()}\n`;
        fs.appendFileSync(bot.logPath, exitMessage);
        
        client.runningBots.delete(botId);
        client.botStats.botsRunning--;
        client.botStats.crashedBots++;
        
        // Update bot status in database
        Bot.findOneAndUpdate(
          { botId },
          { status: 'crashed' },
          { new: true }
        ).catch(err => console.error(`Error updating bot status: ${err}`));
        
        // Notify the user if this wasn't a manual stop
        if (code !== 0) {
          interaction.user.createDM().then(dmChannel => {
            dmChannel.send({
              embeds: [
                new EmbedBuilder()
                  .setTitle('🔴 Bot Crashed')
                  .setDescription(`Your bot **${bot.name}** has crashed.`)
                  .addFields(
                    { name: 'Exit Code', value: code ? code.toString() : 'Unknown', inline: true },
                    { name: 'Signal', value: signal || 'None', inline: true }
                  )
                  .setColor('#e74c3c')
                  .setTimestamp()
              ]
            });
          }).catch(err => console.error('Failed to send crash DM:', err));
        }
      });
      
      // Store bot info
      const botInfo = {
        id: botId,
        name: bot.name,
        owner: bot.owner,
        process: botProcess,
        path: bot.path,
        mainFile: bot.mainFile,
        startTime: Date.now(),
        logPath: bot.logPath,
        token: bot.token
      };
      
      client.runningBots.set(botId, botInfo);
      client.botStats.botsRunning++;
      
      // Update unique users count
      const uniqueUsers = new Set([...client.runningBots.values()].map(b => b.owner));
      client.botStats.usersHosting = uniqueUsers.size;
      
      // Update bot status in database
      await Bot.findOneAndUpdate(
        { botId },
        { status: 'running', startTime: Date.now() },
        { new: true }
      );
      
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('🔄 Bot Restarted')
            .setDescription(`Your bot **${bot.name}** has been restarted successfully.`)
            .setColor('#3498db')
            .setTimestamp()
        ],
        ephemeral: true
      });
    } catch (error) {
      console.error('Error restarting bot:', error);
      await interaction.editReply({
        content: `An error occurred while restarting the bot: ${error.message}`,
        ephemeral: true
      });
    }
  }
};
