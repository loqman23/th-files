const { EmbedBuilder } = require('discord.js');
const LogChannel = require('../database/models/LogChannel');

/**
 * إرسال سجل إلى قناة السجلات المحددة
 * @param {string} guildId - معرف السيرفر
 * @param {string} logMessage - رسالة السجل
 * @param {Object} embedOptions - خيارات إضافية للـ embed
 * @param {Object} client - عميل Discord
 */
async function sendLogToChannel(guildId, logMessage, embedOptions = {}, client) {
  try {
    // الحصول على قناة السجلات من قاعدة البيانات
    const logChannelConfig = await LogChannel.findOne({ guildId });
    
    if (!logChannelConfig) {
      return; // لم يتم تكوين قناة السجلات
    }
    
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;
    
    const channel = guild.channels.cache.get(logChannelConfig.channelId);
    if (!channel) return;
    
    // إنشاء embed افتراضي إذا لم يتم توفيره
    const defaultEmbed = {
      title: '📋 سجل النظام',
      description: logMessage,
      color: '#3498db',
      timestamp: new Date(),
      footer: { text: 'Bot Host Logs' }
    };
    
    // دمج الخيارات المقدمة مع الافتراضات
    const embed = new EmbedBuilder({
      ...defaultEmbed,
      ...embedOptions
    });
    
    await channel.send({ embeds: [embed] });
    console.log(`[LOG] Successfully sent log to channel: ${channel.name}`);
  } catch (error) {
    console.error('Error sending log to channel:', error);
  }
}

/**
 * إرسال سجل حذف بوت إلى قناة السجلات
 * @param {Object} bot - البوت المحذوف
 * @param {string} guildId - معرف السيرفر
 * @param {string} adminTag - اسم المسؤول الذي قام بالحذف
 * @param {Object} client - عميل Discord
 */
async function logBotDeletion(bot, guildId, adminTag, adminId, client) {
  if (!bot) return;
  
  const owner = await client.users.fetch(bot.owner).catch(() => null);
  const ownerTag = owner ? owner.tag : 'غير معروف';
  
  const logMessage = `تم حذف بوت: **${bot.name}**\n` +
                     `معرف البوت: \`${bot.botId}\`\n` +
                     `المالك: ${ownerTag} (\`${bot.owner}\`)\n` +
                     `بواسطة المسؤول: ${adminTag} (\`${adminId}\`)\n` +
                     `تاريخ الإنشاء: <t:${Math.floor(bot.createdAt.getTime() / 1000)}:F>`;
  
  await sendLogToChannel(guildId, logMessage, {
    title: '🗑️ حذف بوت',
    color: '#e74c3c',
  }, client);
}

/**
 * إرسال سجل حذف مستخدم إلى قناة السجلات
 * @param {Object} user - المستخدم المحذوف
 * @param {number} botsCount - عدد البوتات المحذوفة
 * @param {string} guildId - معرف السيرفر
 * @param {string} adminTag - اسم المسؤول الذي قام بالحذف
 * @param {Object} client - عميل Discord
 */
async function logUserDeletion(user, botsCount, guildId, adminTag, adminId, client) {
  if (!user) return;
  
  const logMessage = `تم حذف مستخدم: **${user.username}**\n` +
                     `معرف المستخدم: \`${user.userId}\`\n` +
                     `عدد البوتات المحذوفة: ${botsCount}\n` +
                     `رتبة المستخدم: ${user.tier || 'free'}\n` +
                     `بواسطة المسؤول: ${adminTag} (\`${adminId}\`)\n` +
                     `تاريخ التسجيل: <t:${Math.floor(user.createdAt.getTime() / 1000)}:F>`;
  
  await sendLogToChannel(guildId, logMessage, {
    title: '🗑️ حذف مستخدم',
    color: '#e74c3c',
  }, client);
}

/**
 * إرسال سجل لإعادة تشغيل بوت قسرياً
 * @param {Object} bot - البوت المعاد تشغيله
 * @param {string} guildId - معرف السيرفر
 * @param {string} adminTag - اسم المسؤول الذي قام بالإعادة
 * @param {string} adminId - معرف المسؤول
 * @param {Object} client - عميل Discord
 */
async function logBotRestart(bot, guildId, adminTag, adminId, client) {
  if (!bot) return;
  
  const owner = await client.users.fetch(bot.owner).catch(() => null);
  const ownerTag = owner ? owner.tag : 'غير معروف';
  
  const logMessage = `تم إعادة تشغيل بوت قسرياً: **${bot.name}**\n` +
                     `معرف البوت: \`${bot.botId}\`\n` +
                     `المالك: ${ownerTag} (\`${bot.owner}\`)\n` +
                     `بواسطة المسؤول: ${adminTag} (\`${adminId}\`)\n` +
                     `عدد مرات إعادة التشغيل: ${bot.restarts + 1}`;
  
  await sendLogToChannel(guildId, logMessage, {
    title: '🔄 إعادة تشغيل بوت',
    color: '#3498db',
  }, client);
}

/**
 * إرسال سجل لإيقاف بوت
 * @param {Object} bot - البوت الذي تم إيقافه
 * @param {string} guildId - معرف السيرفر
 * @param {string} adminTag - اسم المسؤول الذي قام بالإيقاف
 * @param {string} adminId - معرف المسؤول
 * @param {Object} client - عميل Discord
 */
async function logBotShutdown(bot, guildId, adminTag, adminId, client) {
  if (!bot) return;
  
  const owner = await client.users.fetch(bot.owner).catch(() => null);
  const ownerTag = owner ? owner.tag : 'غير معروف';
  
  const logMessage = `تم إيقاف بوت: **${bot.name}**\n` +
                     `معرف البوت: \`${bot.botId}\`\n` +
                     `المالك: ${ownerTag} (\`${bot.owner}\`)\n` +
                     `بواسطة المسؤول: ${adminTag} (\`${adminId}\`)`;
  
  await sendLogToChannel(guildId, logMessage, {
    title: '⛔ إيقاف بوت',
    color: '#e67e22',
  }, client);
}

module.exports = {
  sendLogToChannel,
  logBotDeletion,
  logUserDeletion,
  logBotRestart,
  logBotShutdown
}; 