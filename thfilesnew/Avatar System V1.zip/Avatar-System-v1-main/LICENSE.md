## 📄 License

© 2025 Velrosy. All rights reserved.

### Permitted Use / الاستخدام المسموح

* Use for personal, educational, or non-commercial purposes / استخدام شخصي، تعليمي، أو غير تجاري
* Modify code for learning / تعديل الكود للتعلم
* Share code for educational purposes with credits intact / مشاركة الكود لأغراض تعليمية مع الحفاظ على الحقوق

### Prohibited Use / الاستخدام المحظور

* Selling, redistributing, or commercializing / بيع أو إعادة توزيع أو استخدام تجاري
* Using for illegal or harmful activities / استخدام في أي نشاط غير قانوني أو ضار
* Claiming as your own without credit / ادعاء الكود ملكك بدون ذكر المصدر

### Disclaimer / التنويه

This project is provided "as-is", without warranty / هذا البرنامج مقدم كما هو بدون أي ضمان.
The author is not responsible for any misuse or damages / المؤلف غير مسؤول عن أي سوء استخدام أو أضرار.

---

By using this Project , you agree to all terms / باستخدامك هذا المشروع، أنت توافق على جميع الشروط.
