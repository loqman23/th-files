module.exports = {
    Bot: {
        token: 'BOT_TOKEN',
        prefix: '$'
    }
};