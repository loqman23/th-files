const { Client, IntentsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const express = require('express');
const path = require('path');
const app = express();

const config = require('./config.json');
const client = new Client({
  intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.MessageContent,
    IntentsBitField.Flags.GuildMembers,
  ],
});


app.use(express.static(path.join(__dirname)));
app.use(express.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const optionsFile = './options.json';
const pointsFile = './points.json';
const ticketsFile = './tickets.json';
if (!fs.existsSync(optionsFile)) fs.writeFileSync(optionsFile, JSON.stringify([]));
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, JSON.stringify({}));
if (!fs.existsSync(ticketsFile)) fs.writeFileSync(ticketsFile, JSON.stringify({}));


app.post('/add-option', (req, res) => {
  try {
    const { name, desc, categoryID } = req.body;
    if (!name || !desc || !categoryID) {
      return res.status(400).json({ error: 'يرجى إدخال جميع الحقول!' });
    }

    const options = JSON.parse(fs.readFileSync(optionsFile));
    if (options.length >= 4) {
      return res.status(400).json({ error: 'الحد الأقصى 4 خيارات' });
    }
    options.push({ name, desc, categoryID });
    fs.writeFileSync(optionsFile, JSON.stringify(options, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Error in /add-option:', error);
    res.status(500).json({ error: 'حدث خطأ أثناء إضافة الخيار' });
  }
});


app.post('/set-support-role', (req, res) => {
  try {
    const { roleID } = req.body;
    if (!roleID) {
      return res.status(400).json({ error: 'يرجى إدخال معرف الرتبة!' });
    }

    config.supportRoleID = roleID;
    fs.writeFileSync('./config.json', JSON.stringify(config, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Error in /set-support-role:', error);
    res.status(500).json({ error: 'حدث خطأ أثناء تحديد رتبة الدعم' });
  }
});

app.get('/get-categories', (req, res) => {
  try {
    const guild = client.guilds.cache.first(); 
    if (!guild) {
      return res.status(404).json({ error: 'لم يتم العثور على السيرفر!' });
    }

    const categories = guild.channels.cache
      .filter(channel => channel.type === 4) 
      .map(category => ({
        id: category.id,
        name: category.name,
      }));

    res.json(categories);
  } catch (error) {
    console.error('Error in /get-categories:', error);
    res.status(500).json({ error: 'حدث خطأ أثناء جلب الكاتجوريات' });
  }
});

client.on('ready', async () => {
  try {
    console.log(`Logged in as ${client.user.tag}`);

    const ticketCommand = new SlashCommandBuilder()
      .setName('ticket')
      .setDescription('إنشاء تذكرة جديدة - General Progs');

    const pointsCommand = new SlashCommandBuilder()
      .setName('points')
      .setDescription('عرض نقاطك - General Progs');

    const topCommand = new SlashCommandBuilder()
      .setName('top')
      .setDescription('عرض أعلى الأعضاء نقاطًا - General Progs');

    await client.application.commands.create(ticketCommand);
    await client.application.commands.create(pointsCommand);
    await client.application.commands.create(topCommand);
  } catch (error) {
    console.error('Error registering commands:', error);
  }
});


client.on('interactionCreate', async (interaction) => {
  try {
    
    if (interaction.isCommand()) {
      if (interaction.commandName === 'ticket') {
        
        await interaction.reply({ content: 'تم', ephemeral: true });

        
        const options = JSON.parse(fs.readFileSync(optionsFile));
        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId('ticket_select')
          .setPlaceholder('اختر نوع التذكرة')
          .addOptions(
            ...options.map(opt =>
              new StringSelectMenuOptionBuilder()
                .setLabel(opt.name)
                .setValue(opt.name)
                .setDescription(opt.desc)
            ),
            new StringSelectMenuOptionBuilder()
              .setLabel('إعادة تعيين')
              .setValue('restart')
          );

        const row = new ActionRowBuilder().addComponents(selectMenu);
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('**إنشاء تذكرة - General Progs**')
          .setDescription('**يرجى اختيار نوع التذكرة من القائمة أدناه.**');

        await interaction.channel.send({ embeds: [embed], components: [row] });
      }

      if (interaction.commandName === 'points') {
        if (!interaction.member.roles.cache.has(config.supportRoleID)) {
          return interaction.reply({ content: 'ليس لديك صلاحية استخدام هذا الأمر!', ephemeral: true });
        }
        const points = JSON.parse(fs.readFileSync(pointsFile));
        const userPoints = points[interaction.user.id] || 0;
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('**نقاطك - General Progs**')
          .setDescription(`لديك **${userPoints}** نقطة.`);
        await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      if (interaction.commandName === 'top') {
        if (!interaction.member.roles.cache.has(config.supportRoleID)) {
          return interaction.reply({ content: 'ليس لديك صلاحية استخدام هذا الأمر', ephemeral: true });
        }
        const points = JSON.parse(fs.readFileSync(pointsFile));
        const sortedPoints = Object.entries(points)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 10);
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('أعلى الأعضاء نقاطًا - General Progs')
          .setDescription(
            sortedPoints.length
              ? sortedPoints.map(([userID, points], i) => `${i + 1}. <@${userID}>: **${points}** نقطة`).join('\n')
              : 'لا توجد نقاط مسجلة.'
          );
        await interaction.reply({ embeds: [embed] });
      }
    }

   
    if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select') {
      const selected = interaction.values[0];
      const options = JSON.parse(fs.readFileSync(optionsFile));
      const tickets = JSON.parse(fs.readFileSync(ticketsFile));
      const userTickets = tickets[interaction.user.id] || [];

      if (selected === 'restart') {
        await interaction.reply({ content: 'تم', ephemeral: true });
        return;
      }

      
      if (userTickets.some(ticket => ticket.option === selected)) {
        await interaction.reply({ content: '**لديك تذكرة مفتوحة بالفعل لهذا النوع**', ephemeral: true });
        return;
      }

      const option = options.find(opt => opt.name === selected);
      const categoryID = option ? option.categoryID : null;
      const category = categoryID ? client.channels.cache.get(categoryID) : null;

      if (!category) {
        await interaction.reply({ content: '**كاتيجوري غير موجود**', ephemeral: true });
        return;
      }

      const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0,
        parent: category.id,
        permissionOverwrites: [
          { id: interaction.guild.id, deny: ['ViewChannel'] },
          { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages'] },
          { id: client.user.id, allow: ['ViewChannel', 'SendMessages'] },
          { id: config.supportRoleID, allow: ['ViewChannel', 'SendMessages'] },
        ],
      });

      
      userTickets.push({ option: selected, channelID: ticketChannel.id, ownerID: interaction.user.id });
      tickets[interaction.user.id] = userTickets;
      fs.writeFileSync(ticketsFile, JSON.stringify(tickets, null, 2));

      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('**اهلا بك في تذكرة**')
        .setDescription('** يرجي كتابة مشكلتك او طلبك **')
        .setThumbnail(interaction.user.displayAvatarURL({ size: 128 }));

      const claimButton = new ButtonBuilder()
        .setCustomId('claim_ticket')
        .setLabel('استلام')
        .setStyle(ButtonStyle.Success);
      const closeButton = new ButtonBuilder()
        .setCustomId('close_ticket')
        .setLabel('قفل التذكرة')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(claimButton, closeButton);
      await ticketChannel.send({ embeds: [embed], components: [row] });
      await interaction.reply({ content: `تم إنشاء تذكرتك: ${ticketChannel}`, ephemeral: true });
    }

    // معالجة الأزرار
    if (interaction.isButton()) {
      const tickets = JSON.parse(fs.readFileSync(ticketsFile));
      let userTickets = tickets[interaction.user.id] || [];
      const ticket = userTickets.find(t => t.channelID === interaction.channel.id);
      const ownerID = ticket ? ticket.ownerID : null;

      if (interaction.customId === 'claim_ticket') {
        if (!interaction.member.roles.cache.has(config.supportRoleID)) {
          return interaction.reply({ content: '** انت مريض ؟**', ephemeral: true });
        }

        if (ticket && ticket.claimerID) {
          return interaction.reply({ content: '**التذكرة مستلمة بالفعل من قبل شخص آخر**', ephemeral: true });
        }

        const points = JSON.parse(fs.readFileSync(pointsFile));
        points[interaction.user.id] = (points[interaction.user.id] || 0) + 1;
        fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));

        if (ticket) {
          ticket.claimerID = interaction.user.id;
          tickets[interaction.user.id] = userTickets;
          fs.writeFileSync(ticketsFile, JSON.stringify(tickets, null, 2));
        }

        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('**مرحبًا بك في تذكرتك - General Progs**')
          .setDescription('تم استلام التذكرة من قبل أحد أعضاء الدعم. يرجى شرح مشكلتك او طلبك ')
          .setThumbnail(interaction.user.displayAvatarURL({ size: 128 }));

        const unclaimButton = new ButtonBuilder()
          .setCustomId('unclaim_ticket')
          .setLabel('إلغاء الاستلام')
          .setStyle(ButtonStyle.Secondary);
        const closeButton = new ButtonBuilder()
          .setCustomId('close_ticket')
          .setLabel('قفل التذكرة')
          .setStyle(ButtonStyle.Danger);

        const row = new ActionRowBuilder().addComponents(unclaimButton, closeButton);
        await interaction.message.edit({ embeds: [embed], components: [row] });
        await interaction.reply({ content: `تم استلام التذكرة! لديك الآن **${points[interaction.user.id]}** نقطة.`, ephemeral: true });
      }

      if (interaction.customId === 'unclaim_ticket') {
        if (!interaction.member.roles.cache.has(config.supportRoleID)) {
          return interaction.reply({ content: '**لا برضو غبي **', ephemeral: true });
        }

        if (!ticket || ticket.claimerID !== interaction.user.id) {
          return interaction.reply({ content: '**لم تستلم هذه التذكرة**', ephemeral: true });
        }

        const points = JSON.parse(fs.readFileSync(pointsFile));
        points[interaction.user.id] = Math.max((points[interaction.user.id] || 0) - 1, 0);
        fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));

        ticket.claimerID = null;
        tickets[interaction.user.id] = userTickets;
        fs.writeFileSync(ticketsFile, JSON.stringify(tickets, null, 2));

        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('مرحبًا بك في** تذكرتك - General Progs**')
          .setDescription('**يرجى شرح مشكلتك او طلبك ، وسيقوم فريق الدعم بالرد عليك قريبا **')
          .setThumbnail(interaction.user.displayAvatarURL({ size: 128 }));

        const claimButton = new ButtonBuilder()
          .setCustomId('claim_ticket')
          .setLabel('استلام')
          .setStyle(ButtonStyle.Success);
        const closeButton = new ButtonBuilder()
          .setCustomId('close_ticket')
          .setLabel('قفل التذكرة')
          .setStyle(ButtonStyle.Danger);

        const row = new ActionRowBuilder().addComponents(claimButton, closeButton);
        await interaction.message.edit({ embeds: [embed], components: [row] });
        await interaction.reply({ content: 'تم إلغاء الاستلام!', ephemeral: true });
      }

      if (interaction.customId === 'close_ticket') {
        await interaction.reply({ content: '**سيتم قفل التذكرة بعد 5 ثوانٍ**', ephemeral: true });

        const messages = await interaction.channel.messages.fetch();
        let htmlContent = `
          <!DOCTYPE html>
          <html lang="ar">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>تذكرة ${interaction.channel.name} - General Progs</title>
            <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="styles.css">
          </head>
          <body>
            <div class="chat-container">
              <h1>تذكرة: ${interaction.channel.name} - General Progs</h1>
        `;

        messages.reverse().forEach((msg) => {
          htmlContent += `
            <div class="message">
              <img src="${msg.author.displayAvatarURL({ size: 128 })}" alt="Avatar" class="avatar">
              <div class="message-content">
                <span class="username">${msg.author.username}</span>
                <span class="timestamp">${new Date(msg.createdTimestamp).toLocaleString()}</span>
                <p>${msg.content}</p>
              </div>
            </div>
          `;
        });

        htmlContent += `
            </div>
          </body>
          </html>
        `;

        fs.writeFileSync(`ticket_${interaction.channel.id}.html`, htmlContent);

        const logChannel = client.channels.cache.get(config.logChannelID);
        if (!logChannel) {
          console.error('Log channel not found!');
          return;
        }

        const logEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle(`تذكرة مغلقة: ${interaction.channel.name} - General Progs`)
          .setDescription(`تم إغلاق التذكرة بواسطة ${interaction.user.tag}`)
          .addFields({ name: 'معرف التذكرة', value: interaction.channel.id })
          .setThumbnail(interaction.user.displayAvatarURL({ size: 128 }))
          .setTimestamp();

        const downloadButton = new ButtonBuilder()
          .setLabel('تحميل سجل التذكرة')
          .setURL(`http://79.99.40.71:6101/ticket_${interaction.channel.id}.html`)
          .setStyle(ButtonStyle.Link);

        const logRow = new ActionRowBuilder().addComponents(downloadButton);
        await logChannel.send({ embeds: [logEmbed], components: [logRow], files: [`ticket_${interaction.channel.id}.html`] });

        
        const allTickets = JSON.parse(fs.readFileSync(ticketsFile));
        if (ownerID && allTickets[ownerID]) {
          allTickets[ownerID] = allTickets[ownerID].filter(t => t.channelID !== interaction.channel.id);
          fs.writeFileSync(ticketsFile, JSON.stringify(allTickets, null, 2));
        }

        setTimeout(() => {
          interaction.channel.delete().catch(error => console.error('Error deleting channel:', error));
        }, 5000);
      }
    }
  } catch (error) {
    console.error('Error in interactionCreate:', error);
    await interaction.reply({ content: 'حدث خطأ أثناء معالجة طلبك!', ephemeral: true }).catch(() => {});
  }
});


client.on('error', error => {
  console.error('Client error:', error);
});
// بدل 6101 في بورت الهوست حقك 
app.listen(6101, () => console.log(' website run - General Progs'));
client.login(config.token).catch(error => {
  console.error('Error logging in:', error);
});