const { Client, IntentsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs').promises;
const stringSimilarity = require('string-similarity');
const config = require('./config.js');

const client = new Client({
  intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.MessageContent,
    IntentsBitField.Flags.GuildMembers,
  ],
});

if (config.rights !== '.h_4s') {
  console.error('⚠️ تم تغيير الحقوق! البوت لن يعمل حتى تعيد حقوق .h_4s');
  process.exit(1);
}

let db = { rooms: {}, gameStates: {}, scores: {} };
const dbPath = './database.json';

async function loadDatabase() {
  try {
    const data = await fs.readFile(dbPath, 'utf8');
    db = JSON.parse(data);
    // التأكد من وجود rooms, gameStates, scores
    if (!db.rooms) db.rooms = {};
    if (!db.gameStates) db.gameStates = {};
    if (!db.scores) db.scores = {};
  } catch (error) {
    console.error('⚠️ خطأ في تحميل قاعدة البيانات:', error.message);
    db = { rooms: {}, gameStates: {}, scores: {} }; // إعادة تعيين إذا كان فيه خطأ
    await saveDatabase();
  }
}

async function saveDatabase() {
  try {
    await fs.writeFile(dbPath, JSON.stringify(db, null, 2));
  } catch (error) {
    console.error('⚠️ خطأ في حفظ قاعدة البيانات:', error.message);
  }
}

const games = {
  روليت: require('./games/roulette.js'),
  اكس_او: require('./games/xo.js'),
  مافيا: require('./games/mafia.js'),
  كراسي: require('./games/chairs.js'),
  حجرة: require('./games/room.js'),
  نرد: require('./games/dice.js'),
  غميضة: require('./games/hide.js'),
  ريبلكا: require('./games/replica.js'),
  زر: require('./games/button.js'),
  الأسرع: require('./games/fastest.js'),
  فكك: require('./games/unscramble.js'),
  ادمج: require('./games/merge.js'),
  أعلام: require('./games/flags.js'),
  اعكس: require('./games/reverse.js'),
  حرف: require('./games/letter.js'),
  صحح: require('./games/correct.js'),
  ترتيب: require('./games/arrange.js'),
  ألوان: require('./games/colors.js'),
  ايموجي: require('./games/emoji.js'),
  عجلة: require('./games/wheel.js'),
  هوت_اكس_او: require('./games/hotxo.js'),
};

const allCommands = Object.keys(games).concat(
  ['العاب', 'غرفه'],
  ...Object.values(config.games).flatMap(category =>
    category.flatMap(game => game.aliases || [])
  )
);

client.on('clientReady', async () => {
  console.log(`🌟 تم تسجيل الدخول كـ ${client.user.tag}!`);
  await loadDatabase();

  const guild = client.guilds.cache.first();
  if (!guild) {
    console.error('⚠️ البوت ليس في أي سيرفر! أضف البوت إلى سيرفر أولاً.');
    return;
  }

  try {
    const owner = await client.users.fetch(guild.ownerId);
    if (config.rights !== '.h_4s') {
      await owner.send('⚠️ هل تهزر؟ تم تغيير حقوق البوت! أرجع حقوق .h_4s وإلا البوت مش هيشتغل! 😡');
      process.exit(1);
    }
  } catch (error) {
    console.error('⚠️ خطأ في استرجاع صاحب السيرفر:', error.message);
  }
});

client.on('messageCreate', async message => {
  if (message.author.bot || !message.content.startsWith(config.prefix)) return;
  if (!message.guild) return message.reply('❌ هذا الأمر يعمل فقط في سيرفر، مش في الرسائل الخاصة!');

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  let command = args.shift().toLowerCase();

  if (!allCommands.includes(command) && command !== 'غرفه' && command !== 'العاب') {
    const matches = stringSimilarity.findBestMatch(command, allCommands);
    if (matches.bestMatch.rating > 0.4) {
      return message.reply(`❌ الأمر "${command}" غير موجود! هل تقصد "${matches.bestMatch.target}"؟`);
    }
    return message.reply(`❌ الأمر "${command}" غير موجود! استخدم !العاب لعرض الألعاب المتوفرة.`);
  }

  if (command === 'العاب' || command === 'الألعاب') {
    const gameList = [
      '🎮 **ألعاب السيرفر**',
      ...config.games.server.map(g => `${g.emoji} ${g.name} (${g.aliases.join(', ')}): ${g.description}`),
      '\n🎮 **ألعاب فردية**',
      ...config.games.solo.map(g => `${g.emoji} ${g.name} (${g.aliases.join(', ')}): ${g.description}`),
      '\n🎮 **ألعاب المجموعات**',
      ...config.games.group.map(g => `${g.emoji} ${g.name} (${g.aliases.join(', ')}): ${g.description}`),
    ].join('\n');
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('refresh_games').setLabel('تحديث القائمة').setStyle(ButtonStyle.Primary).setEmoji('🔄')
    );
    return message.reply({ content: `🌟 **قائمة الألعاب المتوفرة** 🌟\n${gameList}\n\n📜 حقوق البوت: CS`, components: [row] });
  }

  if (command === 'غرفه' || command === 'غرفة') {
    const roomName = args.join(' ');
    if (!roomName) return message.reply('❌ يرجى تحديد اسم الغرفة!');
    if (!db.rooms) db.rooms = {}; // التأكد من وجود db.rooms
    db.rooms[message.channel.id] = { name: roomName, activeGame: null, players: [] };
    await saveDatabase();
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('join_room').setLabel('انضم للغرفة').setStyle(ButtonStyle.Success).setEmoji('✅')
    );
    return message.reply({ content: `🏠 **تم إنشاء غرفة باسم "${roomName}"!** انضم باستخدام الزر أدناه.\n📜 حقوق البوت: CS`, components: [row] });
  }

  let gameCommand = Object.keys(games).find(key =>
    key === command || config.games.server.concat(config.games.solo, config.games.group).some(g => g.aliases.includes(command) && g.name === key)
  );

  if (gameCommand) {
    if (!db.rooms[message.channel.id]) {
      return message.reply('❌ يجب إنشاء غرفة أولاً باستخدام !غرفه [اسم_الغرفة]');
    }
    try {
      if (!message.guild) throw new Error(`Guild is undefined for command: ${gameCommand}`);
      console.log(`تشغيل اللعبة: ${gameCommand} في سيرفر: ${message.guild.id}`);
      await games[gameCommand].execute(message, args, db, saveDatabase, client);
      db.scores[message.author.id] = (db.scores[message.author.id] || 0) + 1;
      await saveDatabase();
    } catch (error) {
      console.error(`خطأ في تشغيل اللعبة "${gameCommand}" في سيرفر ${message.guild?.id || 'غير معروف'}:`, error);
      message.reply(`❌ حدث خطأ أثناء تشغيل اللعبة "${gameCommand}"! تأكد من أنك في سيرفر وحاول مرة أخرى.`);
    }
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (!interaction.guild) return interaction.reply({ content: '❌ هذا يعمل فقط في السيرفرات!', ephemeral: true });

  if (interaction.customId === 'refresh_games') {
    const gameList = [
      '🎮 **ألعاب السيرفر**',
      ...config.games.server.map(g => `${g.emoji} ${g.name} (${g.aliases.join(', ')}): ${g.description}`),
      '\n🎮 **ألعاب فردية**',
      ...config.games.solo.map(g => `${g.emoji} ${g.name} (${g.aliases.join(', ')}): ${g.description}`),
      '\n🎮 **ألعاب المجموعات**',
      ...config.games.group.map(g => `${g.emoji} ${g.name} (${g.aliases.join(', ')}): ${g.description}`),
    ].join('\n');
    await interaction.update({ content: `🌟 **قائمة الألعاب المتوفرة** 🌟\n${gameList}\n\n📜 حقوق البوت: CS`, components: [interaction.message.components[0]] });
  }

  if (interaction.customId === 'join_room') {
    if (!db.rooms) db.rooms = {}; // التأكد من وجود db.rooms
    const room = db.rooms[interaction.channel.id];
    if (!room) return interaction.reply({ content: '⚠️ لا توجد غرفة في هذه القناة!', ephemeral: true });
    if (!room.players.includes(interaction.user.id)) {
      room.players.push(interaction.user.id);
      await saveDatabase();
      await interaction.reply({ content: `✅ **${interaction.user.username} انضم إلى الغرفة "${room.name}"!**`, ephemeral: true });
    } else {
      await interaction.reply({ content: '⚠️ أنت بالفعل في الغرفة!', ephemeral: true });
    }
  }
});

client.login(config.token);