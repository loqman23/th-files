module.exports = {
  token: '',
  prefix: '!',
  rights: '.h_4s', // لا تغير هذا! حقوق البوت لـ .h_4s
  games: {
    server: [
      { name: 'روليت', aliases: ['roulette', 'رول'], emoji: '🎰', description: 'دور الروليت وجرب حظك!' },
      { name: 'اكس_او', aliases: ['xo', 'اكساو'], emoji: '❌⭕', description: 'تحدى صديقك في XO!' },
      { name: 'مافيا', aliases: ['mafia', 'ماف'], emoji: '🕵️‍♂️', description: 'اكتشف من المافيا!' },
      { name: 'كراسي', aliases: ['chairs', 'كرسي'], emoji: '🪑', description: 'الكراسي الموسيقية الممتعة!' },
      { name: 'حجرة', aliases: ['room', 'حجره'], emoji: '🏠', description: 'حل الألغاز الذكية!' },
      { name: 'نرد', aliases: ['dice', 'نردي'], emoji: '🎲', description: 'ارمِ النرد وشوف النتيجة!' },
      { name: 'غميضة', aliases: ['hide', 'غميضه'], emoji: '🙈', description: 'اختبئ وابحث عن الآخرين!' },
      { name: 'ريبلكا', aliases: ['replica', 'ريب'], emoji: '🔄', description: 'كرر الكلمة بإبداع!' },
    ],
    solo: [
      { name: 'زر', aliases: ['button', 'زرار'], emoji: '🔳', description: 'اضغط الزر بسرعة!' },
      { name: 'الأسرع', aliases: ['fastest', 'اسرع'], emoji: '🏃‍♂️', description: 'كن الأسرع في الضغط!' },
      { name: 'فكك', aliases: ['unscramble', 'فك'], emoji: '🔠', description: 'فك الكلمة المشوشة!' },
      { name: 'ادمج', aliases: ['merge', 'دمج'], emoji: '🔗', description: 'ادمج كلمتين بذكاء!' },
      { name: 'أعلام', aliases: ['flags', 'علم'], emoji: '🏳️', description: 'خمن اسم العلم!' },
      { name: 'اعكس', aliases: ['reverse', 'عكس'], emoji: '↩️', description: 'اعكس الكلمة المعطاة!' },
      { name: 'حرف', aliases: ['letter', 'حرفي'], emoji: '✉️', description: 'اكتب كلمة بحرف معين!' },
      { name: 'صحح', aliases: ['correct', 'تصحيح'], emoji: '✅', description: 'صحح الجملة الخاطئة!' },
      { name: 'ترتيب', aliases: ['arrange', 'رتب'], emoji: '📚', description: 'رتب الكلمات لجملة صحيحة!' },
      { name: 'ألوان', aliases: ['colors', 'لون'], emoji: '🎨', description: 'خمن اسم اللون!' },
      { name: 'ايموجي', aliases: ['emoji', 'ايموج'], emoji: '😀', description: 'فسر الإيموجي!' },
    ],
    group: [
      { name: 'عجلة', aliases: ['wheel', 'عجله'], emoji: '🎡', description: 'دور عجلة الحظ!' },
      { name: 'هوت_اكس_او', aliases: ['hotxo', 'هوت'], emoji: '🔥❌⭕', description: 'XO جماعي ملتهب!' },
    ],
  },
};