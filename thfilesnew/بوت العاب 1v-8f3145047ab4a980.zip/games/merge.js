const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const wordPairs = [
      ['كرة', 'قدم'],
      ['شمس', 'ضوء'],
      ['ماء', 'ثلج'],
      ['شجرة', 'ورق'],
    ];
    const words = wordPairs[Math.floor(Math.random() * wordPairs.length)];
    db.gameStates[message.channel.id] = { game: 'ادمج', words, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('answer_merge').setLabel('أرسل الإجابة').setStyle(ButtonStyle.Primary).setEmoji('🔗')
    );

    await message.reply({
      content: `🔗 **ادمج الكلمتين!**\nالكلمتان: **${words.join(' + ')}**\nاكتب !إجابة [جوابك]\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = m => m.content.startsWith('!إجابة') && m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000 });

    collector.on('collect', async (m) => {
      const answer = m.content.split(' ').slice(1).join(' ').toLowerCase();
      if (answer.includes(words[0].toLowerCase()) && answer.includes(words[1].toLowerCase())) {
        db.gameStates[message.channel.id].winner = m.author.id;
        db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 3;
        await saveDatabase();
        collector.stop();
        await m.reply(`🏆 **مبروك <@${m.author.id}>! إجابتك رائعة: ${answer}** 🎉 النقاط: ${db.scores[m.author.id]}\n📜 حقوق البوت: CS`);
      } else {
        await m.reply(`❌ **الإجابة لا تحتوي على الكلمتين!** حاول مرة أخرى.\n📜 حقوق البوت: CS`);
      }
    });
  },
};
