const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const flags = [
      { emoji: '🇸🇦', name: 'السعودية' },
      { emoji: '🇪🇬', name: 'مصر' },
      { emoji: '🇦🇪', name: 'الإمارات' },
      { emoji: '🇯🇴', name: 'الأردن' },
      { emoji: '🇵🇸', name: 'فلسطين' },
    ];
    const selected = flags[Math.floor(Math.random() * flags.length)];
    const wrongAnswers = flags.filter(f => f.name !== selected.name).sort(() => Math.random() - 0.5).slice(0, 3).map(f => f.name);
    const options = [selected.name, ...wrongAnswers].sort(() => Math.random() - 0.5);
    db.gameStates[message.channel.id] = { game: 'أعلام', flag: selected.emoji, answer: selected.name, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      options.map(opt =>
        new ButtonBuilder()
          .setCustomId(`flag_${opt}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Primary)
      )
    );

    await message.reply({
      content: `🏳️ **خمن اسم العلم!** ${selected.emoji}\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = (i) => i.customId.startsWith('flag_') && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', async (i) => {
      const choice = i.customId.split('_')[1];
      db.gameStates[message.channel.id].winner = choice === selected.name ? i.user.id : null;
      if (choice === selected.name) {
        db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 3;
      }
      await saveDatabase();
      await i.update({
        content: choice === selected.name
          ? `🏆 **مبروك <@${i.user.id}>! الإجابة صحيحة: ${selected.name}** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`
          : `❌ **الإجابة خاطئة!** الإجابة الصحيحة: ${selected.name}\n📜 حقوق البوت: .h_4s`,
        components: [],
      });
      collector.stop();
    });
  },
};