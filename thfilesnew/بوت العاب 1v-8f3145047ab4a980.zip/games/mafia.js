const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const players = [message.author.id, ...(message.mentions.users.map(u => u.id) || [])];
    if (players.length < 3) {
      return message.reply('❌ **يلزم 3 لاعبين على الأقل للعب المافيا! منشن لاعبين.**');
    }
    const roles = ['مافيا', 'مواطن', 'مواطن', 'طبيب', 'شرطي'].slice(0, players.length);
    const shuffledRoles = roles.sort(() => Math.random() - 0.5);
    const playerRoles = {};
    players.forEach((p, i) => (playerRoles[p] = shuffledRoles[i]));
    db.gameStates[message.channel.id] = { game: 'مافيا', phase: 'night', players, playerRoles, votes: {}, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('vote_mafia').setLabel('صوت').setStyle(ButtonStyle.Danger).setEmoji('🗳️')
    );

    await message.reply({
      content: `🕵️‍♂️ **بدأت لعبة المافيا!** مرحلة الليل: المافيا تختار ضحية.\n📜 حقوق البوت: CS`,
      components: [row],
    });

    const filter = i => i.customId === 'vote_mafia' && players.includes(i.user.id);
    const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      if (db.gameStates[message.channel.id].phase === 'night' && db.gameStates[message.channel.id].playerRoles[i.user.id] !== 'مافيا') {
        return i.reply({ content: '❌ **لست مافيا! انتظر مرحلة النهار.**', ephemeral: true });
      }
      await i.reply({ content: `🗳️ **اختر لاعب للتصويت عليه:** اكتب !صوت @لاعب`, ephemeral: true });
    });

    const voteCollector = message.channel.createMessageCollector({
      filter: m => m.content.startsWith('!صوت') && players.includes(m.author.id),
      time: 60000,
    });

    voteCollector.on('collect', async m => {
      const votedUser = m.mentions.users.first();
      if (!votedUser || !players.includes(votedUser.id)) return;
      db.gameStates[message.channel.id].votes[m.author.id] = votedUser.id;
      await saveDatabase();
      if (Object.keys(db.gameStates[message.channel.id].votes).length === players.length) {
        const voteCounts = players.reduce((acc, p) => {
          acc[p] = Object.values(db.gameStates[message.channel.id].votes).filter(v => v === p).length;
          return acc;
        }, {});
        const eliminated = players.reduce((a, b) => (voteCounts[a] > voteCounts[b] ? a : b));
        players.splice(players.indexOf(eliminated), 1);
        db.gameStates[message.channel.id].players = players;
        if (players.filter(p => db.gameStates[message.channel.id].playerRoles[p] === 'مافيا').length === 0) {
          db.gameStates[message.channel.id].winner = 'مواطنين';
          db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 10;
          await saveDatabase();
          voteCollector.stop();
          return m.channel.send(`🏆 **فاز المواطنون!** تم القضاء على المافيا.\n📜 حقوق البوت: .h_4s`);
        }
        await saveDatabase();
        await m.channel.send(`🗳️ **تم طرد <@${eliminated}>!** مرحلة الليل التالية.\n📜 حقوق البوت: .h_4s`);
      }
    });
  },
};