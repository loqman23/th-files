const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const words = ['مرحبا', 'كتاب', 'سيارة', 'مفتاح', 'شجرة'];
    const word = words[Math.floor(Math.random() * words.length)];
    const reversed = word.split('').reverse().join('');
    db.gameStates[message.channel.id] = { game: 'اعكس', word, reversed, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('answer_reverse').setLabel('أرسل الإجابة').setStyle(ButtonStyle.Primary).setEmoji('↩️')
    );

    await message.reply({
      content: `↩️ **اعكس الكلمة!**\nالكلمة: **${word}**\nاكتب !إجابة [جوابك]\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = m => m.content.startsWith('!إجابة') && m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000 });

    collector.on('collect', async (m) => {
      const answer = m.content.split(' ').slice(1).join(' ').toLowerCase();
      if (answer === reversed.toLowerCase()) {
        db.gameStates[message.channel.id].winner = m.author.id;
        db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 3;
        await saveDatabase();
        collector.stop();
        await m.reply(`🏆 **مبروك <@${m.author.id}>! الإجابة صحيحة: ${reversed}** 🎉 النقاط: ${db.scores[m.author.id]}\n📜 حقوق البوت: CS`);
      } else {
        await m.reply(`❌ **الإجابة خاطئة!** حاول مرة أخرى.\n📜 حقوق البوت: CS`);
      }
    });
  },
};