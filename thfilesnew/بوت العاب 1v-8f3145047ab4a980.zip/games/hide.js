const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const seeker = message.author.id;
    const players = [seeker, ...(message.mentions.users.map(u => u.id) || [])];
    if (players.length < 2) {
      return message.reply('❌ **يلزم لاعب واحد على الأقل للعب الغميضة! منشن لاعبين.**');
    }
    const hiders = players.filter(p => p !== seeker);
    db.gameStates[message.channel.id] = { game: 'غميضة', seeker, hiders, found: [], winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('hide').setLabel('اختبئ').setStyle(ButtonStyle.Primary).setEmoji('🙈')
    );

    await message.reply({
      content: `🙈 **لعبة الغميضة بدأت!** <@${seeker}> هو الباحث. اضغط لتختبئ!\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const hideFilter = i => i.customId === 'hide' && hiders.includes(i.user.id);
    const hideCollector = message.channel.createMessageComponentCollector({ hideFilter, time: 30000 });

    hideCollector.on('collect', async i => {
      if (!db.gameStates[message.channel.id].hiders.includes(i.user.id)) {
        return i.reply({ content: '❌ **لست من المختبئين!**', ephemeral: true });
      }
      db.gameStates[message.channel.id].hiders = db.gameStates[message.channel.id].hiders.filter(p => p !== i.user.id);
      db.gameStates[message.channel.id].found.push(i.user.id);
      await saveDatabase();
      await i.reply({ content: `🙈 **${i.user.username} اختبأ!**`, ephemeral: true });
    });

    hideCollector.on('end', async () => {
      if (db.gameStates[message.channel.id].hiders.length === 0) {
        await message.channel.send(`❌ **لم يختبئ أحد! اللعبة انتهت.**\n📜 حقوق البوت: .h_4s`);
        return;
      }
      const findRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('find').setLabel('ابحث عن لاعب').setStyle(ButtonStyle.Danger).setEmoji('🔍')
      );
      await message.channel.send({
        content: `🔍 **مرحلة البحث!** <@${seeker}> ابحث عن اللاعبين المختبئين.\n📜 حقوق البوت: .h_4s`,
        components: [findRow],
      });

      const findFilter = i => i.customId === 'find' && i.user.id === seeker;
      const findCollector = message.channel.createMessageComponentCollector({ findFilter, time: 30000 });

      findCollector.on('collect', async i => {
        const foundPlayer = db.gameStates[message.channel.id].hiders[Math.floor(Math.random() * db.gameStates[message.channel.id].hiders.length)];
        db.gameStates[message.channel.id].found.push(foundPlayer);
        db.gameStates[message.channel.id].hiders = db.gameStates[message.channel.id].hiders.filter(p => p !== foundPlayer);
        await saveDatabase();
        if (db.gameStates[message.channel.id].hiders.length === 0) {
          db.gameStates[message.channel.id].winner = seeker;
          db.scores[seeker] = (db.scores[seeker] || 0) + 5;
          await saveDatabase();
          findCollector.stop();
          await i.update({
            content: `🏆 **فاز <@${seeker}>!** وجد كل المختبئين! 🎉 النقاط: ${db.scores[seeker]}\n📜 حقوق البوت: .h_4s`,
            components: [],
          });
        } else {
          await i.update({
            content: `🔍 **وجدت <@${foundPlayer}>!** ${db.gameStates[message.channel.id].hiders.length} لاعبين متبقين.\n📜 حقوق البوت: .h_4s`,
            components: [findRow],
          });
        }
      });
    });
  },
};