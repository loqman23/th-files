const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const sentences = [
      { words: ['اليوم', 'هو', 'الأحد'], correct: 'اليوم هو الأحد' },
      { words: ['أنا', 'أحب', 'القراءة'], correct: 'أنا أحب القراءة' },
      { words: ['السيارة', 'في', 'الكراج'], correct: 'السيارة في الكراج' },
    ];
    const selected = sentences[Math.floor(Math.random() * sentences.length)];
    const shuffled = selected.words.sort(() => Math.random() - 0.5);
    db.gameStates[message.channel.id] = { game: 'ترتيب', words: selected.words, correct: selected.correct, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('answer_arrange').setLabel('أرسل الإجابة').setStyle(ButtonStyle.Primary).setEmoji('📚')
    );

    await message.reply({
      content: `📚 **رتب الجملة!**\nالكلمات: **${shuffled.join(' ')}**\nاكتب !إجابة [جوابك]\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = m => m.content.startsWith('!إجابة') && m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000 });

    collector.on('collect', async (m) => {
      const answer = m.content.split(' ').slice(1).join(' ').toLowerCase();
      if (answer === selected.correct.toLowerCase()) {
        db.gameStates[message.channel.id].winner = m.author.id;
        db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 3;
        await saveDatabase();
        collector.stop();
        await m.reply(`🏆 **مبروك <@${m.author.id}>! الجملة صحيحة: ${selected.correct}** 🎉 النقاط: ${db.scores[m.author.id]}\n📜 حقوق البوت: .h_4s`);
      } else {
        await m.reply(`❌ **الجملة خاطئة!** حاول مرة أخرى.\n📜 حقوق البوت: .h_4s`);
      }
    });
  },
};
