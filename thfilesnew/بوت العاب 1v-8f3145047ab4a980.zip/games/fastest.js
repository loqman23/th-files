const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    db.gameStates[message.channel.id] = { game: 'الأسرع', started: Date.now(), winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('fastest_click').setLabel('اضغط أولاً').setStyle(ButtonStyle.Primary).setEmoji('🏃‍♂️')
    );

    await message.reply({
      content: `🏃‍♂️ **لعبة الأسرع!** أول من يضغط الزر يفوز!\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = (i) => i.customId === 'fastest_click';
    const collector = message.channel.createMessageComponentCollector({ filter, max: 1, time: 30000 });

    collector.on('collect', async (i) => {
      db.gameStates[message.channel.id].winner = i.user.id;
      db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 3;
      await saveDatabase();
      await i.update({
        content: `🏆 **مبروك <@${i.user.id}>! أنت الأسرع!** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`,
        components: [],
      });
    });
  },
};