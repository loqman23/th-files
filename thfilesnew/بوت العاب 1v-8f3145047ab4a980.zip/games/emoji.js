const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const emojis = [
      { combo: '😺🐶', answer: 'قطة وكلب' },
      { combo: '🍎🍊', answer: 'تفاحة وبرتقال' },
      { combo: '🚗🏍️', answer: 'سيارة وموتوسيكل' },
      { combo: '🌞🌙', answer: 'شمس وقمر' },
      { combo: '📚✏️', answer: 'كتاب وقلم' },
    ];
    const selected = emojis[Math.floor(Math.random() * emojis.length)];
    const wrongAnswers = emojis
      .filter(e => e.answer !== selected.answer)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map(e => e.answer);
    const options = [selected.answer, ...wrongAnswers].sort(() => Math.random() - 0.5);
    db.gameStates[message.channel.id] = {
      game: 'ايموجي',
      emojis: selected.combo,
      answer: selected.answer,
      winner: null,
    };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      options.map(opt =>
        new ButtonBuilder()
          .setCustomId(`emoji_${opt}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Primary)
      )
    );

    await message.reply({
      content: `😀 **فسر الإيموجي!** ${selected.combo}\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = i => i.customId.startsWith('emoji_') && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', async i => {
      const choice = i.customId.split('_')[1];
      db.gameStates[message.channel.id].winner = choice === selected.answer ? i.user.id : null;
      if (choice === selected.answer) {
        db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 3;
      }
      await saveDatabase();
      await i.update({
        content: choice === selected.answer
          ? `🏆 **مبروك <@${i.user.id}>! الإجابة صحيحة: ${selected.answer}** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`
          : `❌ **الإجابة خاطئة!** الإجابة الصحيحة: ${selected.answer}\n📜 حقوق البوت: .h_4s`,
        components: [],
      });
      collector.stop();
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await message.channel.send({
          content: `⏰ **انتهى وقت لعبة الإيموجي!** الإجابة الصحيحة: ${selected.answer}\n📜 حقوق البوت: CS`,
          components: [],
        });
      }
    });
  },
};