const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const prizes = [
      { name: '100 نقطة', points: 100 },
      { name: '50 نقطة', points: 50 },
      { name: 'جائزة سرية 🏆', points: 200 },
      { name: 'لا شيء 😅', points: 0 },
      { name: '10 نقاط', points: 10 },
    ];
    const selected = prizes[Math.floor(Math.random() * prizes.length)];
    db.gameStates[message.channel.id] = {
      game: 'عجلة',
      prize: selected.name,
      points: selected.points,
      winner: null,
    };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spin_wheel')
        .setLabel('دور العجلة')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🎡')
    );

    await message.reply({
      content: `🎡 **دور عجلة الحظ!** اضغط لتكتشف جائزتك!\n📜 حقوق البوت: CS`,
      components: [row],
    });

    const filter = i => i.customId === 'spin_wheel' && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, max: 1, time: 30000 });

    collector.on('collect', async i => {
      db.gameStates[message.channel.id].winner = i.user.id;
      db.scores[i.user.id] = (db.scores[i.user.id] || 0) + selected.points;
      await saveDatabase();
      await i.update({
        content: `🎡 **توقفت العجلة!** فزت بـ **${selected.name}**! 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`,
        components: [],
      });
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await message.channel.send({
          content: `⏰ **انتهى وقت لعبة العجلة!** جرب مرة أخرى.\n📜 حقوق البوت: CS`,
          components: [],
        });
      }
    });
  },
};