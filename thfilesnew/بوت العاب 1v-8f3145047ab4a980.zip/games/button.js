const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    let clicks = 0;
    db.gameStates[message.channel.id] = { game: 'زر', clicks, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('button_click').setLabel('اضغط الزر').setStyle(ButtonStyle.Primary).setEmoji('🔳')
    );

    await message.reply({
      content: `🔳 **اضغط الزر 5 مرات للفوز!**\nالضغطات: ${clicks}/5\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = (i) => i.customId === 'button_click' && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', async (i) => {
      clicks++;
      db.gameStates[message.channel.id].clicks = clicks;
      if (clicks >= 5) {
        db.gameStates[message.channel.id].winner = i.user.id;
        db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 3;
        await saveDatabase();
        await i.update({
          content: `🏆 **مبروك <@${i.user.id}>! فزت بضغط الزر 5 مرات!** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`,
          components: [],
        });
        collector.stop();
      } else {
        await saveDatabase();
        await i.update({
          content: `🔳 **اضغط الزر 5 مرات للفوز!**\nالضغطات: ${clicks}/5\n📜 حقوق البوت: .h_4s`,
          components: [row],
        });
      }
    });
  },
};
