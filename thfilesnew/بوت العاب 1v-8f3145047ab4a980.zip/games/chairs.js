const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    let chairs = args[0] ? parseInt(args[0]) : 5;
    if (chairs < 2) chairs = 2;
    const players = [message.author.id, ...(message.mentions.users.map(u => u.id) || [])];
    if (players.length < 2) {
      return message.reply('❌ **يلزم لاعبان على الأقل للعب الكراسي! منشن لاعبين.**');
    }
    db.gameStates[message.channel.id] = { game: 'كراسي', chairs, players, currentRound: 1, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('sit_chair').setLabel('اجلس على كرسي').setStyle(ButtonStyle.Primary).setEmoji('🪑')
    );

    await message.reply({
      content: `🪑 **بدأت لعبة الكراسي!** ${chairs} كراسي متاحة في الجولة ${db.gameStates[message.channel.id].currentRound}. اضغط لتجلس!\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = i => i.customId === 'sit_chair' && players.includes(i.user.id);
    const collector = message.channel.createMessageComponentCollector({ filter, max: chairs, time: 30000 });

    collector.on('collect', async i => {
      if (!db.gameStates[message.channel.id].players.includes(i.user.id)) {
        return i.reply({ content: '❌ **لست في اللعبة!**', ephemeral: true });
      }
    });

    collector.on('end', async collected => {
      if (collected.size < chairs) {
        db.gameStates[message.channel.id].winner = null;
        await saveDatabase();
        return message.channel.send(`❌ **اللعبة انتهت!** لم يجلس عدد كافٍ من اللاعبين.\n📜 حقوق البوت: .h_4s`);
      }
      const winners = collected.map(i => i.user.id);
      db.gameStates[message.channel.id].players = winners;
      db.gameStates[message.channel.id].chairs--;
      db.gameStates[message.channel.id].currentRound++;
      await saveDatabase();
      if (db.gameStates[message.channel.id].chairs === 0 || winners.length === 1) {
        const winner = winners[0];
        db.gameStates[message.channel.id].winner = winner;
        db.scores[winner] = (db.scores[winner] || 0) + 7;
        await saveDatabase();
        return message.channel.send(`🏆 **فاز <@${winner}> بلعبة الكراسي!** 🎉 النقاط: ${db.scores[winner]}\n📜 حقوق البوت: .h_4s`);
      }
      const newRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('sit_chair').setLabel('اجلس على كرسي').setStyle(ButtonStyle.Primary).setEmoji('🪑')
      );
      await message.channel.send({
        content: `🪑 **الجولة ${db.gameStates[message.channel.id].currentRound}!** ${db.gameStates[message.channel.id].chairs} كراسي متاحة. اضغط لتجلس!\n📜 حقوق البوت: .h_4s`,
        components: [newRow],
      });
    });
  },
};
