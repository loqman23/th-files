const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const roll = Math.floor(Math.random() * 6) + 1;
    db.gameStates[message.channel.id] = { game: 'نرد', lastRoll: roll, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('roll_dice').setLabel('ارمِ النرد مرة أخرى').setStyle(ButtonStyle.Primary).setEmoji('🎲')
    );

    await message.reply({
      content: `🎲 **لقد رميت النرد وأتت النتيجة: ${roll}**\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = (i) => i.customId === 'roll_dice' && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (i) => {
      const newRoll = Math.floor(Math.random() * 6) + 1;
      db.gameStates[message.channel.id].lastRoll = newRoll;
      await saveDatabase();
      await i.update({
        content: `🎲 **لقد رميت النرد وأتت النتيجة: ${newRoll}**\n📜 حقوق البوت: .h_4s`,
        components: [row],
      });
    });
  },
};