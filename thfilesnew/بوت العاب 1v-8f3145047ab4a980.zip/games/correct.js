const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const sentences = [
      { wrong: 'اليوم هو يوم الاحد', correct: 'الأحد' },
      { wrong: 'انا ذاهب الى المدرسه', correct: 'المدرسة' },
      { wrong: 'الكتاب على الطاوله', correct: 'الطاولة' },
    ];
    const selected = sentences[Math.floor(Math.random() * sentences.length)];
    db.gameStates[message.channel.id] = { game: 'صحح', sentence: selected.wrong, correct: selected.correct, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('answer_correct').setLabel('أرسل الإجابة').setStyle(ButtonStyle.Primary).setEmoji('✅')
    );

    await message.reply({
      content: `✅ **صحح الجملة!**\nالجملة: **${selected.wrong}**\nاكتب !إجابة [الكلمة الصحيحة]\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = m => m.content.startsWith('!إجابة') && m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000 });

    collector.on('collect', async (m) => {
      const answer = m.content.split(' ').slice(1).join(' ').toLowerCase();
      if (answer === selected.correct.toLowerCase()) {
        db.gameStates[message.channel.id].winner = m.author.id;
        db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 3;
        await saveDatabase();
        collector.stop();
        await m.reply(`🏆 **مبروك <@${m.author.id}>! الإجابة صحيحة: ${selected.correct}** 🎉 النقاط: ${db.scores[m.author.id]}\n📜 حقوق البوت: CS`);
      } else {
        await m.reply(`❌ **الإجابة خاطئة!** حاول مرة أخرى.\n📜 حقوق البوت:.h_4s`);
      }
    });
  },
};