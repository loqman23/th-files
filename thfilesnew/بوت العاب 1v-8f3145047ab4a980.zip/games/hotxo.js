const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const players = [message.author.id, ...(message.mentions.users.map(u => u.id) || [])];
    if (players.length < 2) {
      return message.reply('❌ **يلزم لاعبان على الأقل للعب هوت اكس او! منشن لاعبين.**');
    }
    const board = Array(9).fill('⬜');
    const symbols = ['❌', '⭕', '🔺', '🔷'].slice(0, players.length);
    const playerSymbols = {};
    players.forEach((p, i) => (playerSymbols[p] = symbols[i]));
    let currentPlayer = players[0];
    db.gameStates[message.channel.id] = {
      game: 'هوت_اكس_او',
      board,
      currentPlayer,
      players,
      playerSymbols,
      winner: null,
    };
    await saveDatabase();

    const checkWin = (board, symbol) => {
      const winConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8], // Rows
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8], // Columns
        [0, 4, 8],
        [2, 4, 6], // Diagonals
      ];
      return winConditions.some(condition =>
        condition.every(index => board[index] === symbol)
      );
    };

    const displayBoard = () => {
      const buttons = board.map((cell, i) =>
        new ButtonBuilder()
          .setCustomId(`hotxo_${i}`)
          .setLabel(cell)
          .setStyle(
            cell === '⬜'
              ? ButtonStyle.Secondary
              : cell === '❌'
              ? ButtonStyle.Danger
              : cell === '⭕'
              ? ButtonStyle.Success
              : cell === '🔺'
              ? ButtonStyle.Primary
              : ButtonStyle.Primary
          )
          .setDisabled(cell !== '⬜')
      );
      return [
        new ActionRowBuilder().addComponents(buttons.slice(0, 3)),
        new ActionRowBuilder().addComponents(buttons.slice(3, 6)),
        new ActionRowBuilder().addComponents(buttons.slice(6, 9)),
      ];
    };

    await message.reply({
      content: `🔥 **بدأت لعبة هوت اكس او!** الدور على <@${currentPlayer}> (${playerSymbols[currentPlayer]})\n📜 حقوق البوت: .h_4s`,
      components: displayBoard(),
    });

    const filter = i => i.customId.startsWith('hotxo_') && players.includes(i.user.id);
    const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      if (i.user.id !== currentPlayer) {
        return i.reply({ content: '❌ **ليس دورك!**', ephemeral: true });
      }

      const position = parseInt(i.customId.split('_')[1]);
      board[position] = playerSymbols[i.user.id];
      db.gameStates[message.channel.id].board = board;

      if (checkWin(board, playerSymbols[i.user.id])) {
        db.gameStates[message.channel.id].winner = i.user.id;
        db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 7;
        await saveDatabase();
        collector.stop();
        return i.update({
          content: `🏆 **فاز <@${i.user.id}> بلعبة هوت اكس او!** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`,
          components: [],
        });
      }

      if (!board.includes('⬜')) {
        db.gameStates[message.channel.id].winner = 'tie';
        await saveDatabase();
        collector.stop();
        return i.update({
          content: `🤝 **انتهت اللعبة بالتعادل!**\n📜 حقوق البوت: .h_4s`,
          components: [],
        });
      }

      const currentIndex = players.indexOf(currentPlayer);
      currentPlayer = players[(currentIndex + 1) % players.length];
      db.gameStates[message.channel.id].currentPlayer = currentPlayer;
      await saveDatabase();

      await i.update({
        content: `🔥 **الدور على <@${currentPlayer}> (${playerSymbols[currentPlayer]})**\n📜 حقوق البوت: .h_4s`,
        components: displayBoard(),
      });
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await message.channel.send({
          content: `⏰ **انتهى وقت لعبة هوت اكس او!** جربوا مرة أخرى.\n📜 حقوق البوت: .h_4s`,
          components: [],
        });
      }
    });
  },
};