const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const words = ['كرة', 'قلم', 'شجرة', 'مفتاح', 'ساعة'];
    const word = args[0] || words[Math.floor(Math.random() * words.length)];
    db.gameStates[message.channel.id] = { game: 'ريبلكا', word, attempts: [], winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('submit_replica').setLabel('أرسل إجابتك').setStyle(ButtonStyle.Primary).setEmoji('🔄')
    );

    await message.reply({
      content: `🔄 **لعبة ريبلكا!** كرر الكلمة "${word}" بطريقة إبداعية. اكتب !إجابة [جوابك]\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = m => m.content.startsWith('!إجابة') && m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000 });

    collector.on('collect', async (m) => {
      const attempt = m.content.split(' ').slice(1).join(' ');
      db.gameStates[message.channel.id].attempts.push({ user: m.author.id, attempt });
      await saveDatabase();
      if (attempt.toLowerCase().includes(word.toLowerCase())) {
        db.gameStates[message.channel.id].winner = m.author.id;
        db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 3;
        await saveDatabase();
        collector.stop();
        await m.reply(`🏆 **مبروك <@${m.author.id}>! إجابتك رائعة: ${attempt}** 🎉 النقاط: ${db.scores[m.author.id]}\n📜 حقوق البوت: CS`);
      } else {
        await m.reply(`❌ **إجابتك لا تحتوي على "${word}"!** حاول مرة أخرى.\n📜 حقوق البوت: CS`);
      }
    });
  },
};