const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const colors = [
      { emoji: '🔴', name: 'أحمر' },
      { emoji: '🟢', name: 'أخضر' },
      { emoji: '🔵', name: 'أزرق' },
      { emoji: '🟡', name: 'أصفر' },
      { emoji: '⚪', name: 'أبيض' },
    ];
    const selected = colors[Math.floor(Math.random() * colors.length)];
    const wrongAnswers = colors.filter(c => c.name !== selected.name).sort(() => Math.random() - 0.5).slice(0, 3).map(c => c.name);
    const options = [selected.name, ...wrongAnswers].sort(() => Math.random() - 0.5);
    db.gameStates[message.channel.id] = { game: 'ألوان', color: selected.emoji, answer: selected.name, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      options.map(opt =>
        new ButtonBuilder()
          .setCustomId(`color_${opt}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Primary)
      )
    );

    await message.reply({
      content: `🎨 **خمن اسم اللون!** ${selected.emoji}\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = (i) => i.customId.startsWith('color_') && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', async (i) => {
      const choice = i.customId.split('_')[1];
      db.gameStates[message.channel.id].winner = choice === selected.name ? i.user.id : null;
      if (choice === selected.name) {
        db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 3;
      }
      await saveDatabase();
      await i.update({
        content: choice === selected.name
          ? `🏆 **مبروك <@${i.user.id}>! الإجابة صحيحة: ${selected.name}** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`
          : `❌ **الإجابة خاطئة!** الإجابة الصحيحة: ${selected.name}\n📜 حقوق البوت: .h_4s`,
        components: [],
      });
      collector.stop();
    });
  },
};
