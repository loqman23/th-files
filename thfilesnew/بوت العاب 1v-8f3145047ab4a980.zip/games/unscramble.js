const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const words = ['كتاب', 'قلم', 'مدرسة', 'سيارة', 'بيت'];
    const word = words[Math.floor(Math.random() * words.length)];
    const scrambled = word.split('').sort(() => Math.random() - 0.5).join('');
    db.gameStates[message.channel.id] = { game: 'فكك', word, scrambled, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('answer_unscramble').setLabel('أرسل الإجابة').setStyle(ButtonStyle.Primary).setEmoji('🔠')
    );

    await message.reply({
      content: `🔠 **فكك الكلمة!**\nالكلمة المشوشة: **${scrambled}**\nاكتب !إجابة [جوابك]\n📜 حقوق البوت: .h_4s`,
      components: [row],
    });

    const filter = m => m.content.startsWith('!إجابة') && m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000 });

    collector.on('collect', async (m) => {
      const answer = m.content.split(' ').slice(1).join(' ').toLowerCase();
      if (answer === word.toLowerCase()) {
        db.gameStates[message.channel.id].winner = m.author.id;
        db.scores[m.author.id] = (db.scores[m.author.id] || 0) + 3;
        await saveDatabase();
        collector.stop();
        await m.reply(`🏆 **مبروك <@${m.author.id}>! الإجابة صحيحة: ${word}** 🎉 النقاط: ${db.scores[m.author.id]}\n📜 حقوق البوت: CS`);
      } else {
        await m.reply(`❌ **الإجابة خاطئة!** حاول مرة أخرى.\n📜 حقوق البوت: CS`);
      }
    });
  },
};