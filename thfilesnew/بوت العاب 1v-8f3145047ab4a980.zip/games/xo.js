const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    if (!message.mentions.users.size) {
      return message.reply('❌ **منشن لاعب آخر للعب اكس او!**');
    }
    const opponent = message.mentions.users.first();
    const board = Array(9).fill('⬜');
    let currentPlayer = message.author.id;
    let currentSymbol = '❌';
    db.gameStates[message.channel.id] = { game: 'اكس_او', board, currentPlayer, opponent: opponent.id, winner: null };
    await saveDatabase();

    const checkWin = (board, symbol) => {
      const winConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
        [0, 4, 8], [2, 4, 6], // Diagonals
      ];
      return winConditions.some(condition =>
        condition.every(index => board[index] === symbol)
      );
    };

    const displayBoard = () => {
      const buttons = board.map((cell, i) => 
        new ButtonBuilder()
          .setCustomId(`xo_${i}`)
          .setLabel(cell)
          .setStyle(cell === '⬜' ? ButtonStyle.Secondary : cell === '❌' ? ButtonStyle.Danger : ButtonStyle.Success)
          .setDisabled(cell !== '⬜')
      );
      return [
        new ActionRowBuilder().addComponents(buttons.slice(0, 3)),
        new ActionRowBuilder().addComponents(buttons.slice(3, 6)),
        new ActionRowBuilder().addComponents(buttons.slice(6, 9)),
      ];
    };

    await message.reply({
      content: `❌⭕ **بدأت لعبة اكس او!** الدور على <@${currentPlayer}> (${currentSymbol})\n📜 حقوق البوت: CS`,
      components: displayBoard(),
    });

    const filter = (i) => i.customId.startsWith('xo_') && (i.user.id === message.author.id || i.user.id === opponent.id);
    const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (i) => {
      if (i.user.id !== currentPlayer) {
        return i.reply({ content: '❌ **ليس دورك!**', ephemeral: true });
      }

      const position = parseInt(i.customId.split('_')[1]);
      board[position] = currentSymbol;
      db.gameStates[message.channel.id].board = board;

      if (checkWin(board, currentSymbol)) {
        db.gameStates[message.channel.id].winner = i.user.id;
        db.scores[i.user.id] = (db.scores[i.user.id] || 0) + 5; // مكافأة 5 نقاط
        await saveDatabase();
        collector.stop();
        return i.update({
          content: `🏆 **فاز <@${i.user.id}> بلعبة اكس او!** 🎉 النقاط: ${db.scores[i.user.id]}\n📜 حقوق البوت: .h_4s`,
          components: [],
        });
      }

      if (!board.includes('⬜')) {
        db.gameStates[message.channel.id].winner = 'tie';
        await saveDatabase();
        collector.stop();
        return i.update({
          content: `🤝 **انتهت اللعبة بالتعادل!**\n📜 حقوق البوت: CS`,
          components: [],
        });
      }

      currentPlayer = currentPlayer === message.author.id ? opponent.id : message.author.id;
      currentSymbol = currentSymbol === '❌' ? '⭕' : '❌';
      db.gameStates[message.channel.id].currentPlayer = currentPlayer;
      await saveDatabase();

      await i.update({
        content: `❌⭕ **الدور على <@${currentPlayer}> (${currentSymbol})**\n📜 حقوق البوت: CS`,
        components: displayBoard(),
      });
    });
  },
};