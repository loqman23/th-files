const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  execute: async (message, args, db, saveDatabase, client) => {
    const numbers = Array.from({ length: 37 }, (_, i) => i);
    const result = numbers[Math.floor(Math.random() * numbers.length)];
    const color = result === 0 ? '🟢' : result % 2 === 0 ? '🔴' : '⚫';
    db.gameStates[message.channel.id] = { game: 'روليت', lastResult: `${color} ${result}`, winner: null };
    await saveDatabase();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('play_roulette').setLabel('العب مرة أخرى').setStyle(ButtonStyle.Primary).setEmoji('🎰')
    );

    await message.reply({
      content: `🎰 **الروليت تدور...** والنتيجة: **${color} ${result}**\n📜 حقوق البوت: CS`,
      components: [row],
    });

    const filter = (i) => i.customId === 'play_roulette' && i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (i) => {
      const newResult = numbers[Math.floor(Math.random() * numbers.length)];
      const newColor = newResult === 0 ? '🟢' : newResult % 2 === 0 ? '🔴' : '⚫';
      db.gameStates[message.channel.id].lastResult = `${newColor} ${newResult}`;
      await saveDatabase();
      await i.update({
        content: `🎰 **الروليت تدور...** والنتيجة: **${newColor} ${newResult}**\n📜 حقوق البوت: .h_4s`,
        components: [row],
      });
    });
  },
};