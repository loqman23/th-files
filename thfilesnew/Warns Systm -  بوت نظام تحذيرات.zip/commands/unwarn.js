const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '..', 'warns.json');

function load() {
    if (!fs.existsSync(file)) return {};
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data);
}

function save(data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 4));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unwarn')
        .setDescription('إزالة تحذير من عضو')
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
        .addUserOption(option =>
            option.setName('user')
                .setDescription('العضو اللي عايز تشيل تحذيره')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('list')
                .setDescription('رقم التحذير اللي عايز تشيله')
                .setRequired(true)),
    
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const list = interaction.options.getInteger('list') - 1;

        const data = load();

        if (!data[interaction.guild.id] || !data[interaction.guild.id][user.id] || data[interaction.guild.id][user.id].length === 0) {
            return interaction.reply({ content: `لا يوجد تحذيرات لـ ${user.tag}`, ephemeral: true });
        }

        const warns = data[interaction.guild.id][user.id];

        if (list < 0 || list >= warns.length) {
            return interaction.reply({ content: `الرقم اللي دخلته مش موجود`, ephemeral: true });
        }

        const removed = warns.splice(list, 1);
        save(data);

        await interaction.reply({ content: `تم إزالة التحذير رقم ${list + 1} لـ ${user.tag}\n**السبب:** ${removed[0].reason}`, ephemeral: false })
            user.send(`تم إزالة تحذير رقم ${list + 1} في سيرفر **${interaction.guild.name}** بواسطة **${interaction.user.tag}**
**السبب:** ${removed[0].reason}
`).catch(() => {
                interaction.followUp({ content: 'ماقدرتش ابعتله رسالة في الخاص', ephemeral: true });
            });
        
    },
};
