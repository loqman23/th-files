const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('اوامر البوت البسيطه'),
    async execute(interaction) {
        await interaction.reply({
            content: `
اوامر البوت بسيطه وسهله :
- /warn <user> <reason> : لتحذير عضو مع ذكر السبب
- /warns <user> : لعرض تحذيرات عضو معين
- /warnslist : لعرض كل الاعضاء وعدد التحذيرات الخاصة بهم
- /unwarn <user> <list> : لإزالة تحذير من عضو مع ذكر رقم التحذير
            `});
    },
};
