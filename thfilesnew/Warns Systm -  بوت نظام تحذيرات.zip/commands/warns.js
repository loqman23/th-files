const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '..', 'warns.json');

function load() {
    if (!fs.existsSync(file)) return {};
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data);
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warns')
        .setDescription('عرض كل التحذيرات الخاصة بعضو')
        .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers)
        .addUserOption(option =>
            option.setName('user')
                .setDescription('العضو اللي عايز تشوف تحذيراته')
                .setRequired(true)),
    
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const data = load();

        if (!data[interaction.guild.id] || !data[interaction.guild.id][user.id] || data[interaction.guild.id][user.id].length === 0) {
            return interaction.reply({ content: `لا يوجد تحذيرات لـ ${user.tag}`, ephemeral: true });
        }

        const warns = data[interaction.guild.id][user.id];
        let description = '';
warns.forEach((warn, index) => {
    const time = Math.floor(new Date(warn.date).getTime() / 1000);
    description += `
**${index + 1}.** ${warn.reason} — بواسطة <@${warn.moderatorId}> في 
- <t:${time}:R>\n`;
});


        await interaction.reply({ content: `تحذيرات ${user.tag}:\n${description}`, ephemeral: false });
    },
};
