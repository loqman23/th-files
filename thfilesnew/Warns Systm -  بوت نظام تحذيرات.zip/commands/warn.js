const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '..', 'warns.json');

function load() {
    if (!fs.existsSync(file)) return {};
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data);
}

function save(data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 4));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('تحذير عضو مع سبب')
        .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers)
        .addUserOption(option =>
            option.setName('user')
                .setDescription('العضو اللي عايز تحذره')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب التحذير')
                .setRequired(true)),

    async execute(interaction) {
        const user = interaction.options.getUser('user');
        
        if (user.id === interaction.user.id) {
            return interaction.reply({ content: 'ماينفعش تحذر نفسك', ephemeral: true });
        }
        if (user.id === interaction.guild.ownerId) {
            return interaction.reply({ content: 'ماينفعش تحذر صاحب السيرفر', ephemeral: true });
        }
        
        if (user.bot) {
            return interaction.reply({ content: 'ماينفعش تحذر بوت', ephemeral: true });
        }
        const reason = interaction.options.getString('reason');
        const data = load();
        if (!data[interaction.guild.id]) data[interaction.guild.id] = {};

        if (!data[interaction.guild.id][user.id]) data[interaction.guild.id][user.id] = [];
        data[interaction.guild.id][user.id].push({
            moderatorId: interaction.user.id,
            reason: reason,
            date: new Date().toISOString()
        });
        save(data);

        await interaction.reply({content: `
${user.tag} تم تحذير هذا العضو
**السبب:** ${reason}
`, ephemeral: false})
 user.send({content:`تم تحذيرك في سيرفر **${interaction.guild.name}** بواسطة **${interaction.user.tag}**
**السبب:** ${reason}
`}).catch(() => {
            interaction.followUp({ content: 'ماقدرتش ابعتله رسالة في الخاص', ephemeral: true });
        })
 
},
};
