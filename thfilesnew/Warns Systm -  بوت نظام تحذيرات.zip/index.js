
//متلمسش اي حاجه تحت هنا
const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { token, id } = require('./config.json');
const client = new Client({ intents: [GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers] });

client.commands = new Collection();
const commands = [];

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);

    if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
        commands.push(command.data.toJSON());
        console.log(`✅ ${command.data.name}`);
    }
}

const rest = new REST({ version: '10' }).setToken(token);
(async () => {
    try {
        await rest.put(
            Routes.applicationCommands(id),
            { body: commands },
        );
    } catch (error) {
        console.error(error);
    }
})();


client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});


client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);

    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(`❌ ${interaction.commandName}`, error);
    }
});



client.login(token);
