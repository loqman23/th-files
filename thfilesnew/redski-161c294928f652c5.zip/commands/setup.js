
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('إرسال بانل المنتجات'),

    async execute(interaction) {
        const products = JSON.parse(fs.readFileSync('./data/products.json', 'utf8'));
        const embed = new EmbedBuilder()
            .setTitle('متجر المنتجات')
            .setDescription('اضغط على الأزرار لشراء المنتج')
            .setColor(0x00AE86);

        const row = new ActionRowBuilder();
        products.forEach(product => {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`buy_${product.id}`)
                    .setLabel(`${product.name} - ${product.price} ريال`)
                    .setStyle(ButtonStyle.Primary)
            );
        });

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
