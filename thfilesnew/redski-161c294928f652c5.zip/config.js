module.exports = {
    token: 'YOUR_BOT_TOKEN_HERE',
    guildId: 'YOUR_GUILD_ID_HERE',
    supportRoleId: 'SUPPORT_ROLE_ID_HERE'
};
