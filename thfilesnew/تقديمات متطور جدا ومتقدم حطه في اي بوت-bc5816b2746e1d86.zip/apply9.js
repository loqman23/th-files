const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

const fs = require('fs');

const path = require('path');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('list-applies')

    .setDescription('يعرض جميع عناوين ملفات التقديم المحفوظة لهذا السيرفر')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {

    const folderPath = path.join(__dirname, '../../data/apply');

    const guildId = interaction.guildId;

    const files = fs.readdirSync(folderPath).filter(file => file.startsWith(guildId));

    if (files.length === 0) {

      return interaction.reply({ content: 'لا توجد ملفات تقديم محفوظة لهذا السيرفر.', ephemeral: true });

    }

    let list = '';

    let count = 1;

    for (const file of files) {

      const filePath = path.join(folderPath, file);

      try {

        const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

        list += `\`${count++}.\` **${data.title || 'عنوان غير معروف'}**\n`;

      } catch (err) {

        list += `\`${count++}.\` (ملف تالف: ${file})\n`;

      }

    }

    const embed = new EmbedBuilder()

      .setTitle(`قائمة عناوين التقديمات`)

      .setDescription(list)

      .setColor('#3498db')

      .setFooter({ text: `عدد الملفات: ${files.length}` });

    await interaction.reply({ embeds: [embed], ephemeral: true });

  }

};