// events/interactionCreate.js

module.exports = {

  name: 'interactionCreate',

  async execute(interaction) {

    if (!interaction.isStringSelectMenu()) return;

    if (interaction.customId === 'off-apply') {

      return interaction.reply({

        content: '❗ التقديم مقفل لا يمكنك التقديم حالياً.',

        ephemeral: true

      });

    }

    // باقي التفاعلات الخاصة بـ Select Menus...

  }

};