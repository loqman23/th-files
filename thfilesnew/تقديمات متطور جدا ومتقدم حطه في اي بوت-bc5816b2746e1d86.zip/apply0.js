const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

const fs = require('fs');

const path = require('path');

const applyFolderPath = path.join(__dirname, '../../data/apply');

const choices = [];

if (fs.existsSync(applyFolderPath)) {

  const files = fs.readdirSync(applyFolderPath).filter(file => file.endsWith('.json'));

  for (const file of files) {

    const filePath = path.join(applyFolderPath, file);

    const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    choices.push([`${content.title}`, file]); // [name, value]

  }

}

module.exports = {

  data: new SlashCommandBuilder()

    .setName('send-apply')

    .setDescription('إرسال تقديم محفوظ')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addStringOption(opt =>

      opt.setName('apply')

        .setDescription('اختر التقديم المراد إرساله')

        .setRequired(true)

        .addChoices(

          ...choices.map(([title, filename]) => ({ name: title, value: filename }))

        )

    ),

  async execute(interaction) {

    const selectedFile = interaction.options.getString('apply');

    const filePath = path.join(applyFolderPath, selectedFile);

    if (!fs.existsSync(filePath)) {

      return interaction.reply({ content: 'حدث خطأ: الملف غير موجود.', ephemeral: true });

    }

    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    const embed = new EmbedBuilder()

      .setTitle(data.title)

      .setDescription(data.description)

      .setColor('#000000')

      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

    if (data.image) embed.setImage(data.image);

    const options = data.buttonNames.map((name, index) => ({

      label: name,

      value: `apply_button_${index + 1}`

    }));

    const row = new ActionRowBuilder().addComponents(

      new StringSelectMenuBuilder()

        .setCustomId(data.customId || 'apply_select')

        .setPlaceholder('اختر نوع التقديم')

        .addOptions(options)

    );

    await interaction.reply({ content: 'تم الإرسال بنجاح!', ephemeral: true });

    await interaction.channel.send({ embeds: [embed], components: [row] });

  }

};

