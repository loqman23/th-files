const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {

data: new SlashCommandBuilder()

.setName('apply')  

.setDescription('إرسال نموذج تقديم')  

.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)  

.addStringOption(opt => opt.setName('title').setDescription('عنوان الرسالة').setRequired(true))  

.addStringOption(opt => opt.setName('description').setDescription('وصف الرسالة').setRequired(true))  

.addStringOption(opt => opt.setName('apply').setDescription('عدد الأزرار: apply1 إلى apply4').setRequired(true)  

  .addChoices(  

    { name: 'apply1', value: '1' },  

    { name: 'apply2', value: '2' },  

    { name: 'apply3', value: '3' },  

    { name: 'apply4', value: '4' }  

  ))  

.addChannelOption(opt => opt.setName('log1').setDescription('روم تسجيل التقديمات').addChannelTypes(ChannelType.GuildText).setRequired(true))  

.addChannelOption(opt => opt.setName('log2').setDescription('روم تسجيل القبول/الرفض').addChannelTypes(ChannelType.GuildText).setRequired(true))  

.addRoleOption(opt => opt.setName('blacklistrole').setDescription('رتبة البلاك ليست').setRequired(true))  

.addRoleOption(opt => opt.setName('role').setDescription('رتبة يتم إعطاؤها عند القبول').setRequired(true))  

.addStringOption(opt => opt.setName('q1').setDescription('سؤال 1').setRequired(true))  

.addStringOption(opt => opt.setName('q2').setDescription('سؤال 2').setRequired(true))  

.addStringOption(opt => opt.setName('q3').setDescription('سؤال 3').setRequired(true))  

.addStringOption(opt => opt.setName('q4').setDescription('سؤال 4').setRequired(true))  

.addStringOption(opt => opt.setName('q5').setDescription('سؤال 5').setRequired(true))  

.addStringOption(opt => opt.setName('image-message').setDescription('رابط صورة (اختياري)'))  

.addStringOption(opt => opt.setName('name-button1').setDescription('اسم الزر 1 (اختياري)'))  

.addStringOption(opt => opt.setName('name-button2').setDescription('اسم الزر 2 (اختياري)'))  

.addStringOption(opt => opt.setName('name-button3').setDescription('اسم الزر 3 (اختياري)'))  

.addStringOption(opt => opt.setName('name-button4').setDescription('اسم الزر 4 (اختياري)')),

async execute(interaction) {

const fs = require('fs');  

const path = require('path');  

const {  

  EmbedBuilder,  

  ActionRowBuilder,  

  StringSelectMenuBuilder,  

  ComponentType  

} = require('discord.js');  

const title = interaction.options.getString('title');  

const description = interaction.options.getString('description');  

const applyCount = parseInt(interaction.options.getString('apply'));  

const log1 = interaction.options.getChannel('log1');  

const log2 = interaction.options.getChannel('log2');  

const blacklistRole = interaction.options.getRole('blacklistrole');  

const applyRole = interaction.options.getRole('role');  

const image = interaction.options.getString('image-message') || null;  

const q1 = interaction.options.getString('q1');  

const q2 = interaction.options.getString('q2');  

const q3 = interaction.options.getString('q3');  

const q4 = interaction.options.getString('q4');  

const q5 = interaction.options.getString('q5');  

const buttonNames = [  

  interaction.options.getString('name-button1') || 'تقديم 📲',  

  interaction.options.getString('name-button2') || 'تقديم 📲',  

  interaction.options.getString('name-button3') || 'تقديم 📲',  

  interaction.options.getString('name-button4') || 'تقديم 📲',  

];  

const serverName = interaction.guild.name;  

const serverIcon = interaction.guild.iconURL();  

const embed = new EmbedBuilder()  

  .setTitle(title)  

  .setDescription(description)  

  .setColor('#000000')  

  .setFooter({ text: serverName, iconURL: serverIcon });  

if (image) embed.setImage(image);  

const menuOptions = [];  

for (let i = 0; i < applyCount; i++) {  

  menuOptions.push({  

    label: buttonNames[i],  

    value: `apply_button_${i + 1}`  

  });  

}  

const row = new ActionRowBuilder()  

  .addComponents(new StringSelectMenuBuilder()  

    .setCustomId('apply_select')  

    .setPlaceholder('اختر نوع التقديم')  

    .addOptions(menuOptions)  

  );  

await interaction.reply({ embeds: [embed], components: [row] });  

  

// حفظ الإعدادات للزر في ملف خاص بالسيرفر  

const applyConfig = {  

  guildId: interaction.guildId,  

  channelId: interaction.channelId,  

  createdBy: interaction.user.id,  

  title,  

  description,  

  image,  

  applyCount,  

  questions: [q1, q2, q3, q4, q5],  

  log1: log1.id,  

  log2: log2.id,  

  blacklistRole: blacklistRole.id,  

  role: applyRole.id,  

  buttonNames: buttonNames.slice(0, applyCount),  

};  

const configPath = path.join(__dirname, '../../data/apply', `${interaction.guildId}_${Date.now()}.json`);  

fs.writeFileSync(configPath, JSON.stringify(applyConfig, null, 2));

}

};

