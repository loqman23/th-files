const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const fs = require('fs');

const path = require('path');

const applyFolder = path.join(__dirname, '../../data/apply');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('enable-apply')

    .setDescription('إعادة تفعيل تقديم محدد')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addStringOption(option => {

      const choices = [];

      if (fs.existsSync(applyFolder)) {

        for (const file of fs.readdirSync(applyFolder)) {

          const filePath = path.join(applyFolder, file);

          const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

          choices.push([content.title, file]);

        }

      }

      return option

        .setName('apply')

        .setDescription('اختر التقديم الذي تريد تفعيله')

        .setRequired(true)

        .addChoices(...choices.map(([title, file]) => ({ name: title, value: file })));

    }),

  async execute(interaction) {

    const file = interaction.options.getString('apply');

    const filePath = path.join(applyFolder, file);

    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    data.customId = 'apply_select';

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

    await interaction.reply({

      content: 'تم تفعيل التقديم بنجاح! الآن يمكنك استخدام أمر /send-apply لإعادة إرساله.',

      ephemeral: true

    });

  }

};

