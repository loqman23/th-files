const {

  ModalBuilder,

  TextInputBuilder,

  TextInputStyle,

  ActionRowBuilder,

  EmbedBuilder,

  StringSelectMenuBuilder,

  InteractionType,

  Events

} = require('discord.js');

const fs = require('fs');

const path = require('path');

module.exports = {

  name: Events.InteractionCreate,

  async execute(interaction) {

    const applyDir = path.join(__dirname, '../data/apply');

    // 1) عند اختيار نوع التقديم

    if (interaction.isStringSelectMenu() && interaction.customId === 'apply_select') {

    



      // جلب جميع ملفات الإعداد للسيرفر

      const configs = fs.readdirSync(applyDir)

        .filter(f => f.startsWith(interaction.guildId))

        .map(f => JSON.parse(fs.readFileSync(path.join(applyDir, f), 'utf-8')));


      // اختيار الإعداد بناءً على القناة التي نُفذ فيها الأمر

      const config = configs.find(c => c.channelId === interaction.channelId);

      if (!config) return;
      
      if (config.blacklistRole) {

    const role = interaction.guild.roles.cache.get(config.blacklistRole);

    if (interaction.member.roles.cache.has(role.id)) {

      return interaction.reply({ content: 'عذراً، أنت في البلاك ليست لا تستطيع التقديم 🔴', ephemeral: true });

    }

  }



      // بناء المودال

      const modal = new ModalBuilder()

        .setCustomId(`apply_modal_${interaction.user.id}_${Date.now()}`)

        .setTitle('نموذج التقديم');

      config.questions.forEach((q, i) => {

        modal.addComponents(

          new ActionRowBuilder().addComponents(

            new TextInputBuilder()

              .setCustomId(`q${i + 1}`)

              .setLabel(q)

              .setStyle(TextInputStyle.Paragraph)

              .setRequired(true)

          )

        );

      });

      return await interaction.showModal(modal);

    }

    // 2) عند إرسال المودال

    if (interaction.type === InteractionType.ModalSubmit && interaction.customId.startsWith('apply_modal_')) {

      const [, , userId, timestamp] = interaction.customId.split('_');

      if (interaction.user.id !== userId) {

        return await interaction.reply({ content: 'هذا النموذج ليس لك.', ephemeral: true });

      }

      // جلب نفس ملف الإعداد بناءً على القناة الأصلية

      const configs = fs.readdirSync(applyDir)

        .filter(f => f.startsWith(interaction.guildId))

        .map(f => JSON.parse(fs.readFileSync(path.join(applyDir, f), 'utf-8')));

      const config = configs.find(c => c.channelId === interaction.channelId);

      if (!config) return;

      // جمع الإجابات

      const answers = config.questions.map((_, i) => interaction.fields.getTextInputValue(`q${i + 1}`));

      // بناء إيمبد التقديم وإرساله إلى log1

      const embed = new EmbedBuilder()

        .setTitle('طلب تقديم جديد')

        .setColor('#00ff00')

        .setThumbnail(interaction.user.displayAvatarURL())

        .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })

        .setTimestamp();

      config.questions.forEach((q, i) => {

        embed.addFields({ name: q, value: answers[i] });

      });

      const row = new ActionRowBuilder().addComponents(

        new StringSelectMenuBuilder()

          .setCustomId(`apply_result_${userId}_${timestamp}`)

          .setPlaceholder('اختر الإجراء')

          .addOptions([

            { label: 'قبول ✅', value: `accept_${userId}_${timestamp}` },

            { label: 'رفض ❌', value: `reject_${userId}_${timestamp}` },

            { label: 'بلاكليست ⛔', value: `blacklist_${userId}_${timestamp}` }

          ])

      );

      const log1 = interaction.guild.channels.cache.get(config.log1);

      if (log1) await log1.send({ embeds: [embed], components: [row] });

      return await interaction.reply({ content: 'تم إرسال تقديمك بنجاح، سيتم مراجعته قريبًا.', ephemeral: true });

    }

    // 3) عند اختيار نتيجة التقديم

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('apply_result_')) {

      // تفكيك الإجراء ومعرّف المستخدم والزمن

      const [action, userId, timestamp] = interaction.values[0].split('_');

      // جلب ملف الإعداد بناءً على قناة log1

      const configs = fs.readdirSync(applyDir)

        .filter(f => f.startsWith(interaction.guildId))

        .map(f => JSON.parse(fs.readFileSync(path.join(applyDir, f), 'utf-8')));

      const config = configs.find(c => c.log1 === interaction.channelId);

      if (!config) return;

      const targetMember = await interaction.guild.members.fetch(userId).catch(() => null);

      if (!targetMember) return await interaction.reply({ content: 'لا يمكن العثور على العضو.', ephemeral: true });

      // بناء إيمبد النتيجة

      const embed = new EmbedBuilder()

        .setTitle('نتيجة التقديم')

        .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })

        .setThumbnail(targetMember.displayAvatarURL())

        .setTimestamp();

      if (action === 'accept') {

        await targetMember.roles.add(config.role).catch(() => null);

        embed.setColor('#00ff00').setDescription(`**تم قبول ${targetMember} **`);

      } else if (action === 'reject') {

        embed.setColor('#ff0000').setDescription(`**تم رفض ${targetMember}**`);

      } else if (action === 'blacklist') {

        await targetMember.roles.add(config.blacklistRole).catch(() => null);

        embed.setColor('#000000').setDescription(`**تمت إضافة ${targetMember} إلى البلاكليست**`);

      }

      const log2 = interaction.guild.channels.cache.get(config.log2);

      if (log2) await log2.send({ embeds: [embed],content: `${targetMember}` });

      return interaction.reply({ content: 'تم تنفيذ الإجراء بنجاح.', ephemeral: true });

    }

  }

};

