import { CommandInteraction, SlashCommandBuilder } from "discord.js";

export default {
    data: new SlashCommandBuilder()
    .setName("test")
    .setDescription("hello world"),
    admin: true,
    run: async (interaction: CommandInteraction) => { 
        await interaction.reply('Pong!');
    }
};
