import { Command } from "components/newCommand";
import { SlashCommandBuilder } from "discord.js";

export default new Command ({
    data: new SlashCommandBuilder()
    .setName("panel")
    .setDescription("test"),
    admin: true,
    run: async (interaction) => {
        // logic
    }
})