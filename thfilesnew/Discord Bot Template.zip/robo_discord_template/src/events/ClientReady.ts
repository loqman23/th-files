import type { RoBoClient } from "@lib/Client";
import { Events, ActivityType } from "discord.js";
import { Logger } from "@lib/Logger";

export default {
    name: Events.ClientReady,
    once: true,
    async execute(client: RoBoClient) {
        Logger.success(`> Logged in as ${client.user?.tag}`);
        Logger.info(`> Bot ID: ${client.user?.id}`);

        client.user?.setPresence({
            status: "dnd",
            activities: [
                {
                    name: "Hello",
                    type: ActivityType.Playing,
                },
            ],
        });
    },
};
