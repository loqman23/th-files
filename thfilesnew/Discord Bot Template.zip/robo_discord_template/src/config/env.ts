import { Logger } from "@lib/Logger";
import dotenv from "dotenv";
import { z } from "zod";

dotenv.config();

const envSchema = z.object({
    DATABASE: z.string().min(1, "Missing DATABASE"),
    TOKEN: z.string().min(1, "Missing TOKEN"),
    CLIENT_ID: z.string().min(1, "Missing CLIENT_ID"),
    CLIENT_SECRET: z.string().min(1, "Missing CLIENT_SECRET"),
    NODE_ENV: z.string().min(1, "Need One of Pro and Dev")
});

const _env = envSchema.safeParse(process.env);

if (!_env.success) {
    console.error("❌ Invalid environment variables:", _env.error.format());
    process.exit(1);
}

export const ENV = _env.data;