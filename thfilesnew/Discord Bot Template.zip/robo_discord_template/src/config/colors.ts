export const color = {
    error: 0xFF4C4C,
    success: 0x4CAF50,
    info: 0x3498DB,
    warning: 0xFFC107,
    default: 0x5865F2,
};