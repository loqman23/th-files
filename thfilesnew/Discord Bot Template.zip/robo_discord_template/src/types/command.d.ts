import { 
    CommandInteraction, 
    SlashCommandBuilder,
    type SlashCommandSubcommandsOnlyBuilder
} from "discord.js"
import { RoBoClient } from "@lib/client"

interface CommandProps {
    data:
    | SlashCommandBuilder
    | SlashCommandSubcommandsOnlyBuilder
    | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">;
    admin?: boolean;
    run: (interaction: CommandInteraction, client: RoBoClient) => Promise<void>;
}
