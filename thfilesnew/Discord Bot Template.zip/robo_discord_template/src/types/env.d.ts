type Settings = {
    TOKEN?: string | undefined,
    DATABASE?: string | undefined,
    CLIENT_ID?: string,
    CLIENT_SECRET?: string,
}

interface envProps {
    ENV: Setting
}