const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '..', 'warns.json');

function load() {
    if (!fs.existsSync(file)) return {};
    const data = fs.readFileSync(file, 'utf8');
    return JSON.parse(data);
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warnslist')
        .setDescription('عرض كل الأعضاء وعدد التحذيرات الخاصة بهم')
        .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),

    async execute(interaction) {
        const data = load();
        if (!data[interaction.guild.id] || Object.keys(data[interaction.guild.id]).length === 0) {
            return interaction.reply({ content: 'لا يوجد أي تحذيرات في السيرفر', ephemeral: true });
        }

        const guild = data[interaction.guild.id];
        let desc = '';

        for (const userId of Object.keys(guild)) {
          const warnings = guild[userId];
            if (!warnings || warnings.length === 0) continue;
            const user = await interaction.guild.members.fetch(userId).catch(() => null);
            const username = user ? user.user.tag : `مش موجود (${userId})`;
            desc += `**${username}**: ${warnings.length} تحذيرات\n`;
        }

        if (desc === '') {
            return interaction.reply({ content: 'لا يوجد أي تحذيرات في السيرفر', ephemeral: true });
        }
        await interaction.reply({ content: `قائمة التحذيرات في السيرفر:\n${desc}`, ephemeral: false });
    },
};
