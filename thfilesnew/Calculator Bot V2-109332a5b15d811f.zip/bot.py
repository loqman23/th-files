import discord
from discord.ext import commands
import os
import json
from dotenv import load_dotenv

# تحميل بيانات env
load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')

# تحميل بيانات config.json
with open('config.json', 'r', encoding='utf-8') as f:
    config = json.load(f)

prefix = config.get("prefix")
bot_name = config.get("bot_name")

# إعداد البوت
intents = discord.Intents.default()
bot = commands.Bot(command_prefix=prefix, intents=intents)

@bot.event
async def on_ready():
    print(f"{bot_name} is now running as {bot.user}.")

@bot.command(name="calc", help="اكتب: !calc 2 + 2")
async def calculate(ctx, *, expression: str):
    try:
        # نحذف أي مسافات غير ضرورية
        expression = expression.replace(' ', '')
        # نحمي من الأكواد الخبيثة (مسموح بس العمليات الرياضية البسيطة)
        allowed_chars = "0123456789+-*/()."
        if any(c not in allowed_chars for c in expression):
            await ctx.send("🚫 المعادلة غير صالحة.")
            return

        result = eval(expression)
        await ctx.send(f"النتيجة: `{result}`")
    except:
        await ctx.send("⚠️ خطأ في المعادلة.")

bot.run(TOKEN)
