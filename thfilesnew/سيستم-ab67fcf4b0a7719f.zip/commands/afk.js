const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const afkFilePath = path.join(__dirname, 'data', 'afk.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('afk')
        .setDescription('Set AFK status with a reason')
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for being AFK')
                .setRequired(false)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: '❌ Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.afk;

        if (!commandSettings.enabled) {
            return reply({ content: '⛔ This command is currently disabled', ephemeral: true });
        }

        const user = interaction?.user || message?.author;
        const userId = user.id;
        const guild = interaction?.guild || message?.guild;

        const member = guild?.members.cache.get(userId);
        if (member) {
            if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
                member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
                return reply({ content: '🚫 You do not have permission to use this command', ephemeral: true });
            }

            if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
                !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
                return reply({ content: '🔒 This command is only available for certain roles', ephemeral: true });
            }
        }

        let reason;
        if (interaction) {
            reason = interaction.options.getString('reason');
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                reason = args.slice(1).join(' ');
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'afk' || commandSettings.aliases?.includes(commandName)) {
                    reason = args.slice(1).join(' ');
                }
            }
        }

        if (!fs.existsSync(afkFilePath)) {
            try {
                fs.writeFileSync(afkFilePath, JSON.stringify({}, null, 2));
            } catch (err) {
                return reply('❌ Error creating AFK file');
            }
        }

        let afkData = {};
        try {
            afkData = JSON.parse(fs.readFileSync(afkFilePath, 'utf8'));
        } catch (err) {
            console.error('❌ Error reading AFK file:', err);
        }

        if (reason || (isMessage && !afkData[userId])) {
            afkData[userId] = { 
                reason: reason || 'Not specified', 
                time: Date.now(),
                username: user.username
            };
            
            try {
                fs.writeFileSync(afkFilePath, JSON.stringify(afkData, null, 2));
                
                const embed = new EmbedBuilder()
                    .setColor('#FFA500')
                    .setDescription(`**${user.username}** is now AFK`)
                    .addFields(
                        { name: 'Reason', value: reason || 'Not specified', inline: true },
                        { name: 'Time', value: `<t:${Math.floor(Date.now()/1000)}:R>`, inline: true }
                    );
                
                return reply({ embeds: [embed] });
            } catch (err) {
                return reply('❌ Error saving AFK data');
            }
        } else {
            if (afkData[userId]) {
                const afkDuration = Math.floor((Date.now() - afkData[userId].time) / 1000);
                const durationString = formatDuration(afkDuration);
                
                delete afkData[userId];
                try {
                    fs.writeFileSync(afkFilePath, JSON.stringify(afkData, null, 2));
                    
                    const embed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setDescription(`**${user.username}** is no longer AFK`)
                        .addFields(
                            { name: 'AFK Duration', value: durationString, inline: true }
                        );
                    
                    return reply({ embeds: [embed] });
                } catch (err) {
                    return reply('❌ Error saving AFK data');
                }
            } else {
                return reply('You are not AFK.');
            }
        }
    },
};

function formatDuration(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    let duration = [];
    if (days > 0) duration.push(`${days} day${days > 1 ? 's' : ''}`);
    if (hours > 0) duration.push(`${hours} hour${hours > 1 ? 's' : ''}`);
    if (mins > 0) duration.push(`${mins} minute${mins > 1 ? 's' : ''}`);
    if (secs > 0 || duration.length === 0) duration.push(`${secs} second${secs !== 1 ? 's' : ''}`);
    
    return duration.join(' and ');
}