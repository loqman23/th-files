require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('Unmute a user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to unmute')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for unmute')
                .setRequired(false)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.unmute;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let targetUser, reason;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: false });
            targetUser = interaction.options.getUser('user');
            reason = interaction.options.getString('reason') || 'No reason provided';
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                targetUser = message.mentions.users.first();
                reason = args.slice(2).join(' ') || 'No reason provided';
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'unmute' || commandSettings.aliases?.includes(commandName)) {
                    targetUser = message.mentions.users.first();
                    reason = args.slice(2).join(' ') || 'No reason provided';
                }
            }
            
            if (!targetUser) {
                const usageExample = commandSettings.aliases?.[0] || 'unmute';
                return reply({ content: `❌ Please mention the user (example: ${usageExample} @user reason)` });
            }
        }

        const targetMember = interactionOrMessage.guild.members.cache.get(targetUser.id);

        if (!targetMember) {
            return reply({ content: '❌ User not found in server', ephemeral: true });
        }

        if (!targetMember.manageable) {
            return reply({ content: '❌ I cannot unmute this user. They may have higher permissions', ephemeral: true });
        }

        if (!targetMember.communicationDisabledUntilTimestamp) {
            return reply({ content: '❌ This user is not muted', ephemeral: true });
        }

        try {
            await targetMember.timeout(null);
            await reply({ content: `✅ Successfully unmuted **${targetUser}**` });

        } catch (error) {
            await reply({ content: '❌ Error while unmuting user', ephemeral: true });
        }
    }
};