const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, Colors } = require('discord.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a specific user from the server')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to ban')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('time')
                .setDescription('Ban duration in minutes (0 = permanent)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Ban reason')
                .setRequired(false)),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.ban;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let targetUser, banTime, reason;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: true });
            targetUser = interaction.options.getMember('user');
            banTime = interaction.options.getInteger('time');
            reason = interaction.options.getString('reason') || 'No reason provided';
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                targetUser = message.mentions.members.first();
                banTime = parseInt(args[2]) || 0;
                reason = args.slice(3).join(' ') || 'No reason provided';
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'ban' || commandSettings.aliases?.includes(commandName)) {
                    targetUser = message.mentions.members.first();
                    banTime = parseInt(args[2]) || 0;
                    reason = args.slice(3).join(' ') || 'No reason provided';
                }
            }
            
            if (!targetUser) {
                const usageExample = commandSettings.aliases?.[0] || 'ban';
                return reply({ content: `❌ Please mention a user (example: ${usageExample} @user 60 reason)` });
            }
        }

        if (!targetUser) {
            return reply({ content: '❌ Cannot find this user in the server' });
        }

        if (!targetUser.bannable) {
            return reply({ content: '❌ I cannot ban this user. Make sure my role is higher than theirs' });
        }

        try {
            await targetUser.ban({ reason });
            await reply({ content: `✅ Successfully banned ${targetUser}\n**Duration:** ${banTime} minutes\n**Reason:** ${reason}` });

            if (banTime > 0) {
                setTimeout(async () => {
                    try {
                        await interactionOrMessage.guild.members.unban(targetUser.id);
                    } catch (err) {
                        console.error('❌ Unban Error:', err);
                    }
                }, banTime * 60 * 1000);
            }
        } catch (error) {
            return reply({ content: '❌ An error occurred while trying to ban the user' });
        }
    }
};