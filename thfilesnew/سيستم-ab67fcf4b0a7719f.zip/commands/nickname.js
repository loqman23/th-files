const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nickname')
        .setDescription('Change a member\'s nickname')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Member to change nickname')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('nickname')
                .setDescription('New nickname (leave empty to reset)')
                .setRequired(false)
                .setMaxLength(32)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isSlashCommand ? null : interactionOrMessage;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.nickname;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let targetUser, newNickname;
        if (interaction) {
            targetUser = interaction.options.getUser('user');
            newNickname = interaction.options.getString('nickname');
        } else {
            const args = message.content.split(/\s+/).slice(1);
            if (args.length < 1) {
                return reply({ content: '❌ Invalid command format. Use: `nick @user nickname`', ephemeral: true });
            }
            
            targetUser = message.mentions.users.first();
            if (!targetUser) {
                return reply({ content: '❌ Please mention user correctly', ephemeral: true });
            }
            
            newNickname = args.slice(1).join(' ');
        }

        const targetMember = interaction?.guild?.members.cache.get(targetUser.id) || 
                            message?.guild?.members.cache.get(targetUser.id);

        if (!targetMember) {
            return reply({ content: '❌ Member not found in server', ephemeral: true });
        }

        if (!targetMember.manageable) {
            return reply({ content: '❌ Cannot modify this member\'s nickname (higher role)', ephemeral: true });
        }

        const oldNickname = targetMember.nickname || targetUser.username;

        try {
            await targetMember.setNickname(newNickname || null);

            const successEmbed = new EmbedBuilder()
                .setColor(Colors.Green)
                .setTitle('✅ Nickname changed successfully')
                .addFields(
                    { name: '👤 Member', value: targetUser.toString(), inline: true },
                    { name: '👮‍♂️ Changed by', value: user.toString(), inline: true },
                    { name: '📝 Old nickname', value: oldNickname || 'None', inline: false },
                    { name: '🆕 New nickname', value: newNickname || 'Reset to default', inline: false }
                )
                .setTimestamp();

            await reply({ embeds: [successEmbed] });

        } catch (error) {
            await reply({ 
                content: '❌ Error changing nickname. Check permissions!',
                ephemeral: true 
            });
        }
    }
};