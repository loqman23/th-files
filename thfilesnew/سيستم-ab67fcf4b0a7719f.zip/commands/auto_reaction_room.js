const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder } = require('discord.js');
require('dotenv').config();

const dataPath = path.join(__dirname, 'data', 'auto_reaction.json');
const ADMIN = process.env.ADMIN;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('auto_reaction_room')
        .setDescription('Add a channel to auto-reaction list')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to add')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        if (!interaction.member.roles.cache.has(ADMIN)) {
            return interaction.reply({ content: '❌ You do not have permission to use this command', ephemeral: true });
        }

        const channel = interaction.options.getChannel('channel');

        try {
            let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            if (data.channels.includes(channel.id)) {
                return interaction.reply({ content: '⚠️ This channel is already in the auto-reaction list', ephemeral: false });
            }

            data.channels.push(channel.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            interaction.reply({ content: `✅ ${channel} has been added to auto-reaction list`, ephemeral: false });
        } catch (error) {
            console.error('Error updating auto_reaction.json:', error);
            interaction.reply({ content: '❌ Failed to update auto-reaction list', ephemeral: false });
        }
    },
};