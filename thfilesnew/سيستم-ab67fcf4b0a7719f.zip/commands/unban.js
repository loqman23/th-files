const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a specific user')
        .addStringOption(option =>
            option.setName('user')
                .setDescription('ID of the user to unban')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for unban')
                .setRequired(false)),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.unban;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let userId, reason;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: true });
            userId = interaction.options.getString('user');
            reason = interaction.options.getString('reason') || 'No reason provided';
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                userId = args[1];
                reason = args.slice(2).join(' ') || 'No reason provided';
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'unban' || commandSettings.aliases?.includes(commandName)) {
                    userId = args[1];
                    reason = args.slice(2).join(' ') || 'No reason provided';
                }
            }
            
            if (!userId) {
                const usageExample = commandSettings.aliases?.[0] || 'unban';
                return reply({ content: `❌ Please provide user ID (example: ${usageExample} 123456789 reason)` });
            }
        }

        if (!/^\d+$/.test(userId)) {
            return reply({ content: '❌ User ID must contain only numbers' });
        }

        try {
            const bannedUsers = await interactionOrMessage.guild.bans.fetch();
            const bannedUser = bannedUsers.get(userId);

            if (!bannedUser) {
                return reply({ content: '❌ This user is not currently banned' });
            }

            await interactionOrMessage.guild.members.unban(userId, reason);
            await reply({ content: `✅ Successfully unbanned <@${userId}>\n**Reason:** ${reason}` });

        } catch (error) {
            return reply({ content: '❌ Error while trying to unban user' });
        }
    }
};