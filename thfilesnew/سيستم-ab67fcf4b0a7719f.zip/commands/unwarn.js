const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const warningsFilePath = path.join(__dirname, 'data', 'warning.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unwarn')
        .setDescription('Remove a warning from a user using warning ID')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to remove warning from')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('warning_id')
                .setDescription('Warning ID to remove (use /warning to view IDs)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for removing the warning')
                .setRequired(true)),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: '❌ Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.unwarn;

        if (!commandSettings.enabled) {
            return reply({ content: '⛔ This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const guild = interaction?.guild || message?.guild;

        if (!member || !channel || !guild) {
            return reply({ content: '❌ Cannot determine server information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: '🚫 You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: '🔒 This command is only available to specific roles', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: '📌 This command can only be used in specific channels', ephemeral: true });
        }

        let targetUser, warningId, reason;
        if (interaction) {
            targetUser = interaction.options.getUser('user');
            warningId = interaction.options.getString('warning_id');
            reason = interaction.options.getString('reason');
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias || args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].startsWith(process.env.PREFIX) ? 
                    args[0].slice(process.env.PREFIX.length).toLowerCase() : 
                    args[0].toLowerCase();
                
                if (commandName === 'unwarn' || commandSettings.aliases?.includes(commandName)) {
                    const mention = args[1];
                    if (!mention || !mention.startsWith('<@') || !mention.endsWith('>')) {
                        return reply({ 
                            content: '❌ Please mention the user to remove warning from', 
                            ephemeral: true 
                        });
                    }
                    
                    const userId = mention.replace(/[<@!>]/g, '');
                    try {
                        targetUser = await client.users.fetch(userId);
                    } catch (error) {
                        return reply({ 
                            content: '❌ Cannot find mentioned user', 
                            ephemeral: true 
                        });
                    }
                    
                    warningId = args[2];
                    reason = args.slice(3).join(' ') || 'Not specified';
                }
            }
        }

        if (!targetUser) {
            return reply({ 
                content: '❌ Please specify the user to remove warning from', 
                ephemeral: true 
            });
        }

        if (!warningId) {
            return reply({ 
                content: '❌ Please specify the warning ID to remove (use /warning to view IDs)', 
                ephemeral: true 
            });
        }

        if (!reason) {
            return reply({ 
                content: '❌ Please specify the reason for removing the warning', 
                ephemeral: true 
            });
        }

        const allowedRoleIds = process.env.STAFF?.split(',') || [];
        if (!member.permissions.has(PermissionsBitField.Flags.Administrator) &&
            !allowedRoleIds.some(roleId => member.roles.cache.has(roleId))) {
            return reply({ 
                content: '❌ You dont have permission to use this command', 
                ephemeral: true 
            });
        }

        let warningsData = {};
        if (fs.existsSync(warningsFilePath)) {
            try {
                warningsData = JSON.parse(fs.readFileSync(warningsFilePath, 'utf8'));
            } catch (error) {
                warningsData = {};
            }
        }

        if (!warningsData[targetUser.id] || warningsData[targetUser.id].length === 0) {
            return reply({ 
                content: `❌ User <@${targetUser.id}> has no warnings`, 
                ephemeral: true 
            });
        }

        const warningIndex = warningsData[targetUser.id].findIndex(w => w.id === warningId);
        if (warningIndex === -1) {
            return reply({ 
                content: `❌ No warning found with ID ${warningId} for user <@${targetUser.id}>`, 
                ephemeral: true 
            });
        }

        const removedWarning = warningsData[targetUser.id].splice(warningIndex, 1)[0];
        const remainingWarnings = warningsData[targetUser.id].length;

        try {
            fs.writeFileSync(warningsFilePath, JSON.stringify(warningsData, null, 4));
        } catch (error) {
            return reply({ 
                content: '❌ Error saving warnings data', 
                ephemeral: true 
            });
        }

        const successEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`
                ✅ Successfully removed warning from <@${targetUser.id}>
                **Warning ID:** ${warningId}
                **Reason:** ${reason}
                **Remaining warnings:** ${remainingWarnings}
            `)
            .setTimestamp();

        return reply({ 
            embeds: [successEmbed],
            ephemeral: false
        });
    },
};