const { SlashCommandBuilder, EmbedBuilder, ChatInputCommandInteraction } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('Show detailed user profile information')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User whose profile you want to view')
                .setRequired(false)),

    async execute(client, interactionOrMessage, args) {
        const settingsPath = path.join(__dirname, '..', 'setting.json');
        const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        const commandSettings = settings.commands.profile;

        const isSlashCommand = interactionOrMessage instanceof ChatInputCommandInteraction;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isSlashCommand ? null : interactionOrMessage;

        const respond = async (response) => {
            if (isSlashCommand) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(response);
                }
                return interaction.reply(response);
            }
            return message.reply(response);
        };

        if (!commandSettings.enabled) {
            return respond({ content: '⚠️ This command is currently disabled', ephemeral: true });
        }

        let targetUser;
        if (isSlashCommand) {
            targetUser = interaction.options.getUser('user') || interaction.user;
        } else {
            const mentionedUser = message.mentions.users.first();
            targetUser = mentionedUser || message.author;
        }

        let member;
        try {
            const guild = isSlashCommand ? interaction.guild : message.guild;
            member = await guild.members.fetch(targetUser.id);
        } catch (error) {
            return respond({ content: '❌ Error fetching member information', ephemeral: true });
        }

        if (!isSlashCommand) {
            const member = message.member;
            const channel = message.channel;

            if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
                member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
                return respond({ content: '⛔ You dont have permission to use this command' });
            }

            if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
                !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
                return respond({ content: '⛔ You dont have permission to use this command' });
            }

            if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
                !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
                return respond({ content: '🚫 This command cannot be used in this channel' });
            }
        }

        const profileEmbed = new EmbedBuilder()
            .setColor('#3498db')
            .setAuthor({
                name: targetUser.tag,
                iconURL: targetUser.displayAvatarURL({ dynamic: true }),
            })
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 1024 }))
            .setTitle('📄 User Profile')
            .addFields(
                { name: '👤 **Username**', value: targetUser.username, inline: true },
                { name: '🆔 **ID**', value: targetUser.id, inline: true },
                {
                    name: '📅 **Account Created**',
                    value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:F>`,
                    inline: false,
                },
                {
                    name: '📥 **Joined Server**',
                    value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`,
                    inline: false,
                },
                {
                    name: '🎭 **Highest Role**',
                    value: member.roles.highest.toString(),
                    inline: true,
                },
                {
                    name: '🔢 **Role Count**',
                    value: member.roles.cache.size.toString(),
                    inline: true,
                }
            )
            .setFooter({
                text: `Requested by ${isSlashCommand ? interaction.user.tag : message.author.tag}`,
                iconURL: (isSlashCommand ? interaction.user : message.author).displayAvatarURL({ dynamic: true }),
            })
            .setTimestamp();

        await respond({ embeds: [profileEmbed] });
    }
};