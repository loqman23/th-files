const { SlashCommandBuilder, EmbedBuilder, ChatInputCommandInteraction } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('Show user profile picture')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User whose avatar you want to see')
                .setRequired(false)),

    async execute(client, interactionOrMessage, args) {
        const isSlashCommand = interactionOrMessage instanceof ChatInputCommandInteraction;
        
        let targetUser;
        if (isSlashCommand) {
            targetUser = interactionOrMessage.options.getUser('user') || interactionOrMessage.user;
        } else {
            const mentionedUser = interactionOrMessage.mentions.users.first();
            targetUser = mentionedUser || interactionOrMessage.author;
        }

        const avatarEmbed = new EmbedBuilder()
            .setColor('Random')
            .setAuthor({
                name: `${targetUser.username}`,
                iconURL: targetUser.displayAvatarURL({ dynamic: true }),
            })
            .setTitle('🖼️ Profile Picture')
            .setDescription(`[Original Image Link](${targetUser.displayAvatarURL({ dynamic: true, size: 1024 })})`)
            .setImage(targetUser.displayAvatarURL({ dynamic: true, size: 1024 }))
            .setFooter({
                text: `Requested by ${isSlashCommand ? interactionOrMessage.user.username : interactionOrMessage.author.username}`,
                iconURL: (isSlashCommand ? interactionOrMessage.user : interactionOrMessage.author).displayAvatarURL({ dynamic: true }),
            })
            .setTimestamp();

        if (isSlashCommand) {
            await interactionOrMessage.reply({ embeds: [avatarEmbed] });
        } else {
            await interactionOrMessage.channel.send({ embeds: [avatarEmbed] });
        }
    },

    aliases: [],
    permissions: {},
};