require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add_giveaway')
        .setDescription('Create a new giveaway')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Giveaway title')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Giveaway duration (e.g. 6h, 2d, 30m)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('Number of winners')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('Prize description')
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to post giveaway in')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('host')
                .setDescription('Giveaway host'))
        .addStringOption(option =>
            option.setName('banner')
                .setDescription('Banner image URL (optional)'))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('Thumbnail image URL (optional)')),

    async execute(client, interaction) {
        const allowedRoleIds = process.env.ADMIN.split(',');

        const memberRoles = interaction.member.roles.cache;
        const hasPermission = allowedRoleIds.some(roleId => memberRoles.has(roleId));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: false,
            });
        }

        const name = interaction.options.getString('name');
        const duration = interaction.options.getString('duration');
        const winners = interaction.options.getInteger('winners');
        const prize = interaction.options.getString('prize');
        const channel = interaction.options.getChannel('channel');
        const host = interaction.options.getUser('host');
        const banner = interaction.options.getString('banner');
        const thumbnail = interaction.options.getString('thumbnail');

        const durationMs = parseDuration(duration);
        if (durationMs === null) {
            return await interaction.reply({ 
                content: '❌ Invalid duration format. Please use "h", "d" or "m" (e.g. 6h, 2d, 30m).', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle(`🎉 Giveaway: ${name}`)
            .setDescription(`
                **Prize:** ${prize}
                **Winners:** ${winners}
                **Ends In:** <t:${Math.floor((Date.now() + durationMs) / 1000)}:R>
                **Hosted By:** ${host ? host : 'Anonymous'}
            `)
            .setColor('Blue')
            .setFooter({ text: 'Click the button below to enter the giveaway' });

        if (banner) embed.setImage(banner);
        if (thumbnail) embed.setThumbnail(thumbnail);

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('giveaway_enter')
                    .setLabel('🎉 Enter')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('giveaway_participants')
                    .setLabel('📋 Participants')
                    .setStyle(ButtonStyle.Secondary)
            );

        try {
            const giveawayMessage = await channel.send({ embeds: [embed], components: [button] });

            const giveawayDataPath = path.join(__dirname, 'data', 'addgiveaway.json');
            const giveawayData = JSON.parse(fs.readFileSync(giveawayDataPath, 'utf-8') || '[]');

            const giveawayEntry = {
                id: giveawayMessage.id,
                participants: [],
                active: true,
                prize,
                winners,
                durationMs,
                channelId: channel.id,
                hostId: host ? host.id : null
            };

            giveawayData.push(giveawayEntry);
            fs.writeFileSync(giveawayDataPath, JSON.stringify(giveawayData, null, 2));

            await interaction.reply({
                content: `✅ Giveaway created successfully in channel: ${channel.name}!`,
                ephemeral: true,
            });

            const collector = giveawayMessage.createMessageComponentCollector({ time: durationMs });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'giveaway_enter') {
                    const user = interaction.user;
                    
                    if (giveawayEntry.participants.some(p => p.id === user.id)) {
                        return await interaction.reply({ 
                            content: '❌ You are already registered!', 
                            ephemeral: true 
                        });
                    }

                    giveawayEntry.participants.push({ username: user.username, id: user.id });
                    fs.writeFileSync(giveawayDataPath, JSON.stringify(giveawayData, null, 2));

                    await interaction.deferReply({ ephemeral: true });
                    await interaction.editReply({ content: '🎉 You have successfully entered!' });
                
                } else if (interaction.customId === 'giveaway_participants') {
                    await interaction.deferReply({ ephemeral: true });
                    await interaction.editReply({ 
                        content: `📋 Number of participants: ${giveawayEntry.participants.length}` 
                    });
                }
            });

            collector.on('end', async () => {
                try {
                    const giveawayMessage = await channel.messages.fetch(giveawayEntry.id);
                    if (!giveawayMessage) {
                        throw new Error("Message not found");
                    }
                    await giveawayMessage.edit({ components: [] });
            
                    const selectedWinners = getRandomWinners(giveawayEntry.participants, winners);
            
                    const winnerMentions = selectedWinners.map(winner => `<@${winner.id}>`).join(', ');
                    await channel.send(`🎉 **Giveaway ended!** 🎉\nWinners: ${winnerMentions}`);
            
                    for (const winner of selectedWinners) {
                        try {
                            const user = await client.users.fetch(winner.id);
                            await user.send({
                                content: `🎉 Congratulations! You won the prize!\n**Prize:** ${prize}\n\nCheck the winners: ${giveawayMessage.url}`,
                            });
                        } catch (error) {
                            console.log(`Couldn't DM winner ${winner.id}`);
                        }
                    }
            
                    if (host) {
                        try {
                            const hostUser = await client.users.fetch(host.id);
                            await hostUser.send({
                                content: `⏰ Your hosted giveaway has ended. Please check the winners and ensure everything is handled. ${giveawayMessage.url}`,
                            });
                        } catch (error) {
                            console.log(`Couldn't DM host ${host.id}`);
                        }
                    }
                } catch (error) {
                    console.log('❌ Failed to edit giveaway message or handle giveaway end:', error);
                }
            });            
        } catch (error) {
            console.error('❌ Failed to create giveaway:', error);
            await interaction.reply({
                content: '❌ An error occurred while creating the giveaway. Please try again.',
                ephemeral: true,
            });
        }

        client.on('messageDelete', async (message) => {
            try {
                const giveawayData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'addgiveaway.json'), 'utf-8'));
                const giveaway = giveawayData.find(g => g.id === message.id);
                if (giveaway) {
                    giveaway.active = false;
                    fs.writeFileSync(path.join(__dirname, 'data', 'addgiveaway.json'), JSON.stringify(giveawayData, null, 2));
                    console.log(`Giveaway with ID ${giveaway.id} has been deactivated due to message deletion.`);
                }
            } catch (error) {
                console.log('❌ Error handling giveaway deletion:', error);
            }
        });
    }
};

function parseDuration(duration) {
    const regex = /^(\d+)(h|d|m)$/;
    const match = duration.match(regex);
    if (!match) return null;
    const value = parseInt(match[1]);
    const unit = match[2];
    switch (unit) {
        case 'h': return value * 60 * 60 * 1000;
        case 'd': return value * 24 * 60 * 60 * 1000;
        case 'm': return value * 60 * 1000;
        default: return null;
    }
}

function getRandomWinners(participants, winnersCount) {
    const shuffled = participants.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, winnersCount);
}