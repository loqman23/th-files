const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const warningsFilePath = path.join(__dirname, 'data', 'warning.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Warn a specific user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to warn')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the warning')
                .setRequired(true)),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: '❌ Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.warn;

        if (!commandSettings.enabled) {
            return reply({ content: '⛔ This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const guild = interaction?.guild || message?.guild;

        if (!member || !channel || !guild) {
            return reply({ content: '❌ Cannot determine server information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: '🚫 You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: '🔒 This command is only available to certain roles', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: '📌 This command can only be used in specific channels', ephemeral: true });
        }

        let targetUser, reason;
        if (interaction) {
            targetUser = interaction.options.getUser('user');
            reason = interaction.options.getString('reason');
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias || args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].startsWith(process.env.PREFIX) ? 
                    args[0].slice(process.env.PREFIX.length).toLowerCase() : 
                    args[0].toLowerCase();
                
                if (commandName === 'warn' || commandSettings.aliases?.includes(commandName)) {
                    const mention = args[1];
                    if (!mention || !mention.startsWith('<@') || !mention.endsWith('>')) {
                        return reply({ 
                            content: '❌ Please mention the user to warn', 
                            ephemeral: true 
                        });
                    }
                    
                    const userId = mention.replace(/[<@!>]/g, '');
                    try {
                        targetUser = await client.users.fetch(userId);
                    } catch (error) {
                        return reply({ 
                            content: '❌ Cannot find mentioned user', 
                            ephemeral: true 
                        });
                    }
                    
                    reason = args.slice(2).join(' ') || 'Not specified';
                }
            }
        }

        if (!targetUser) {
            return reply({ 
                content: '❌ Please specify the user to warn', 
                ephemeral: true 
            });
        }

        if (!reason) {
            return reply({ 
                content: '❌ Please specify a reason for the warning', 
                ephemeral: true 
            });
        }

        const allowedRoleIds = process.env.STAFF?.split(',') || [];
        if (!member.permissions.has(PermissionsBitField.Flags.Administrator) &&
            !allowedRoleIds.some(roleId => member.roles.cache.has(roleId))) {
            return reply({ 
                content: '❌ You dont have permission to use this command', 
                ephemeral: true 
            });
        }

        try {
            await targetUser.send(`🚨 **Warning from server staff:**\n**Reason:** ${reason}`);
        } catch (error) {}

        const generateWarningId = () => {
            const randomNumbers = Math.floor(10000000 + Math.random() * 90000000);
            return `WARN-${randomNumbers}`;
        };

        let warningsData = {};
        if (fs.existsSync(warningsFilePath)) {
            try {
                warningsData = JSON.parse(fs.readFileSync(warningsFilePath, 'utf8'));
            } catch (error) {
                warningsData = {};
            }
        }

        if (!warningsData[targetUser.id]) {
            warningsData[targetUser.id] = [];
        }

        warningsData[targetUser.id].push({
            id: generateWarningId(),
            issuedBy: member.id,
            reason: reason,
            timestamp: new Date().toISOString(),
            moderator: member.user.tag
        });

        try {
            fs.writeFileSync(warningsFilePath, JSON.stringify(warningsData, null, 4));
        } catch (error) {
            return reply({ 
                content: '❌ Error saving warning data', 
                ephemeral: true 
            });
        }

        const successEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setDescription(`
                ✅ Successfully warned <@${targetUser.id}>
                **Reason:** ${reason}
                **Total warnings:** ${warningsData[targetUser.id].length}
            `)
            .setTimestamp();

        return reply({ 
            embeds: [successEmbed],
            ephemeral: false
        });
    },
};