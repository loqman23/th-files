const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const jailedMembers = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('jail')
        .setDescription('Jail a server member')
        .addUserOption(option =>
            option.setName('member')
                .setDescription('Member to jail')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for jailing')
                .setRequired(false)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.jail;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        const botMember = await interactionOrMessage.guild.members.fetch(client.user.id);
        if (!botMember.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
            return reply({ content: '❌ I do not have permission to manage roles!', ephemeral: true });
        }

        let targetMember, reason;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: false });
            targetMember = interaction.options.getMember('member');
            reason = interaction.options.getString('reason') || 'No reason provided';
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                targetMember = message.mentions.members.first();
                reason = args.slice(2).join(' ') || 'No reason provided';
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'jail' || commandSettings.aliases?.includes(commandName)) {
                    targetMember = message.mentions.members.first();
                    reason = args.slice(2).join(' ') || 'No reason provided';
                }
            }
            
            if (!targetMember) {
                const usageExample = commandSettings.aliases?.[0] || 'jail';
                return reply({ content: `❌ Please mention a member (example: ${usageExample} @user reason)` });
            }
        }

        if (!targetMember) {
            return reply({ content: '❌ Could not find this member', ephemeral: false });
        }

        if (targetMember.id === user.id) {
            return reply({ content: '❌ You cannot jail yourself', ephemeral: false });
        }

        if (commandSettings.permissions.no_jail_user?.includes(targetMember.id)) {
            return reply({ content: '❌ This member is protected from jailing', ephemeral: false });
        }

        const jailRole = interactionOrMessage.guild.roles.cache.get(commandSettings.permissions.jail_role);
        if (!jailRole) {
            return reply({ 
                content: '❌ Jail role not found. Please check the settings', 
                ephemeral: true 
            });
        }

        if (jailRole.position >= botMember.roles.highest.position) {
            return reply({ content: '❌ Jail role is higher than bot roles!', ephemeral: true });
        }

        try {
            const originalRoles = targetMember.roles.cache
                .filter(role => 
                    role.id !== interactionOrMessage.guild.id && 
                    !commandSettings.permissions.role_skip?.includes(role.id)
                )
                .map(role => role.id);

            jailedMembers.set(targetMember.id, {
                roles: originalRoles,
                timestamp: Date.now(),
                jailedBy: user.id,
                reason: reason
            });

            const rolesToRemove = targetMember.roles.cache.filter(role =>
                role.id !== interactionOrMessage.guild.id &&
                !commandSettings.permissions.role_skip?.includes(role.id) &&
                !role.permissions.has(PermissionsBitField.Flags.Administrator) &&
                role.id !== jailRole.id
            );

            for (const role of rolesToRemove.values()) {
                try {
                    await targetMember.roles.remove(role);
                } catch (err) {
                    console.error(`Failed to remove role ${role.name} from ${targetMember.user.tag}:`, err);
                }
            }

            if (!targetMember.roles.cache.has(jailRole.id)) {
                await targetMember.roles.add(jailRole);
            }

            await reply({ 
                content: `✅ Successfully jailed ${targetMember}! ${reason ? `\n**Reason:** ${reason}` : ''}`, 
                ephemeral: false 
            });

        } catch (error) {
            await reply({ 
                content: '❌ An error occurred while trying to jail the member. Please check bot permissions.', 
                ephemeral: false 
            });
        }
    },
    
    jailedMembers: jailedMembers
};