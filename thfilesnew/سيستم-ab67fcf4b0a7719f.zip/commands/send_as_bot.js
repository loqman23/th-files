require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sendasbot')
        .setDescription('Send a message as the bot')
        .addStringOption(option =>
            option.setName('msg')
                .setDescription('The message you want to send')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reply')
                .setDescription('Message ID to reply to (optional)')
                .setRequired(false)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        // تحميل الإعدادات من ملف setting.json
        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: '❌ Error loading settings.', ephemeral: true });
        }

        const commandSettings = settings.commands.sendasbot;

        // التحقق من تمكين الأمر
        if (!commandSettings.enabled) {
            return reply({ content: '❌ This command is currently disabled.', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: '❌ Cannot determine user information.', ephemeral: true });
        }

        // التحقق من الصلاحيات
        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: '❌ You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: '❌ You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: '❌ This command cannot be used in this channel.', ephemeral: true });
        }

        let messageContent, replyMessageId;

        if (interaction) {
            await interaction.deferReply({ ephemeral: true });
            messageContent = interaction.options.getString('msg');
            replyMessageId = interaction.options.getString('reply');
        } else {
            const args = message.content.slice(process.env.PREFIX.length).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();

            // التحقق من الأسماء البديلة
            const isAlias = commandSettings.aliases?.includes(commandName);
            if (!isAlias && commandName !== 'sendasbot') {
                return;
            }

            if (args.length < 1) {
                return reply({ content: '❌ Please provide a message to send.' });
            }

            // دعم الرد على رسالة إذا تم ذكر معرف الرسالة
            const replyIndex = args.findIndex(arg => arg.startsWith('reply:'));
            if (replyIndex !== -1) {
                replyMessageId = args[replyIndex].split(':')[1];
                args.splice(replyIndex, 1);
            }

            messageContent = args.join(' ');
        }

        try {
            let sentMessage;

            if (replyMessageId) {
                const targetMessage = await channel.messages.fetch(replyMessageId).catch(() => null);

                if (!targetMessage) {
                    return reply({ 
                        content: '❌ Could not find message to reply to. Please check the message ID.',
                        ephemeral: true
                    });
                }

                sentMessage = await targetMessage.reply(messageContent);
            } else {
                sentMessage = await channel.send(messageContent);
            }

            await reply({ content: '✅ Message sent successfully!', ephemeral: true });
        } catch (error) {
            console.error(error);
            await reply({ 
                content: '❌ Error while executing command.',
                ephemeral: true
            });
        }
    }
};