const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const dataPath = path.join(__dirname, 'data/auto_reaction.json');
const ADMIN = process.env.ADMIN;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('auto_reaction_remove')
        .setDescription('Remove a channel from auto-reaction list')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to remove from auto-reaction list')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        const channel = interaction.options.getChannel('channel');

        if (!interaction.member.roles.cache.has(ADMIN)) {
            return interaction.reply({ content: '❌ You do not have permission to use this command', ephemeral: true });
        }

        try {
            let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));

            if (!data.channels.includes(channel.id)) {
                return interaction.reply({ content: `❌ This channel is not in the auto-reaction list`, ephemeral: false });
            }

            data.channels = data.channels.filter(id => id !== channel.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));

            interaction.reply({ content: `✅ Removed <#${channel.id}> from auto-reaction list`, ephemeral: false });
        } catch (error) {
            console.error('Error updating auto_reaction.json:', error);
            interaction.reply({ content: '❌ Failed to update the list', ephemeral: false });
        }
    }
};