const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Colors } = require('discord.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('vacation')
        .setDescription('Request vacation')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to request vacation for')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('duration')
                .setDescription('Vacation duration (1-30 days)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(30)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Vacation reason')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option.setName('current_role')
                .setDescription('Your current role')
                .setRequired(true)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.vacation;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let targetUser, duration, reason, currentRole;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: false });
            targetUser = interaction.options.getUser('user');
            duration = interaction.options.getInteger('duration');
            reason = interaction.options.getString('reason');
            currentRole = interaction.options.getRole('current_role');
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                targetUser = message.mentions.users.first();
                duration = parseInt(args[2]);
                reason = args.slice(3, args.length - 1).join(' ');
                currentRole = message.mentions.roles.first();
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'vacation' || commandSettings.aliases?.includes(commandName)) {
                    targetUser = message.mentions.users.first();
                    duration = parseInt(args[2]);
                    reason = args.slice(3, args.length - 1).join(' ');
                    currentRole = message.mentions.roles.first();
                }
            }
            
            if (!targetUser || !duration || !reason || !currentRole) {
                const usageExample = commandSettings.aliases?.[0] || 'vacation';
                return reply({ content: `Please use the correct format (example: ${usageExample} @user 7 reason @role)` });
            }
        }

        if (targetUser.bot) {
            return reply({ content: 'Cannot request vacation for bots', ephemeral: false });
        }

        const vacationEmbed = new EmbedBuilder()
            .setTitle('📝 New Vacation Request')
            .setColor('#00FF00')
            .addFields(
                { name: '👤 Employee:', value: `${targetUser}`, inline: true },
                { name: '⏳ Duration:', value: `${duration} days`, inline: true },
                { name: '📝 Reason:', value: reason, inline: false },
                { name: '🏷 Current Role:', value: `${currentRole}`, inline: true },
                { name: '📌 Vacation Rules:', value: `
                    1. Vacation duration must be between 1-30 days
                    2. Must provide a clear and acceptable reason
                    3. Request will be reviewed by management
                    4. System abuse may result in penalties
                `, inline: false }
            )
            .setFooter({ text: `Requested by: ${user.tag}` })
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('accept_vacation')
                    .setLabel('✅ Approve')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('reject_vacation')
                    .setLabel('❌ Reject')
                    .setStyle(ButtonStyle.Danger)
            );

        const vacationChannel = client.channels.cache.get(process.env.VACATION_CHANNEL_ID);
        if (vacationChannel) {
            try {
                const vacationMessage = await vacationChannel.send({
                    content: `${targetUser}, <@&${process.env.ADMIN}>`,
                    embeds: [vacationEmbed],
                    components: [buttons]
                });

                await reply({ content: 'Vacation request submitted successfully', ephemeral: false });

                const filter = (i) => ['accept_vacation', 'reject_vacation'].includes(i.customId);
                const collector = vacationMessage.createMessageComponentCollector({ 
                    filter, 
                    time: 86400000
                });

                collector.on('collect', async (i) => {
                    if (!i.member.roles.cache.has(process.env.ADMIN)) {
                        return i.reply({ content: '❌ Only admins can approve requests', ephemeral: true });
                    }

                    if (i.customId === 'accept_vacation') {
                        const targetMember = await i.guild.members.fetch(targetUser.id);
                        await targetMember.roles.add(process.env.VACATION_ROLE);
                        await targetUser.send(`✅ Your vacation request for ${duration} days has been approved.\nReason: ${reason}`);
                        
                        const acceptEmbed = new EmbedBuilder()
                            .setDescription(`✅ ${targetUser}'s vacation request approved by ${i.user}`)
                            .setColor(Colors.Green);
                        
                        await i.reply({ embeds: [acceptEmbed] });
                    } 
                    else if (i.customId === 'reject_vacation') {
                        await targetUser.send(`❌ Your vacation request has been rejected.\nReason: ${reason || 'No reason provided'}`);
                        
                        const rejectEmbed = new EmbedBuilder()
                            .setDescription(`❌ ${targetUser}'s vacation request rejected by ${i.user}`)
                            .setColor(Colors.Red);
                        
                        await i.reply({ embeds: [rejectEmbed] });
                    }

                    await vacationMessage.edit({ components: [] });
                    collector.stop();
                });

            } catch (error) {
                await reply({ content: '❌ Error processing vacation request', ephemeral: true });
            }
        } else {
            await reply({ content: '❌ Vacation channel not found', ephemeral: true });
        }
    }
};