const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('edit_giveaway')
        .setDescription('Edit current giveaway using message ID')
        .addStringOption(option =>
            option.setName('message_id')
                .setDescription('Message ID of the giveaway to edit')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('name')
                .setDescription('New giveaway title')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('New giveaway duration (e.g. 6h, 2d, 30m)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('New number of winners')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('New giveaway prize')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('host')
                .setDescription('New giveaway host'))
        .addStringOption(option =>
            option.setName('banner')
                .setDescription('URL for new banner image (optional)'))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('URL for new thumbnail image (optional)')),

    async execute(client, interaction) {
        const allowedRoles = [
            process.env.ADMIN
        ];

        const memberRoles = interaction.member.roles.cache.map(role => role.id);
        const hasPermission = allowedRoles.some(role => memberRoles.includes(role));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: false
            });
        }

        const messageId = interaction.options.getString('message_id');
        const name = interaction.options.getString('name');
        const duration = interaction.options.getString('duration');
        const winners = interaction.options.getInteger('winners');
        const prize = interaction.options.getString('prize');
        const host = interaction.options.getUser('host');
        const banner = interaction.options.getString('banner');
        const thumbnail = interaction.options.getString('thumbnail');

        const durationMs = parseDuration(duration);

        if (durationMs === null) {
            await interaction.reply({ content: '❌ Invalid duration format. Please use "h", "d" or "m" (e.g. 6h, 2d, 30m).', ephemeral: false });
            return;
        }

        const giveawayDataPath = path.join(__dirname, 'data', 'addgiveaway.json');
        const giveawayData = JSON.parse(fs.readFileSync(giveawayDataPath, 'utf-8') || '[]');

        const giveawayEntry = giveawayData.find(entry => entry.id === messageId);
        if (!giveawayEntry) {
            await interaction.reply({ content: '❌ No giveaway found with the provided message ID', ephemeral: false });
            return;
        }

        giveawayEntry.name = name;
        giveawayEntry.duration = duration;
        giveawayEntry.winners = winners;
        giveawayEntry.prize = prize;
        giveawayEntry.host = host ? host.username : 'Anonymous';
        giveawayEntry.banner = banner || giveawayEntry.banner;
        giveawayEntry.thumbnail = thumbnail || giveawayEntry.thumbnail;

        const embed = new EmbedBuilder()
            .setTitle(`🎉 Giveaway: ${name}`)
            .setDescription(`**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends In:** <t:${Math.floor((Date.now() + durationMs) / 1000)}:R>\n**Hosted By:** ${host ? host : 'Anonymous'}`)
            .setColor('Blue')
            .setFooter({ text: 'Click the button below to enter' });

        if (banner) embed.setImage(banner);
        if (thumbnail) embed.setThumbnail(thumbnail);

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('giveaway_enter')
                    .setLabel('🎉 Enter')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('giveaway_participants')
                    .setLabel('📋 Participants')
                    .setStyle(ButtonStyle.Secondary)
            );

        try {
            const giveawayChannel = interaction.channel;
            const giveawayMessage = await giveawayChannel.messages.fetch(messageId);
            
            if (!giveawayMessage) {
                throw new Error("Message not found");
            }

            await giveawayMessage.edit({ embeds: [embed], components: [button] });
            
            fs.writeFileSync(giveawayDataPath, JSON.stringify(giveawayData, null, 2));

            await interaction.reply({ content: `✅ Giveaway with message ID ${messageId} updated successfully!`, ephemeral: false });
        } catch (error) {
            console.error('❌ Error editing giveaway message:', error);
            await interaction.reply({
                content: '❌ Could not find or edit the message. Please check the ID.',
                ephemeral: true
            });
        }
    }
};

function parseDuration(duration) {
    const regex = /^(\d+)(h|d|m)$/;
    const match = duration.match(regex);

    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 'h':
            return value * 60 * 60 * 1000;
        case 'd':
            return value * 24 * 60 * 60 * 1000;
        case 'm':
            return value * 60 * 1000;
        default:
            return null;
    }
}