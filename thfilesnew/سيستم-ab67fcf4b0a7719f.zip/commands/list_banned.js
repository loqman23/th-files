const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list_banned')
        .setDescription('Show list of banned users'),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: '❌ Error loading settings.', ephemeral: true });
        }

        const commandSettings = settings.commands.list_banned;

        if (!commandSettings.enabled) {
            return reply({ content: '⛔ This command is currently disabled.', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const guild = interaction?.guild || message?.guild;

        if (!member || !channel || !guild) {
            return reply({ content: '❌ Cannot determine server information.', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: '🚫 You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: '🔒 This command is only available for certain roles.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: '📌 This command can only be used in specific channels.', ephemeral: true });
        }

        try {
            if (interaction) await interaction.deferReply();

            const bannedUsers = await guild.bans.fetch();

            if (bannedUsers.size === 0) {
                return reply({
                    content: '✅ There are currently no banned users.',
                    ephemeral: false,
                });
            }

            const sortedBannedUsers = Array.from(bannedUsers.values()).sort((a, b) => 
                (b.createdAt || new Date(0)).getTime() - (a.createdAt || new Date(0)).getTime()
            );

            const PAGE_SIZE = 5;
            let currentPage = 0;
            
            const generateEmbed = (page) => {
                const start = page * PAGE_SIZE;
                const end = start + PAGE_SIZE;
                const pageUsers = sortedBannedUsers.slice(start, end);

                const embed = new EmbedBuilder()
                    .setTitle('📜 Banned Users List')
                    .setColor('#ff0000')
                    .setFooter({ 
                        text: `Page ${page + 1} of ${Math.ceil(sortedBannedUsers.length / PAGE_SIZE)}` 
                    });

                pageUsers.forEach((ban, i) => {
                    const banDate = ban.createdAt ? ban.createdAt.toLocaleDateString() : 'Unknown date';
                    embed.addFields({
                        name: `#${start + i + 1} ${ban.user.tag}`,
                        value: `**Date:** ${banDate}\n**Reason:** ${ban.reason || 'Not specified'}`,
                        inline: false
                    });
                });

                return embed;
            };

            const getButtons = () => {
                return new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('prev_page')
                        .setLabel('Previous')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === 0),
                    
                    new ButtonBuilder()
                        .setCustomId('next_page')
                        .setLabel('Next')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage >= Math.ceil(sortedBannedUsers.length / PAGE_SIZE) - 1)
                );
            };

            const response = await reply({
                embeds: [generateEmbed(currentPage)],
                components: [getButtons()],
                fetchReply: true
            });

            const filter = (i) => i.user.id === (interaction?.user.id || message?.author.id);
            const collector = response.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async (i) => {
                const interactingMember = await guild.members.fetch(i.user.id);
                if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
                    !interactingMember.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
                    return i.reply({
                        content: '❌ You do not have permission to interact with this list.',
                        ephemeral: true
                    });
                }

                if (i.customId === 'prev_page') currentPage--;
                if (i.customId === 'next_page') currentPage++;
                
                await i.update({
                    embeds: [generateEmbed(currentPage)],
                    components: [getButtons()]
                });
            });

            collector.on('end', () => {
                response.edit({ components: [] }).catch(console.error);
            });

        } catch (error) {
            await reply({
                content: '❌ An error occurred while fetching the banned users list.',
                ephemeral: true
            });
        }
    }
};