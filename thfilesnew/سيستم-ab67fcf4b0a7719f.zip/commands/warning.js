const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const warningsFilePath = path.join(__dirname, 'data', 'warning.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warning')
        .setDescription('Show all warnings for a specific person')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The person you want to view warnings for')
                .setRequired(true)),

    async execute(client, interactionOrMessage) {
        // تحديد نوع التفاعل
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        // دالة للرد المناسب حسب نوع التفاعل
        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        // تحميل الإعدادات
        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            console.error('Error loading settings:', error);
            return reply({ content: '❌ An error occurred while loading the settings.', ephemeral: true });
        }

        const commandSettings = settings.commands.warning;

        // التحقق من تفعيل الأمر
        if (!commandSettings.enabled) {
            return reply({ content: '⛔ This command is currently not enabled', ephemeral: true });
        }

        // الحصول على معلومات العضو والقناة
        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const guild = interaction?.guild || message?.guild;

        if (!member || !channel || !guild) {
            return reply({ content: '❌ Server information cannot be determined', ephemeral: true });
        }

        // التحقق من الصلاحيات
        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: '🚫 You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: '🔒 This command is only available for some roles.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: '📌 This command can only be used on specific channels', ephemeral: true });
        }

        // معالجة المدخلات
        let targetUser;
        if (interaction) {
            targetUser = interaction.options.getUser('user');
        } else {
            // معالجة الأمر النصي أو الاختصار
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            // تحديد ما إذا كان استدعاء بدون بريفيكس (كاختصار)
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias || args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].startsWith(process.env.PREFIX) ? 
                    args[0].slice(process.env.PREFIX.length).toLowerCase() : 
                    args[0].toLowerCase();
                
                if (commandName === 'warning' || commandSettings.aliases?.includes(commandName)) {
                    // الحصول على المستخدم المذكور
                    const mention = args[1];
                    if (!mention || !mention.startsWith('<@') || !mention.endsWith('>')) {
                        return reply({ 
                            content: '❌ Please mention the person whose warnings you want to display', 
                            ephemeral: true 
                        });
                    }
                    
                    const userId = mention.replace(/[<@!>]/g, '');
                    try {
                        targetUser = await client.users.fetch(userId);
                    } catch (error) {
                        return reply({ 
                            content: '❌ The mentioned user could not be found', 
                            ephemeral: true 
                        });
                    }
                }
            }
        }

        if (!targetUser) {
            return reply({ 
                content: '❌ Please select the person whose warnings you want to display', 
                ephemeral: true 
            });
        }

        // التحقق من صلاحيات الإدارة
        const allowedRoleIds = process.env.STAFF?.split(',') || [];
        if (!member.permissions.has(PermissionsBitField.Flags.Administrator) &&
            !allowedRoleIds.some(roleId => member.roles.cache.has(roleId))) {
            return reply({ 
                content: '❌ You do not have permission to use this command', 
                ephemeral: true 
            });
        }

        // معالجة ملف التحذيرات
        let warningsData = {};
        if (fs.existsSync(warningsFilePath)) {
            try {
                warningsData = JSON.parse(fs.readFileSync(warningsFilePath, 'utf8'));
            } catch (error) {
                console.error('Error reading warnings file:', error);
                warningsData = {};
            }
        }

        if (!warningsData[targetUser.id] || warningsData[targetUser.id].length === 0) {
            return reply({ 
                content: `✅ User <@${targetUser.id}> has no warnings`, 
                ephemeral: true 
            });
        }

        // إنشاء قائمة التحذيرات
        const warningsList = warningsData[targetUser.id]
            .map((warn, index) => {
                const warnDate = new Date(warn.timestamp);
                return `🔹 **warning #${index + 1}:**\n` +
                       `**code:** ${warn.id}\n` +
                       `**responsible:** <@${warn.issuedBy}> (${warn.moderator || 'unknown'})\n` +
                       `**reason:** ${warn.reason}\n` +
                       `**date:** <t:${Math.floor(warnDate.getTime() / 1000)}:F>`;
            })
            .join('\n\n');

        // إنشاء إيمبد لعرض التحذيرات
        const warningsEmbed = new EmbedBuilder()
            .setTitle(`⚠️ Log warnings ${targetUser.tag}`)
            .setColor('#FFA500')
            .setDescription(warningsList)
            .setTimestamp()
            .setFooter({ 
                text: `Total Warnings: ${warningsData[targetUser.id].length} | by: ${member.user.tag}` 
            });

        // الرد للمستخدم فقط (بدون إرسال إلى سجل التحذيرات)
        return reply({ 
            embeds: [warningsEmbed], 
            ephemeral: true 
        });
    },
};