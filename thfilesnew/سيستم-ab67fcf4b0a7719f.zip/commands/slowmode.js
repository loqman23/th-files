const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('slowmode')
        .setDescription('Enable or disable slowmode in a channel')
        .addIntegerOption(option => 
            option.setName('time')
                .setDescription('Duration in seconds (0 to disable, max 21600 seconds)')
                .setRequired(true)
                .setMinValue(0)
                .setMaxValue(21600)
        )
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Target channel')
                .setRequired(true)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.slowmode;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let time, targetChannel;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: true });
            time = interaction.options.getInteger('time');
            targetChannel = interaction.options.getChannel('channel');
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                time = parseInt(args[1]);
                targetChannel = message.mentions.channels.first();
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'slowmode' || commandSettings.aliases?.includes(commandName)) {
                    time = parseInt(args[1]);
                    targetChannel = message.mentions.channels.first();
                }
            }
            
            if (!time || !targetChannel) {
                const usageExample = commandSettings.aliases?.[0] || 'slowmode';
                return reply({ content: `❌ Please use the correct format (example: ${usageExample} 30 #channel)` });
            }
        }

        if (!targetChannel.isTextBased()) {
            return reply({ content: '❌ Cannot enable slowmode in this channel type', ephemeral: true });
        }

        try {
            await targetChannel.setRateLimitPerUser(time);
            
            let resultMessage;
            if (time === 0) {
                resultMessage = `✅ Slowmode **disabled** in ${targetChannel}`;
            } else {
                const hours = Math.floor(time / 3600);
                const minutes = Math.floor((time % 3600) / 60);
                const seconds = time % 60;
                
                let timeString = '';
                if (hours > 0) timeString += `${hours} hour${hours > 1 ? 's' : ''} `;
                if (minutes > 0) timeString += `${minutes} minute${minutes > 1 ? 's' : ''} `;
                if (seconds > 0 || timeString === '') timeString += `${seconds} second${seconds !== 1 ? 's' : ''}`;
                
                resultMessage = `✅ Slowmode enabled in ${targetChannel} for **${timeString.trim()}**`;
            }

            await reply({ content: resultMessage, ephemeral: false });

        } catch (error) {
            await reply({ content: '❌ Error while setting slowmode', ephemeral: true });
        }
    }
};