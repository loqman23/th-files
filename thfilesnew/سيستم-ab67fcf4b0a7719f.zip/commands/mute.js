require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors, PermissionsBitField } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Mute a user for a specific duration with a reason')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to mute')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Mute duration (e.g., 10m, 1h, 2d)')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the mute')
                .setRequired(false)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings.', ephemeral: true });
        }

        const commandSettings = settings.commands.mute;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled.', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information.', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel.', ephemeral: true });
        }

        let targetUser, duration, reason;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: false });
            targetUser = interaction.options.getUser('user');
            duration = interaction.options.getString('duration');
            reason = interaction.options.getString('reason') || 'No reason provided.';
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                targetUser = message.mentions.users.first();
                duration = args[2];
                reason = args.slice(3).join(' ') || 'No reason provided.';
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'mute' || commandSettings.aliases?.includes(commandName)) {
                    targetUser = message.mentions.users.first();
                    duration = args[2];
                    reason = args.slice(3).join(' ') || 'No reason provided.';
                }
            }
            
            if (!targetUser || !duration) {
                const usageExample = commandSettings.aliases?.[0] || 'mute';
                return reply({ content: `❌ Please use the correct format (example: ${usageExample} @user 10m reason)` });
            }
        }

        const targetMember = interactionOrMessage.guild.members.cache.get(targetUser.id);

        if (!targetMember) {
            return reply({ content: '❌ User not found in the server', ephemeral: true });
        }

        if (!targetMember.manageable) {
            return reply({ content: '❌ I cannot mute this user. They may have a higher role than me or be the owner.', ephemeral: true });
        }

        const timeMap = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
        const match = duration.match(/^(\d+)([smhd])$/);

        if (!match) {
            return reply({ content: '❌ Invalid duration format. Use s (seconds), m (minutes), h (hours), d (days) (example: `10m`, `1h`, `2d`).', ephemeral: true });
        }

        const timeValue = parseInt(match[1]);
        const timeUnit = match[2];
        const muteDuration = timeValue * timeMap[timeUnit];

        if (isNaN(muteDuration) || muteDuration <= 0) {
            return reply({ content: '❌ Invalid duration value', ephemeral: true });
        }

        try {
            await targetMember.timeout(muteDuration, reason);

            const logThread = client.channels.cache.get(process.env.LOG_THREAD_MUTE);
            const logEmbed = new EmbedBuilder()
                .setTitle('🔇 User Muted')
                .setColor(Colors.Red)
                .addFields(
                    { name: '👤 Muted By', value: `${user} (${user.tag})`, inline: true },
                    { name: '👥 User', value: `${targetUser} (${targetUser.tag})`, inline: true },
                    { name: '🕒 Duration', value: `\`${duration}\``, inline: true },
                    { name: '📄 Reason', value: `\`${reason}\``, inline: false },
                    { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                )
                .setTimestamp();

            if (logThread && logThread.isThread()) {
                await logThread.send({ embeds: [logEmbed] });
            }

            await reply({ content: `✅ Successfully muted **${targetUser}** for **${duration}**` });

            setTimeout(async () => {
                if (targetMember.communicationDisabledUntilTimestamp > Date.now()) {
                    try {
                        await targetMember.timeout(null);
                        
                        const unmuteEmbed = new EmbedBuilder()
                            .setTitle('🔊 User Unmuted')
                            .setColor(Colors.Green)
                            .addFields(
                                { name: '👥 User', value: `${targetUser} (${targetUser.tag})`, inline: true },
                                { name: '⏳ Duration', value: `\`${duration}\``, inline: true },
                                { name: '📅 Unmute Time', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                            )
                            .setTimestamp();
                        
                        if (logThread && logThread.isThread()) {
                            await logThread.send({ embeds: [unmuteEmbed] });
                        }
                    } catch (err) {
                        console.error('Failed to unmute user:', err);
                    }
                }
            }, muteDuration);

        } catch (error) {
            await reply({ content: '❌ Failed to mute the user. Please check my permissions.', ephemeral: true });
        }
    }
};