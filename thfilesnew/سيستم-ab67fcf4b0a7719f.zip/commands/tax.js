const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tax')
        .setDescription('Calculate probot tax')
        .addStringOption(option =>
            option.setName('amount')
                .setDescription('Enter the amount (e.g. 600k, 2m, 5b, or 10000)')
                .setRequired(true)
        ),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.tax;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You dont have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        try {
            let amountInput;
            if (interaction) {
                await interaction.deferReply();
                amountInput = interaction.options.getString('amount');
            } else {
                const content = message.content.trim();
                const args = content.split(/\s+/);
                
                const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
                
                if (isAlias) {
                    amountInput = args[1];
                } else if (args[0].startsWith(process.env.PREFIX)) {
                    const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                    if (commandName === 'tax' || commandSettings.aliases?.includes(commandName)) {
                        amountInput = args[1];
                    }
                }
                
                if (!amountInput) {
                    const usageExample = commandSettings.aliases?.[0] || 'tax';
                    return reply({ content: `❌ Please enter amount after command (e.g. ${usageExample} 600k)`, ephemeral: true });
                }
            }

            const amount = parseAmount(amountInput);

            if (amount === null) {
                return reply({ content: '❌ Please enter a valid amount (e.g. 600k, 2m, 5b, or 10000).', ephemeral: true });
            }

            if (amount <= 0) {
                return reply({ content: '❌ Please enter a valid amount greater than zero.', ephemeral: true });
            }

            const tax2 = Math.floor(amount * (20) / (19) + (1) - amount);
            const finalAmount = amount + tax2;

            const color = determineColor(finalAmount);

            const embed = new EmbedBuilder()
                .setTitle('Probot Tax Calculation Results')
                .setColor(color)
                .setThumbnail('https://cdn.discordapp.com/attachments/1308882544770420766/1310001716141232128/Default_The_image_shows_a_3D_icon_representing_Tax_It_consists_1_bb7b5b3a-8b79-4b1a-a25b-f2571067dbe4_0.png')
                .addFields(
                    { name: 'Original Amount', value: `${formatNumber(amount)}`, inline: true },
                    { name: 'Broker Tax', value: `${formatNumber(tax2)}`, inline: true },
                    { name: 'Final Amount', value: `\`\`\`${formatNumber(finalAmount)}\`\`\``, inline: false }
                )
                .setFooter({ text: `${client.user.username} - ${new Date().toLocaleString()}` })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('aboutus')
                        .setLabel('About us')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('changeLanguage')
                        .setLabel('Change Language')
                        .setStyle(ButtonStyle.Success)
                );

            const response = await reply({ embeds: [embed], components: [row], fetchReply: true });

            const filter = (btnInteraction) => btnInteraction.user.id === user.id;
            const collector = response.createMessageComponentCollector({ filter, time: 60000 });

            let isEnglish = true;

            collector.on('collect', async (btnInteraction) => {
                if (btnInteraction.customId === 'changeLanguage') {
                    isEnglish = !isEnglish;

                    embed.setTitle(isEnglish ? 'Probot Tax Calculation Results' : 'نتائج حساب ضريبة بروبوت')
                        .setFields([
                            { name: isEnglish ? 'Original Amount' : 'المبلغ الأصلي', value: `${formatNumber(amount)}`, inline: true },
                            { name: isEnglish ? 'Broker Tax' : 'المبلغ المخصم', value: `${formatNumber(tax2)}`, inline: true },
                            { name: isEnglish ? 'Final Amount' : 'المبلغ النهائي', value: `\`\`\`${formatNumber(finalAmount)}\`\`\``, inline: false }
                        ]);

                    row.components[0].setLabel(isEnglish ? 'About us' : 'تعرف علينا');
                    row.components[1].setLabel(isEnglish ? 'Change Language' : 'تغيير اللغة');

                    await btnInteraction.update({ embeds: [embed], components: [row] });
                } else if (btnInteraction.customId === 'aboutus') {
                    const aboutEmbed = new EmbedBuilder()
                        .setTitle(isEnglish ? 'About ProTax' : 'تعرف على ProTax')
                        .setColor('#f5b7b1')
                        .setThumbnail('https://cdn.discordapp.com/attachments/1308882544770420766/1310009970762321920/cropped-PB.png')
                        .addFields(
                            { name: isEnglish ? 'Description' : 'الوصف', 
                              value: isEnglish ? 
                              'The bot calculates probot tax easily and shows the final amount that will reach the user' : 
                              'يقوم البوت بحساب ضريبة بروبوت بشكل سهل و معرفة المبلغ الذي سيصل للمستخدم حسب المبلغ المدخل' },
                            { name: isEnglish ? 'Developer' : 'المطور', value: 'rewebby | 756947441592303707' },
                            { name: isEnglish ? 'Support Server' : 'سيرفر الدعم', value: '[Support Server](https://discord.gg/YkEy6d7TzQ)', inline: false },
                            { name: isEnglish ? 'Technologies' : 'التقنيات المستخدمة', value: 'Node.js, Discord.js', inline: false },
                        )
                        .setImage('https://cdn.discordapp.com/attachments/1308882544770420766/1310009970372382833/17f22523900c3a49d6e21e9d72fac5da.jpg')
                        .setFooter({ text: 'ProTax Bot' })
                        .setTimestamp();

                    await btnInteraction.reply({ embeds: [aboutEmbed], ephemeral: true });
                }
            });

            collector.on('end', async () => {
                try {
                    await response.edit({ components: [] });
                } catch (error) {}
            });
        } catch (error) {
            await reply({ content: '❌ An error occurred while processing your request.', ephemeral: true });
        }
    }
};

function parseAmount(input) {
    if (!input) return null;
    
    const regex = /^(\d+(?:\.\d+)?)([kmb]?)$/i;
    const match = input.replace(/,/g, '').match(regex);

    if (!match) return null;

    let amount = parseFloat(match[1]);
    const unit = match[2].toLowerCase();

    switch (unit) {
        case 'k': return amount * 1000;
        case 'm': return amount * 1000000;
        case 'b': return amount * 1000000000;
        default: return amount;
    }
}

function determineColor(finalAmount) {
    const colors = [
        { max: 1, color: '#8e44ad' },
        { max: 10, color: '#9b59b6' },
        { max: 100, color: '#af7ac5' },
        { max: 1000, color: '#d2b4de' },
        { max: 10000, color: '#e8daef' },
        { max: 100000, color: '#f5b7b1' },
        { max: 1000000, color: '#f1948a' },
        { max: 10000000, color: '#ec7063' },
        { max: 100000000, color: '#ff1900' },
        { max: 1000000000, color: '#ff005d' },
        { max: 10000000000, color: '#ff00ff' },
        { max: Infinity, color: '#fff200' }
    ];

    return colors.find(range => finalAmount <= range.max).color;
}

function formatNumber(num) {
    return num.toLocaleString('en-US');
}