const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder } = require('discord.js');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway_delete')
        .setDescription('Delete a giveaway using message ID')
        .addStringOption(option =>
            option.setName('message_id')
                .setDescription('Message ID of the giveaway to delete')
                .setRequired(true)),

    async execute(client, interaction) {
        const allowedRoles = [
            process.env.ADMIN
        ];

        const memberRoles = interaction.member.roles.cache.map(role => role.id);
        const hasPermission = allowedRoles.some(role => memberRoles.includes(role));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: false
            });
        }

        const messageId = interaction.options.getString('message_id');
        const giveawayChannel = interaction.channel;

        const giveawayMessage = await giveawayChannel.messages.fetch(messageId).catch(() => null);
        if (!giveawayMessage) {
            return await interaction.reply({ content: '❌ No giveaway message found with this ID!', ephemeral: false });
        }

        await giveawayMessage.delete().catch(() => null);

        const giveawayDataPath = path.join(__dirname, 'data', 'addgiveaway.json');
        const giveawayData = JSON.parse(fs.readFileSync(giveawayDataPath, 'utf-8') || '[]');

        const updatedData = giveawayData.filter(entry => entry.id !== messageId);
        fs.writeFileSync(giveawayDataPath, JSON.stringify(updatedData, null, 2));

        await interaction.reply({ content: `✅ Successfully deleted giveaway with message ID ${messageId}`, ephemeral: false });
    }
};