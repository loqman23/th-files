const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('logo_server')
        .setDescription('عرض صورة بروفايل السيرفر'),

    async execute(client, interactionOrMessage, args) {
        // تحميل الإعدادات من setting.json
        const settingsPath = path.join(__dirname, '..', 'setting.json');
        const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        const commandSettings = settings.commands.logo_server;

        // تحديد نوع التفاعل (سلاك/رسالة)
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const message = isSlashCommand ? null : interactionOrMessage;
        const interaction = isSlashCommand ? interactionOrMessage : null;

        // دالة للرد الموحد
        const respond = async (response) => {
            if (isSlashCommand) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(response);
                }
                return interaction.reply(response);
            }
            return message.reply(response);
        };

        // التحقق من تفعيل الأمر
        if (!commandSettings.enabled) {
            return respond({ content: '⚠️ هذا الأمر غير مفعل حالياً' });
        }

        // التحقق من الصلاحيات للأوامر النصية
        if (!isSlashCommand) {
            const member = message.member;
            const channel = message.channel;

            // التحقق من الرتب المحظورة
            if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
                member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
                return respond({ content: '⛔ ليس لديك صلاحية استخدام هذا الأمر' });
            }

            // التحقق من الرتب المسموحة
            if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
                !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
                return respond({ content: '⛔ ليس لديك صلاحية استخدام هذا الأمر' });
            }

            // التحقق من الغرف المسموحة
            if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
                !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
                return respond({ content: '🚫 لا يمكن استخدام هذا الأمر في هذه الغرفة' });
            }
        }

        // الحصول على معلومات السيرفر
        const guild = interaction?.guild || message?.guild;
        if (!guild) {
            return respond({ content: '❌ لا يمكن تحديد السيرفر' });
        }

        // التحقق من وجود صورة للسيرفر
        if (!guild.iconURL()) {
            return respond({ content: '❌ لا توجد صورة بروفايل لهذا السيرفر' });
        }

        // إنشاء زر لفتح الصورة بحجم كامل (للأوامر الشرطية فقط)
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('فتح الصورة بحجم كامل')
                    .setStyle(ButtonStyle.Link)
                    .setURL(guild.iconURL({ size: 4096 }))
            );

        // إنشاء Embed لعرض الصورة
        const embed = new EmbedBuilder()
            .setColor('Random')
            .setTitle(`🖼️ صورة سيرفر ${guild.name}`)
            .setImage(guild.iconURL({ size: 1024 }))
            .setDescription(`[رابط الصورة الأصلية](${guild.iconURL({ size: 4096 })})`)
            .setFooter({
                text: `طلب من قبل ${interaction?.user.tag || message.author.tag}`,
                iconURL: interaction?.user.displayAvatarURL() || message.author.displayAvatarURL()
            });

        // إرسال الرد
        return respond({
            embeds: [embed],
            components: isSlashCommand ? [row] : []
        });
    }
};