const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lock')
        .setDescription('Lock a channel to prevent sending messages')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('The channel to lock')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.();
        const isMessage = !isSlashCommand && interactionOrMessage.content;
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isMessage ? interactionOrMessage : null;

        const reply = async (content, options = {}) => {
            if (interaction) {
                if (interaction.replied || interaction.deferred) {
                    return interaction.editReply(content);
                }
                return interaction.reply(content);
            } else {
                return message.reply(content);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings.', ephemeral: true });
        }

        const commandSettings = settings.commands.lock;

        if (!commandSettings.enabled) {
            return reply({ content: 'This command is currently disabled.', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information.', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel.', ephemeral: true });
        }

        let targetChannel;
        
        if (interaction) {
            await interaction.deferReply({ ephemeral: true });
            targetChannel = interaction.options.getChannel('channel');
        } else {
            const content = message.content.trim();
            const args = content.split(/\s+/);
            
            const isAlias = commandSettings.aliases?.includes(args[0].toLowerCase());
            
            if (isAlias) {
                targetChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
            } else if (args[0].startsWith(process.env.PREFIX)) {
                const commandName = args[0].slice(process.env.PREFIX.length).toLowerCase();
                if (commandName === 'lock' || commandSettings.aliases?.includes(commandName)) {
                    targetChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                }
            }
            
            if (!targetChannel) {
                const usageExample = commandSettings.aliases?.[0] || 'lock';
                return reply({ content: `❌ Please mention a channel (example: ${usageExample} #channel)` });
            }
        }

        if (!targetChannel) {
            return reply({ content: '❌ Cannot find this channel.' });
        }

        try {
            await targetChannel.permissionOverwrites.edit(targetChannel.guild.roles.everyone, { SendMessages: false });

            const logChannel = client.channels.cache.get(process.env.LOG_THREAD_LOCK);
            const embed = new EmbedBuilder()
                .setTitle('🔒 Channel Locked')
                .setDescription(`**Channel:** ${targetChannel} was locked by ${user}`)
                .setColor(0xFF0000)
                .setTimestamp();

            if (logChannel) {
                await logChannel.send({ embeds: [embed] });
            }

            await reply({ content: `✅ Successfully locked ${targetChannel}.` });
        } catch (error) {
            return reply({ content: '❌ An error occurred while trying to lock the channel.' });
        }
    }
};