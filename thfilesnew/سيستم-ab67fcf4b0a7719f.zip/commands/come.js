const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('come')
        .setDescription('Send a summon message to a specific user')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('Target user')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('message')
                .setDescription('Message to send')
                .setRequired(true)),
    
    async execute(client, interactionOrMessage) {
        const isSlashCommand = interactionOrMessage.isCommand?.(); 
        const interaction = isSlashCommand ? interactionOrMessage : null;
        const message = isSlashCommand ? null : interactionOrMessage;

        const reply = async (content, options = {}) => {
            try {
                if (interaction) {
                    if (interaction.replied || interaction.deferred) {
                        return await interaction.editReply(content).catch(console.error);
                    }
                    return await interaction.reply(content).catch(console.error);
                } else {
                    return await message.reply(content).catch(console.error);
                }
            } catch (error) {
                console.error('Error in reply function:', error);
            }
        };

        const settingsPath = path.join(__dirname, '..', 'setting.json');
        let settings;
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        } catch (error) {
            return reply({ content: 'Error loading settings', ephemeral: true });
        }

        const commandSettings = settings.commands.come;

        if (!commandSettings.enabled) { 
            return reply({ content: 'This command is currently disabled', ephemeral: true });
        }

        const member = interaction?.member || message?.member;
        const channel = interaction?.channel || message?.channel;
        const user = interaction?.user || message?.author;

        if (!member || !channel || !user) {
            return reply({ content: 'Cannot determine user information', ephemeral: true });
        }

        if (commandSettings.permissions.disabledRoleIds?.length > 0 && 
            member.roles.cache.some(role => commandSettings.permissions.disabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoleIds?.length > 0 && 
            !member.roles.cache.some(role => commandSettings.permissions.enabledRoleIds.includes(role.id))) {
            return reply({ content: 'You do not have permission to use this command', ephemeral: true });
        }

        if (commandSettings.permissions.enabledRoomIds?.length > 0 && 
            !commandSettings.permissions.enabledRoomIds.includes(channel.id)) {
            return reply({ content: 'This command cannot be used in this channel', ephemeral: true });
        }

        let targetUser, messageContent;
        if (interaction) {
            targetUser = interaction.options.getUser('user');
            messageContent = interaction.options.getString('message');
        } else {
            const args = message.content.split(/\s+/).slice(1);
            if (args.length < 2) {
                return reply({ content: '❌ Invalid command format. Use: `come @user message`', ephemeral: true });
            }
            
            targetUser = message.mentions.users.first();
            if (!targetUser) {
                return reply({ content: '❌ Please mention a user correctly', ephemeral: true });
            }
            
            messageContent = args.slice(1).join(' ');
        }

        try {
            const channelId = channel.id;
            const guildId = interaction?.guildId || message.guild.id;
            const messageId = interaction?.id || message.id;
            
            const messageLink = `https://discord.com/channels/${guildId}/${channelId}/${messageId}`;
            
            const embed = new EmbedBuilder()
                .setColor('#3498db')
                .setTitle('📩 New Message')
                .setDescription(`\`\`\`${messageContent}\`\`\``)
                .addFields(
                    { name: '👤 Sender', value: `<@${user.id}>`, inline: true },
                    { name: '🏢 Server', value: interaction?.guild?.name || message.guild.name, inline: true }
                )
                .setFooter({ text: 'Click the button below to go to the original message' })
                .setTimestamp();
            
            const button = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('🔗 Go to Message')
                    .setStyle(ButtonStyle.Link)
                    .setURL(messageLink)
            );
            
            await targetUser.send({ 
                embeds: [embed],
                components: [button] 
            }).catch(async () => {
                await reply({ content: '❌ Cannot send DM to this user', ephemeral: true });
                return;
            });
            
            const confirmEmbed = new EmbedBuilder()
                .setColor('#2ecc71')
                .setDescription(`✅ Message sent to <@${targetUser.id}>`)
                .setFooter({ text: `Message: ${messageContent.substring(0, 50)}${messageContent.length > 50 ? '...' : ''}` });
            
            await reply({ 
                embeds: [confirmEmbed],
                ephemeral: false 
            });
            
        } catch (error) {
            await reply({ 
                content: '❌ Unexpected error while sending summon', 
                ephemeral: true 
            });
        }
    }
};