const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'data', 'addres.json');
const allowedRoles = process.env.ADDRES_ROLES ? process.env.ADDRES_ROLES.split(',') : [];

const hasPermission = (member) => {
    if (allowedRoles.length === 0) return false;
    return member.roles.cache.some(role => allowedRoles.includes(role.id));
};

module.exports = {
    execute(client, message) {
        const args = message.content.split(' ');
        const command = args.shift();

        if (command === `${process.env.PREFIX}upres`) {
            // التحقق من الصلاحيات
            if (!hasPermission(message.member)) {
                return message.reply('❌ You do not have permission to use this command.');
            }

            // معالجة المدخلات
            const trigger = args[0]?.replace(/['"]+/g, '').trim();
            const response = args.slice(1).join(' ')?.replace(/['"]+/g, '').trim();

            // التحقق من المدخلات
            if (!trigger || !response) {
                return message.reply('❌ Please enter both the trigger and new response. Example: `!upres "Trigger" "New Response"`');
            }

            // قراءة البيانات الحالية
            let data = {};
            if (fs.existsSync(filePath)) {
                try {
                    data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
                } catch (error) {
                    console.error('Error reading addres.json:', error);
                    return message.reply('❌ An error occurred while reading responses data.');
                }
            }

            // تحديث الرد
            if (data[trigger]) {
                data[trigger] = response;
                try {
                    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
                    return message.reply(`✅ Auto response updated: **"${trigger}"** => **"${response}"**`);
                } catch (error) {
                    console.error('Error writing to addres.json:', error);
                    return message.reply('❌ Failed to update the response.');
                }
            } else {
                return message.reply(`❌ Trigger **"${trigger}"** does not exist.`);
            }
        }
    }
};