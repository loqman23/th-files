const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'data', 'addres.json');
const allowedRoles = process.env.ADDRES_ROLES ? process.env.ADDRES_ROLES.split(',') : [];

const hasPermission = (member) => {
    if (allowedRoles.length === 0) return false; // إذا لم يتم تحديد أي رتب
    return member.roles.cache.some(role => allowedRoles.includes(role.id));
};

module.exports = {
    execute(client, message) {
        const args = message.content.split(' ');
        const command = args.shift();

        if (command === `${process.env.PREFIX}removeres`) {
            if (!hasPermission(message.member)) {
                return message.reply('❌ You do not have permission to use this command.');
            }

            const trigger = args[0]?.replace(/['"]+/g, '');

            if (!trigger) {
                return message.reply('❌ Please enter a trigger. Example: `!removeres "Trigger"`');
            }

            let data = {};
            if (fs.existsSync(filePath)) {
                data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            }

            if (data[trigger]) {
                delete data[trigger];
                fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

                return message.reply(`✅ Auto response removed: **"${trigger}"**`);
            } else {
                return message.reply(`❌ Trigger **"${trigger}"** does not exist.`);
            }
        }
    }
};