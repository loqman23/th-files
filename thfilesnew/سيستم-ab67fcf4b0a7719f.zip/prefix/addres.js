const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'data', 'addres.json');
const allowedRoles = process.env.ADDRES_ROLES ? process.env.ADDRES_ROLES.split(',') : [];

const hasPermission = (member) => {
    if (allowedRoles.length === 0) return false; // إذا لم يتم تحديد أي رتب
    return member.roles.cache.some(role => allowedRoles.includes(role.id));
};

module.exports = {
    execute(client, message) {
        const args = message.content.split(' ');
        const command = args.shift();

        if (command === `${process.env.PREFIX}addres`) {
            if (!hasPermission(message.member)) {
                return message.reply('❌ You do not have permission to use this command.');
            }

            const trigger = args[0]?.replace(/['"]+/g, '');
            const response = args.slice(1).join(' ')?.replace(/['"]+/g, '');

            if (!trigger || !response) {
                return message.reply('❌ Please enter both trigger and response. Example: `!addres "Trigger" "Response"`');
            }

            let data = {};
            if (fs.existsSync(filePath)) {
                data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            }

            data[trigger] = response;
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

            return message.reply(`✅ Auto response added: **"${trigger}"** => **"${response}"**`);
        }
    }
};