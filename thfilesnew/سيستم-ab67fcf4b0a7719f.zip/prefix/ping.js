module.exports = {
    execute(client, message) {
        if (message.content === `${process.env.PREFIX}ping`) {
            message.reply('im worked now');
        }
    }
};