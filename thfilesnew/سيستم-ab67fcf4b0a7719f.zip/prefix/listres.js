const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'data', 'addres.json');

module.exports = {
    execute(client, message) {
        const args = message.content.split(' ');
        const command = args.shift();

        if (command === `${process.env.PREFIX}listres`) {
            if (!fs.existsSync(filePath)) {
                return message.reply('❌ No auto responses have been added.');
            }

            const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            const triggers = Object.keys(data);
            if (triggers.length === 0) {
                return message.reply('❌ No auto responses have been added.');
            }

            const itemsPerPage = 5;
            const totalPages = Math.ceil(triggers.length / itemsPerPage);

            let currentPage = 0;

            const generateEmbed = (page) => {
                const start = page * itemsPerPage;
                const end = start + itemsPerPage;
                const entries = triggers.slice(start, end);

                const embed = new EmbedBuilder()
                    .setColor(0x3498db)
                    .setTitle('📜 Auto Responses List')
                    .setFooter({ text: `Page ${page + 1} of ${totalPages}` })
                    .setTimestamp();

                entries.forEach((trigger, index) => {
                    embed.addFields({ name: `**${start + index + 1}. ${trigger}**`, value: `${data[trigger]}` });
                });

                return embed;
            };

            const embed = generateEmbed(currentPage);

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('prev')
                        .setLabel('⬅️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === 0),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('➡️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === totalPages - 1)
                );

            message.channel.send({ embeds: [embed], components: [row] }).then((msg) => {
                const filter = (interaction) =>
                    interaction.isButton() && interaction.message.id === msg.id && interaction.user.id === message.author.id;

                const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

                collector.on('collect', (interaction) => {
                    if (interaction.customId === 'prev' && currentPage > 0) {
                        currentPage--;
                    } else if (interaction.customId === 'next' && currentPage < totalPages - 1) {
                        currentPage++;
                    }

                    const updatedEmbed = generateEmbed(currentPage);

                    const updatedRow = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('prev')
                                .setLabel('⬅️')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(currentPage === 0),
                            new ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('➡️')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(currentPage === totalPages - 1)
                        );

                    interaction.update({ embeds: [updatedEmbed], components: [updatedRow] });
                });

                collector.on('end', () => {
                    const disabledRow = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('prev')
                                .setLabel('⬅️')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(true),
                            new ButtonBuilder()
                                .setCustomId('next')
                                .setLabel('➡️')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(true)
                        );

                    msg.edit({ components: [disabledRow] }).catch(() => {});
                });
            });
        }
    }
};