const { Client, GatewayIntentBits, PermissionsBitField, EmbedBuilder, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ActivityType, ChannelType, ApplicationCommandOptionType, StringSelectMenuBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

// إعدادات البوت
const DISCORD_TOKEN = ""; // توكنك
const CLIENT_ID = ""; // ايدي البوت
const YOUTUBE_CHANNEL = "https://youtube.com/@n-muc?si=H05Z3PX9h1WF-12X";// رابط قناتك

// إنشاء العميل
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ],
});

// إنشاء مجلد قواعد البيانات إذا لم يكن موجوداً
const DB_FOLDER = "./databases";
if (!fs.existsSync(DB_FOLDER)) {
    fs.mkdirSync(DB_FOLDER);
}

// دالة لتحميل قاعدة بيانات سيرفر معين
function loadGuildDatabase(guildId) {
    const dbPath = path.join(DB_FOLDER, `${guildId}.json`);
    try {
        if (fs.existsSync(dbPath)) {
            return JSON.parse(fs.readFileSync(dbPath, "utf8"));
        }
    } catch (error) {
        console.error(`خطأ في تحميل قاعدة بيانات السيرفر ${guildId}:`, error);
    }
    return {
        guildId: guildId,
        guildName: "",
        joinedAt: new Date().toISOString(),
        settings: {
            language: "ar",
            deleteConfirmation: true,
            logChannel: null,
            deleteLinksEnabled: false,
            allowedRoleId: null
        },
        stats: {
            totalDeletes: 0,
            categoriesDeleted: 0,
            channelsDeleted: 0,
            lastActivity: new Date().toISOString()
        },
        history: []
    };
}

// دالة لحفظ قاعدة بيانات سيرفر معين
function saveGuildDatabase(guildId, data) {
    const dbPath = path.join(DB_FOLDER, `${guildId}.json`);
    try {
        data.stats.lastActivity = new Date().toISOString();
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(`خطأ في حفظ قاعدة بيانات السيرفر ${guildId}:`, error);
    }
}

// دالة لإضافة سجل في التاريخ
function addToHistory(guildId, action, details, userId) {
    const db = loadGuildDatabase(guildId);
    db.history.push({
        timestamp: new Date().toISOString(),
        action: action,
        details: details,
        userId: userId,
        id: Date.now()
    });
    
    // الاحتفاظ بآخر 50 سجل فقط
    if (db.history.length > 50) {
        db.history = db.history.slice(-50);
    }
    
    saveGuildDatabase(guildId, db);
}

// دالة للتحقق من الصلاحيات
function hasAdminPermission(member) {
    return member.permissions.has(PermissionsBitField.Flags.Administrator);
}

// دالة لإنشاء Embed جميل
function createEmbed(title, description, color = 0x00AE86) {
    return new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setFooter({ 
            text: "N-MUC Bot | قناة N-MUC على يوتيوب", 
            iconURL: client.user?.displayAvatarURL() 
        })
        .setTimestamp();
}

// أمر حذف الكاتجوري
async function deleteCategory(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const category = interaction.options.getChannel("category");
    
    if (!category || category.type !== ChannelType.GuildCategory) {
        const embed = createEmbed(
            "❌ خطأ",
            "يرجى تحديد كاتجوري صحيح.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const channels = category.children.cache;
    const channelCount = channels.size;

    const embed = createEmbed(
        "⚠️ تأكيد حذف الكاتجوري",
        `هل أنت متأكد من حذف الكاتجوري **${category.name}**؟\n\n` +
        `📊 **عدد الرومات:** ${channelCount}\n` +
        `📝 **أسماء الرومات:**\n${channels.map(ch => `• ${ch.name}`).join("\n") || "لا توجد رومات"}\n\n` +
        `⚠️ **تحذير:** هذا الإجراء لا يمكن التراجع عنه!`,
        0xFFAA00
    );

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`confirm_delete_category_${category.id}`)
                .setLabel("نعم، احذف")
                .setStyle(ButtonStyle.Danger)
                .setEmoji("🗑️"),
            new ButtonBuilder()
                .setCustomId("cancel_delete")
                .setLabel("إلغاء")
                .setStyle(ButtonStyle.Secondary)
                .setEmoji("❌")
        );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

// أمر حذف الرومات بالاسم
async function deleteRoomsByName(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const namePrefix = interaction.options.getString("name");
    
    if (!namePrefix || namePrefix.length < 1) {
        const embed = createEmbed(
            "❌ خطأ",
            "يرجى إدخال اسم أو بداية اسم الرومات المراد حذفها.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const guild = interaction.guild;
    const matchingChannels = guild.channels.cache.filter(channel => 
        channel.name.toLowerCase().startsWith(namePrefix.toLowerCase()) && 
        (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice) 
    );

    if (matchingChannels.size === 0) {
        const embed = createEmbed(
            "❌ لم يتم العثور على رومات",
            `لم يتم العثور على أي رومات تبدأ بـ **${namePrefix}**`,
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const channelList = matchingChannels.map(ch => `• ${ch.name} (${ch.type === ChannelType.GuildText ? "نص" : "صوت"})`).join("\n");
    
    const embed = createEmbed(
        "⚠️ تأكيد حذف الرومات",
        `تم العثور على **${matchingChannels.size}** روم تبدأ بـ **${namePrefix}**:\n\n` +
        `📝 **الرومات المطابقة:**\n${channelList}\n\n` +
        `⚠️ **تحذير:** هذا الإجراء لا يمكن التراجع عنه!`,
        0xFFAA00
    );

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`confirm_delete_rooms_${namePrefix}`)
                .setLabel("نعم، احذف الكل")
                .setStyle(ButtonStyle.Danger)
                .setEmoji("🗑️"),
            new ButtonBuilder()
                .setCustomId("cancel_delete")
                .setLabel("إلغاء")
                .setStyle(ButtonStyle.Secondary)
                .setEmoji("❌")
        );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

// معالج الأزرار
async function handleButtonInteraction(interaction) {
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (interaction.customId === "cancel_delete") {
        const embed = createEmbed(
            "✅ تم الإلغاء",
            "تم إلغاء عملية الحذف بنجاح.",
            0x00FF00
        );
        return interaction.update({ embeds: [embed], components: [] });
    }

    if (interaction.customId.startsWith("confirm_delete_category_")) {
        const categoryId = interaction.customId.split("_")[3];
        const category = interaction.guild.channels.cache.get(categoryId);
        
        if (!category) {
            const embed = createEmbed(
                "❌ خطأ",
                "لم يتم العثور على الكاتجوري.",
                0xFF0000
            );
            return interaction.update({ embeds: [embed], components: [] });
        }

        try {
            const channels = category.children.cache;
            let deletedCount = 0;
            const channelNames = [];

            // حذف جميع الرومات في الكاتجوري
            for (const channel of channels.values()) {
                channelNames.push(channel.name);
                await channel.delete();
                deletedCount++;
            }

            // حذف الكاتجوري نفسه
            await category.delete();

            // تحديث الإحصائيات
            const db = loadGuildDatabase(guildId);
            db.stats.totalDeletes++;
            db.stats.categoriesDeleted++;
            db.stats.channelsDeleted += deletedCount;
            saveGuildDatabase(guildId, db);

            // إضافة السجل
            addToHistory(guildId, "delete_category", {
                categoryName: category.name,
                channelsDeleted: deletedCount,
                channelNames: channelNames
            }, userId);

            const embed = createEmbed(
                "✅ تم الحذف بنجاح",
                `تم حذف الكاتجوري **${category.name}** مع **${deletedCount}** روم بنجاح.\n\n` +
                `📊 **إجمالي عمليات الحذف في هذا السيرفر:** ${db.stats.totalDeletes}`,
                0x00FF00
            );
            
            await interaction.update({ embeds: [embed], components: [] });

        } catch (error) {
            console.error("خطأ في حذف الكاتجوري:", error);
            const embed = createEmbed(
                "❌ خطأ في الحذف",
                "حدث خطأ أثناء حذف الكاتجوري. تأكد من أن البوت لديه الصلاحيات الكافية.",
                0xFF0000
            );
            await interaction.update({ embeds: [embed], components: [] });
        }
    }

    if (interaction.customId.startsWith("confirm_delete_rooms_")) {
        const namePrefix = interaction.customId.split("_")[3];
        const guild = interaction.guild;
        
        const matchingChannels = guild.channels.cache.filter(channel => 
            channel.name.toLowerCase().startsWith(namePrefix.toLowerCase()) && 
            (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice)
        );

        try {
            let deletedCount = 0;
            const channelNames = [];
            
            for (const channel of matchingChannels.values()) {
                channelNames.push(channel.name);
                await channel.delete();
                deletedCount++;
            }

            // تحديث الإحصائيات
            const db = loadGuildDatabase(guildId);
            db.stats.totalDeletes++;
            db.stats.channelsDeleted += deletedCount;
            saveGuildDatabase(guildId, db);

            // إضافة السجل
            addToHistory(guildId, "delete_rooms_by_name", {
                namePrefix: namePrefix,
                channelsDeleted: deletedCount,
                channelNames: channelNames
            }, userId);

            const embed = createEmbed(
                "✅ تم الحذف بنجاح",
                `تم حذف **${deletedCount}** روم تبدأ بـ **${namePrefix}** بنجاح.\n\n` +
                `📊 **إجمالي عمليات الحذف في هذا السيرفر:** ${db.stats.totalDeletes}`,
                0x00FF00
            );
            
            await interaction.update({ embeds: [embed], components: [] });

        } catch (error) {
            console.error("خطأ في حذف الرومات:", error);
            const embed = createEmbed(
                "❌ خطأ في الحذف",
                "حدث خطأ أثناء حذف الرومات. تأكد من أن البوت لديه الصلاحيات الكافية.",
                0xFF0000
            );
            await interaction.update({ embeds: [embed], components: [] });
        }
    }
}

// أمر المساعدة
async function helpCommand(interaction) {
    const embed = createEmbed(
        "📚 مساعدة البوت",
        `مرحباً بك في بوت إدارة السيرفر! 🎉\n\n` +
        `**🔧 الأوامر المتاحة:**\n\n` +
        `\`/delete-category\` - حذف كاتجوري مع جميع الرومات الموجودة فيه (للمشرفين)\n` +
        `\`/delete-room\` - حذف الرومات التي تبدأ بنص معين (للمشرفين)\n` +
        `\`/lock\` - قفل قناة معينة (للمشرفين)\n` +
        `\`/unlock\` - فتح قناة معينة (للمشرفين)\n` +
        `\`/ping\` - عرض سرعة استجابة البوت (للجميع)\n` +
        `\`/help\` - عرض هذه الرسالة (للجميع)\n` +
        `\`/info\` - معلومات عن البوت (للجميع)\n` +
        `\`/stats\` - إحصائيات السيرفر (للمشرفين)\n` +
        `\`/history\` - تاريخ العمليات (للمشرفين)\n` +
        `\`/add-reply\` - إضافة رد تلقائي لكلمات محددة (للمشرفين)\n` +
        `\`/reply\` - عرض جميع الردود التلقائية مع خيارات الحذف (للمشرفين)\n` +
        `\`/delete_link\` - تفعيل/تعطيل منع الروابط مع تحديد رتبة مسموحة (للمشرفين)\n\n` +
        `**⚠️ ملاحظة مهمة:**\n` +
        `• يجب أن تكون لديك صلاحية \`Administrator\` لاستخدام أوامر الحذف والقفل/الفتح وإدارة الردود ومنع الروابط\n` +
        `• جميع عمليات الحذف نهائية ولا يمكن التراجع عنها\n` +
        `• كل سيرفر له قاعدة بيانات منفصلة\n\n` +
        `**🎥 قناة المطور:**\n[N-MUC على يوتيوب](${YOUTUBE_CHANNEL})`,
        0x00AE86
    );

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

// أمر معلومات البوت
async function infoCommand(interaction) {
    const guild = interaction.guild;
    const db = loadGuildDatabase(guild.id);
    
    const embed = createEmbed(
        "📊 معلومات البوت",
        `**🤖 اسم البوت:** ${client.user.username}\n` +
        `**🆔 معرف البوت:** ${client.user.id}\n` +
        `**📅 تاريخ الإنشاء:** <t:${Math.floor(client.user.createdTimestamp / 1000)}:F>\n` +
        `**🌐 عدد السيرفرات:** ${client.guilds.cache.size}\n` +
        `**👥 عدد المستخدمين:** ${client.users.cache.size}\n\n` +
        `**📈 إحصائيات السيرفر الحالي:**\n` +
        `• **الأعضاء:** ${guild.memberCount}\n` +
        `• **الرومات:** ${guild.channels.cache.size}\n` +
        `• **الأدوار:** ${guild.roles.cache.size}\n` +
        `• **انضم البوت:** <t:${Math.floor(new Date(db.joinedAt).getTime() / 1000)}:R>\n\n` +
        `**🎥 قناة المطور:**\n[N-MUC على يوتيوب](${YOUTUBE_CHANNEL})\n\n` +
        `**💻 تم تطوير البوت بواسطة:** N-MUC`,
        0x00AE86
    );

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

// أمر الإحصائيات
async function statsCommand(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    const guildId = interaction.guild.id;
    const db = loadGuildDatabase(guildId);
    
    const embed = createEmbed(
        "📊 إحصائيات السيرفر",
        `**🗑️ إجمالي عمليات الحذف:** ${db.stats.totalDeletes}\n` +
        `**📁 الكاتجوريات المحذوفة:** ${db.stats.categoriesDeleted}\n` +
        `**💬 الرومات المحذوفة:** ${db.stats.channelsDeleted}\n` +
        `**📅 آخر نشاط:** <t:${Math.floor(new Date(db.stats.lastActivity).getTime() / 1000)}:R>\n` +
        `**📝 عدد السجلات:** ${db.history.length}\n\n` +
        `**ℹ️ معلومات قاعدة البيانات:**\n` +
        `• **معرف السيرفر:** \`${db.guildId}\`\n` +
        `• **اسم السيرفر:** ${db.guildName || interaction.guild.name}\n` +
        `• **تاريخ الانضمام:** <t:${Math.floor(new Date(db.joinedAt).getTime() / 1000)}:F>`,
        0x00AE86
    );

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

// أمر التاريخ
async function historyCommand(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    const guildId = interaction.guild.id;
    const db = loadGuildDatabase(guildId);
    
    if (db.history.length === 0) {
        const embed = createEmbed(
            "📝 تاريخ العمليات",
            "لا توجد عمليات مسجلة في هذا السيرفر بعد.",
            0xFFAA00
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const recentHistory = db.history.slice(-10).reverse(); // آخر 10 عمليات
    
    let historyText = "";
    recentHistory.forEach((entry, index) => {
        const timestamp = `<t:${Math.floor(new Date(entry.timestamp).getTime() / 1000)}:R>`;
        const action = entry.action === "delete_category" ? "🗂️ حذف كاتجوري" : "💬 حذف رومات";
        const user = `<@${entry.userId}>`;
        
        historyText += `**${index + 1}.** ${action} - ${timestamp}\n`;
        historyText += `👤 **المستخدم:** ${user}\n`;
        
        if (entry.action === "delete_category") {
            historyText += `📁 **الكاتجوري:** ${entry.details.categoryName}\n`;
            historyText += `🔢 **الرومات المحذوفة:** ${entry.details.channelsDeleted}\n`;
        } else {
            historyText += `🔍 **البحث:** ${entry.details.namePrefix}\n`;
            historyText += `🔢 **الرومات المحذوفة:** ${entry.details.channelsDeleted}\n`;
        }
        historyText += "\n";
    });

    const embed = createEmbed(
        "📝 تاريخ العمليات (آخر 10 عمليات)",
        historyText,
        0x00AE86
    );

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

// أمر Ping
async function pingCommand(interaction) {
    const sent = await interaction.reply({ content: "جاري حساب سرعة الاستجابة...", ephemeral: true, fetchReply: true });
    const ping = sent.createdTimestamp - interaction.createdTimestamp;
    const embed = createEmbed(
        "🏓 سرعة الاستجابة",
        `سرعة استجابة البوت: **${ping}ms**\n` +
        `سرعة استجابة API ديسكورد: **${client.ws.ping}ms**`,
        0x00AE86
    );
    await interaction.editReply({ embeds: [embed], content: null });
}

// أمر قفل القناة
async function lockChannelCommand(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const channel = interaction.options.getChannel("channel") || interaction.channel;
    const role = interaction.guild.roles.everyone;

    try {
        await channel.permissionOverwrites.edit(role, {
            SendMessages: false
        });
        const embed = createEmbed(
            "🔒 تم قفل القناة",
            `تم قفل قناة ${channel} بنجاح. لا يمكن لأي شخص إرسال الرسائل الآن.`, 
            0xFFAA00
        );
        await interaction.reply({ embeds: [embed] });
    } catch (error) {
        console.error("خطأ في قفل القناة:", error);
        const embed = createEmbed(
            "❌ خطأ",
            "حدث خطأ أثناء قفل القناة. تأكد من أن البوت لديه الصلاحيات الكافية.",
            0xFF0000
        );
        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
}

// أمر فتح القناة
async function unlockChannelCommand(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const channel = interaction.options.getChannel("channel") || interaction.channel;
    const role = interaction.guild.roles.everyone;

    try {
        await channel.permissionOverwrites.edit(role, {
            SendMessages: true
        });
        const embed = createEmbed(
            "🔓 تم فتح القناة",
            `تم فتح قناة ${channel} بنجاح. يمكن للجميع إرسال الرسائل الآن.`, 
            0x00FF00
        );
        await interaction.reply({ embeds: [embed] });
    } catch (error) {
        console.error("خطأ في فتح القناة:", error);
        const embed = createEmbed(
            "❌ خطأ",
            "حدث خطأ أثناء فتح القناة. تأكد من أن البوت لديه الصلاحيات الكافية.",
            0xFF0000
        );
        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
}

// أمر منع الروابط
async function deleteLinkCommand(interaction) {
    if (!hasAdminPermission(interaction.member)) {
        const embed = createEmbed(
            "❌ خطأ في الصلاحيات",
            "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
            0xFF0000
        );
        return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const status = interaction.options.getString("status");
    const allowedRole = interaction.options.getRole("allowed_role");
    const guildId = interaction.guildId;
    const db = loadGuildDatabase(guildId);
    
    db.settings.deleteLinksEnabled = status === "yes";
    db.settings.allowedRoleId = allowedRole ? allowedRole.id : null;
    saveGuildDatabase(guildId, db);
    
    const embed = createEmbed(
        "✅ تم تحديث الإعدادات",
        `ميزة منع الروابط: **${status === "yes" ? "مفعلة" : "معطلة"}**\n` +
        `الرتبة المسموح لها: **${allowedRole ? allowedRole.name : "لا يوجد"}**`,
        0x00FF00
    );
    await interaction.reply({ embeds: [embed], ephemeral: true });
}

// دالة لقراءة قاعدة البيانات للردود
function getDatabase() {
    const dbPath = path.join(__dirname, 'reply_database.json');
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, '{}');
        return {};
    }
    const rawData = fs.readFileSync(dbPath);
    return JSON.parse(rawData);
}

// دالة لحفظ قاعدة البيانات للردود
function saveDatabase(data) {
    const dbPath = path.join(__dirname, 'reply_database.json');
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

// دالة لتحميل ردود سيرفر معين
function getServerReplies(guildId) {
    const db = getDatabase();
    return db[guildId] || [];
}

// دالة لحفظ ردود سيرفر معين
function saveServerReplies(guildId, replies) {
    const db = getDatabase();
    db[guildId] = replies;
    saveDatabase(db);
}

// تسجيل الأوامر
const commands = [
    new SlashCommandBuilder()
        .setName("delete-category")
        .setDescription("حذف كاتجوري مع جميع الرومات الموجودة فيه")
        .addChannelOption(option =>
            option.setName("category")
                .setDescription("الكاتجوري المراد حذفه")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildCategory) 
        ),
    
    new SlashCommandBuilder()
        .setName("delete-room")
        .setDescription("حذف الرومات التي تبدأ بنص معين")
        .addStringOption(option =>
            option.setName("name")
                .setDescription("بداية اسم الرومات المراد حذفها")
                .setRequired(true)
        ),
    
    new SlashCommandBuilder()
        .setName("help")
        .setDescription("عرض مساعدة البوت"),
    
    new SlashCommandBuilder()
        .setName("info")
        .setDescription("معلومات عن البوت"),
    
    new SlashCommandBuilder()
        .setName("stats")
        .setDescription("إحصائيات السيرفر"),
    
    new SlashCommandBuilder()
        .setName("history")
        .setDescription("تاريخ العمليات في السيرفر"),

    new SlashCommandBuilder()
        .setName("ping")
        .setDescription("عرض سرعة استجابة البوت"),

    new SlashCommandBuilder()
        .setName("lock")
        .setDescription("قفل قناة معينة (للمشرفين فقط)")
        .addChannelOption(option =>
            option.setName("channel")
                .setDescription("القناة المراد قفلها")
                .setRequired(false)
                .addChannelTypes(ChannelType.GuildText, ChannelType.GuildVoice) 
        ),

    new SlashCommandBuilder()
        .setName("unlock")
        .setDescription("فتح قناة معينة (للمشرفين فقط)")
        .addChannelOption(option =>
            option.setName("channel")
                .setDescription("القناة المراد فتحها")
                .setRequired(false)
                .addChannelTypes(ChannelType.GuildText, ChannelType.GuildVoice) 
        ),
    
    new SlashCommandBuilder()
        .setName("add-reply")
        .setDescription("إضافة رد تلقائي لكلمات محددة")
        .addStringOption(option =>
            option.setName("words")
                .setDescription("الكلمات المطلوب الرد عليها")
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName("reply")
                .setDescription("الرد التلقائي")
                .setRequired(true)
        ),
    
    new SlashCommandBuilder()
        .setName("reply")
        .setDescription("عرض جميع الردود التلقائية مع خيارات الحذف"),
    
    new SlashCommandBuilder()
        .setName("delete_link")
        .setDescription("تفعيل أو تعطيل ميزة منع الروابط")
        .addStringOption(option =>
            option.setName("status")
                .setDescription("تفعيل أو تعطيل الميزة (yes/no)")
                .setRequired(true)
                .addChoices(
                    { name: "yes", value: "yes" },
                    { name: "no", value: "no" }
                )
        )
        .addRoleOption(option =>
            option.setName("allowed_role")
                .setDescription("الرتبة المسموح لها بإرسال الروابط")
                .setRequired(false)
        ),
];

// أحداث البوت
client.once("ready", async () => {
    console.log(`✅ تم تسجيل الدخول باسم ${client.user.tag}!`);
    
    // تعيين حالة البوت
    client.user.setActivity("N-MUC YouTube Channel", { type: ActivityType.Watching });
    
    // تسجيل الأوامر
    try {
        console.log("🔄 بدء تحديث أوامر التطبيق...");
        await client.application.commands.set(commands);
        console.log("✅ تم تحديث أوامر التطبيق بنجاح!");
    } catch (error) {
        console.error("❌ خطأ في تسجيل الأوامر:", error);
    }
});

// عند انضمام البوت لسيرفر جديد
client.on("guildCreate", async guild => {
    console.log(`🎉 تم إضافة البوت لسيرفر جديد: ${guild.name} (${guild.id})`);
    
    // إنشاء قاعدة بيانات خاصة بالسيرفر
    const db = loadGuildDatabase(guild.id);
    db.guildName = guild.name;
    db.joinedAt = new Date().toISOString();
    saveGuildDatabase(guild.id, db);
    
    // إرسال رسالة ترحيب للمالك
    try {
        const owner = await guild.fetchOwner();
        const welcomeEmbed = createEmbed(
            "🎉 مرحباً بك في بوت N-MUC!",
            `شكراً لك لإضافة البوت إلى سيرفر **${guild.name}**!\n\n` +
            `**🔧 للبدء:**\n` +
            `• استخدم الأمر \`/help\` لعرض جميع الأوامر المتاحة\n` +
            `• تأكد من أن البوت لديه الصلاحيات الكافية\n` +
            `• تم إنشاء قاعدة بيانات خاصة بسيرفرك\n\n` +
            `**🎥 لا تنس زيارة قناتنا:**\n[N-MUC على يوتيوب](${YOUTUBE_CHANNEL})`,
            0x00FF00
        );
        
        await owner.send({ embeds: [welcomeEmbed] });
    } catch (error) {
        console.log("لا يمكن إرسال رسالة ترحيب للمالك");
    }
});

// معالج التفاعلات
client.on("interactionCreate", async interaction => {
    if (interaction.isCommand()) {
        const { commandName } = interaction;

        // الأوامر المتاحة للجميع
        if (["help", "info", "ping"].includes(commandName)) {
            switch (commandName) {
                case "help":
                    await helpCommand(interaction);
                    break;
                case "info":
                    await infoCommand(interaction);
                    break;
                case "ping":
                    await pingCommand(interaction);
                    break;
            }
        } else {
            // التحقق من صلاحيات المشرف
            if (!hasAdminPermission(interaction.member)) {
                const embed = createEmbed(
                    "❌ خطأ في الصلاحيات",
                    "ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر.\nيجب أن تكون لديك صلاحية **Administrator**.",
                    0xFF0000
                );
                return interaction.reply({ embeds: [embed], ephemeral: true });
            }

            switch (commandName) {
                case "delete-category":
                    await deleteCategory(interaction);
                    break;
                case "delete-room":
                    await deleteRoomsByName(interaction);
                    break;
                case "stats":
                    await statsCommand(interaction);
                    break;
                case "history":
                    await historyCommand(interaction);
                    break;
                case "lock":
                    await lockChannelCommand(interaction);
                    break;
                case "unlock":
                    await unlockChannelCommand(interaction);
                    break;
                case "add-reply":
                    const words = interaction.options.getString("words");
                    const replyText = interaction.options.getString("reply");
                    const guildId = interaction.guildId;
                    const replies = getServerReplies(guildId);
                    replies.push({ id: Date.now().toString(), words, reply: replyText });
                    saveServerReplies(guildId, replies);
                    await interaction.reply({
                        content: `✅ تم إضافة رد تلقائي للكلمات: \`${words}\`\nالرد: \`${replyText}\``,
                        ephemeral: true
                    });
                    break;
                case "reply":
                    const repliesList = getServerReplies(interaction.guildId);
                    if (repliesList.length === 0) {
                        return interaction.reply({
                            content: "⚠️ لا توجد ردود تلقائية في هذا السيرفر!",
                            ephemeral: true
                        });
                    }
                    const embed = new EmbedBuilder()
                        .setTitle("📝 الردود التلقائية للسيرفر")
                        .setColor("#3498db")
                        .setDescription("اختر رداً من القائمة لحذفه:");
                    const options = repliesList.map(reply => ({
                        label: `${reply.words.substring(0, 40)}${reply.words.length > 40 ? "..." : ""}`,
                        description: `ID: ${reply.id} | الرد: ${reply.reply.substring(0, 30)}...`,
                        value: reply.id
                    }));
                    const menu = new StringSelectMenuBuilder()
                        .setCustomId("delete-reply")
                        .setPlaceholder("اختر رداً لحذفه")
                        .addOptions(options);
                    const row = new ActionRowBuilder().addComponents(menu);
                    await interaction.reply({
                        embeds: [embed],
                        components: [row],
                        ephemeral: true
                    });
                    break;
                case "delete_link":
                    await deleteLinkCommand(interaction);
                    break;
                default:
                    const unknownEmbed = createEmbed(
                        "❌ أمر غير معروف",
                        "هذا الأمر غير موجود. استخدم `/help` لعرض الأوامر المتاحة.",
                        0xFF0000
                    );
                    await interaction.reply({ embeds: [unknownEmbed], ephemeral: true });
            }
        }
    } else if (interaction.isButton()) {
        await handleButtonInteraction(interaction);
    } else if (interaction.isStringSelectMenu() && interaction.customId === "delete-reply") {
        const replyId = interaction.values[0];
        const guildId = interaction.guildId;
        let replies = getServerReplies(guildId);
        const initialLength = replies.length;
        replies = replies.filter(reply => reply.id !== replyId);
        if (replies.length === initialLength) {
            return interaction.update({
                content: "❌ لم يتم العثور على الرد المحدد!",
                components: [],
                embeds: []
            });
        }
        saveServerReplies(guildId, replies);
        await interaction.update({
            content: `✅ تم حذف الرد التلقائي بنجاح! (ID: ${replyId})`,
            components: [],
            embeds: []
        });
    }
});

// نظام الرد التلقائي على الرسائل ومنع الروابط
client.on("messageCreate", async message => {
    if (message.author.bot) return;
    
    const guildId = message.guildId;
    const db = loadGuildDatabase(guildId);
    
    // منع الروابط
    if (db.settings.deleteLinksEnabled) {
        const urlRegex = /(https?:\/\/[^\s]+|\.com|discord\.gg)/g;
        if (urlRegex.test(message.content)) {
            const allowedRoleId = db.settings.allowedRoleId;
            if (!allowedRoleId || !message.member.roles.cache.has(allowedRoleId)) {
                await message.delete();
                await message.channel.send({
                    content: `${message.author}, لا يمكنك إرسال روابط هنا!`,
                    ephemeral: true
                });
                return;
            }
        }
    }
    
    // الردود التلقائية
    const replies = getServerReplies(guildId);
    const content = message.content.toLowerCase();
    for (const reply of replies) {
        if (content.includes(reply.words.toLowerCase())) {
            message.reply(reply.reply);
            break;
        }
    }
});

// تشغيل البوت
client.login(DISCORD_TOKEN);