module.exports = {
    bot: {
        token: 'YOUR_BOT_TOKEN_HERE',
        prefix: '$'
    },
    presence: {
        status: 'idle',
        activity: {
            name: 'By Dark <3',
            type: 'Streaming',
            url: 'https://twitch.tv/id5g'
        }
    }
};