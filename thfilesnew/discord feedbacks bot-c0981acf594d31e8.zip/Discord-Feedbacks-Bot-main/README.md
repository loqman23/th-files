# Discord-Feedbacks-Bot

1 -
```sh
git clone https://github.com/id5g/Discord-Feedbacks-Bot.git
cd Discord-Feedbacks-Bot
```

2 -
```
npm i
```

3 - 
```
node .
```

**Leave A Start On The Repo (:**
