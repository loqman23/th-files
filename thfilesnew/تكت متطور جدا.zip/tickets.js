const {

  Events,

  ModalBuilder,

  TextInputBuilder,

  TextInputStyle,

  ActionRowBuilder,

  EmbedBuilder,

  PermissionFlagsBits,

  ChannelType,

  StringSelectMenuBuilder,

  ButtonBuilder,

  ButtonStyle

} = require('discord.js');

const fs = require('fs');

const path = require('path');

const discordTranscripts = require('discord-html-transcripts');

const configPath = path.join(__dirname, '../data/ticketConfig.json');

const statsPath = path.join(__dirname, '../data/ticketStats.json');

if (!fs.existsSync(statsPath)) fs.writeFileSync(statsPath, '{}');

let ticketStats = JSON.parse(fs.readFileSync(statsPath, 'utf-8'));

const ticketMap = new Map();

module.exports = {

  name: Events.InteractionCreate,

  async execute(interaction) {

    const ticketConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

    // فتح المودال لفتح التكت

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('ticket-panel@')) {

      const [, guildId] = interaction.customId.split('@');

      const [, index] = interaction.values[0].split('@');

      const modal = new ModalBuilder()

        .setCustomId(`modal@${guildId}@${index}`)

        .setTitle('سبب فتح التكت؟');

      const reasonInput = new TextInputBuilder()

        .setCustomId('reason')

        .setLabel('اكتب سبب فتح التكت هنا')

        .setStyle(TextInputStyle.Paragraph)

        .setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));

      return interaction.showModal(modal);

    }

    // منشن داخل التكت

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('mention-select@')) {

      const [, guildId, channelId] = interaction.customId.split('@');

      const cfg = ticketConfig[guildId];

      if (!cfg) return;

      const info = ticketMap.get(channelId);

      if (!info) return;

      let mention;

      switch (interaction.values[0]) {

        case 'come': mention = `<@${info.creatorId}>`; break;

        case 'server_owner': mention = `<@${interaction.guild.ownerId}>`; break;

        case 'staff': mention = `<@&${cfg.staffRole}>`; break;

        default: return;

      }

      return interaction.reply({ content: mention });

    }

    // إجراءات التكت

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('action-select@')) {

      const [, guildId, channelId] = interaction.customId.split('@');

      const cfg = ticketConfig[guildId];

      if (!cfg) return;

      const info = ticketMap.get(channelId);

      if (!info) return;

      const action = interaction.values[0];

      switch (action) {

        case 'claim': {

          if (!interaction.member.roles.cache.has(cfg.staffRole))

            return interaction.reply({ content: 'ليس لديك الصلاحية للمطالبة', ephemeral: true });

          if (info.claimerId)

            return interaction.reply({ content: 'لقد تم استلام التكت بالفعل', ephemeral: true });

          await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { ViewChannel: false });

          await interaction.channel.permissionOverwrites.edit(interaction.member.id, { ViewChannel: true, SendMessages: true });

          info.claimerId = interaction.member.id;

          return interaction.reply({ content: 'تم استلام التكت ✅', ephemeral: true });

        }

        case 'close': {

          if (!interaction.member.roles.cache.has(ticketConfig[guildId].staffRole))

            return interaction.reply({ content: 'ليس لديك صلاحية إغلاق التكت', ephemeral: true });

          const modal = new ModalBuilder()

            .setCustomId(`modal-close@${guildId}@${channelId}`)

            .setTitle('سبب قفل التكت');

          const input = new TextInputBuilder()

            .setCustomId('closeReason')

            .setLabel('اكتب سبب قفل التكت')

            .setStyle(TextInputStyle.Paragraph)

            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(input));

          return interaction.showModal(modal);

        }

        case 'add': {

          if (!interaction.member.roles.cache.has(cfg.staffRole))

            return interaction.reply({ content: 'ليس لديك صلاحية إضافة مستخدم', ephemeral: true });

          const modal = new ModalBuilder()

            .setCustomId(`modal-add@${channelId}`)

            .setTitle('أدخل أيدي الشخص للإضافة');

          const input = new TextInputBuilder()

            .setCustomId('userId')

            .setLabel('User ID')

            .setStyle(TextInputStyle.Short)

            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(input));

          return interaction.showModal(modal);

        }

        case 'rename': {

          if (!interaction.member.roles.cache.has(cfg.staffRole))

            return interaction.reply({ content: 'ليس لديك صلاحية تغيير اسم التكت', ephemeral: true });

          const modal = new ModalBuilder()

            .setCustomId(`modal-rename@${channelId}`)

            .setTitle('أدخل الاسم الجديد للتكت');

          const input = new TextInputBuilder()

            .setCustomId('newName')

            .setLabel('New Name')

            .setStyle(TextInputStyle.Short)

            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(input));

          return interaction.showModal(modal);

        }

        case 'remove': {

          if (!interaction.member.roles.cache.has(cfg.staffRole))

            return interaction.reply({ content: 'ليس لديك صلاحية إزالة مستخدم', ephemeral: true });

          const modal = new ModalBuilder()

            .setCustomId(`modal-remove@${channelId}`)

            .setTitle('أدخل أيدي الشخص للإزالة');

          const input = new TextInputBuilder()

            .setCustomId('userId')

            .setLabel('User ID')

            .setStyle(TextInputStyle.Short)

            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(input));

          return interaction.showModal(modal);

        }

        default: return;

      }

    }

    // تعامل مع المودالات

    if (interaction.isModalSubmit()) {

      const [prefix, arg1, arg2] = interaction.customId.split('@');

      // فتح التكت

      if (prefix === 'modal') {

        const guildId = arg1;

        const index = parseInt(arg2, 10);

        const cfg = ticketConfig[guildId];

        const reason = interaction.fields.getTextInputValue('reason');

        // تحديث العداد

        ticketStats[guildId] = (ticketStats[guildId] || 0) + 1;

        fs.writeFileSync(statsPath, JSON.stringify(ticketStats, null, 2));

        const channelName = `ticket-${interaction.user.username}`;

        const category = await interaction.guild.channels.fetch(cfg.categoryId);

        const ticketChannel = await interaction.guild.channels.create({

          name: channelName,

          type: ChannelType.GuildText,

          parent: category,

          permissionOverwrites: [

            { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },

            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },

            { id: cfg.staffRole, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }

          ]

        });

        ticketMap.set(ticketChannel.id, {

          creatorId: interaction.user.id,

          reason,

          createdAt: new Date(),

          claimerId: null,

          ticketNumber: ticketStats[guildId],

          actionLabel: cfg.buttons[index]

        });
const info = ticketMap.get(ticketChannel.id);
        const embed = new EmbedBuilder()

          

          .setDescription(cfg.messageInTicket)

          .addFields(
              
         { name: 'رقم التذكرة', value: `#${info.ticketNumber}`, inline: true },

              { name: 'القسم', value: info.actionLabel, inline: true },

             
             { name: 'مشرفي التذكرة', value: `<@&${cfg.staffRole}>`, inline: true },
              
            { name: 'سبب فتح التكت؟', value: reason },

            { name: 'تم الإنشاء في', value: new Date().toLocaleString('ar-EG') }

          )

          .setColor(0x000000)

          .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

        if (cfg.imageInTicket) embed.setImage(cfg.imageInTicket);

        const mentionMenu = new StringSelectMenuBuilder()

          .setCustomId(`mention-select@${guildId}@${ticketChannel.id}`)

          .setPlaceholder('اختر منشن')

          .addOptions([

            { label: 'Come', value: 'come', emoji: '☎️' },

            { label: 'SERVER OWNER', value: 'server_owner', emoji: '💫' },

            { label: 'STAFF', value: 'staff', emoji: '📲' }

          ]);

        const actionMenu = new StringSelectMenuBuilder()

          .setCustomId(`action-select@${guildId}@${ticketChannel.id}`)

          .setPlaceholder('اختر إجراء')

          .addOptions([

            { label: 'Claim', value: 'claim', emoji: '✅' },

            { label: 'Close', value: 'close', emoji: '❌' },

            { label: 'Add User', value: 'add', emoji: '🟢' },

            { label: 'Rename', value: 'rename', emoji: '⚙️' },

            { label: 'Remove User', value: 'remove', emoji: '🔴' }

          ]);

        await ticketChannel.send({

          content: `<@&${cfg.staffRole}> <@${interaction.user.id}>`,

          embeds: [embed],

          components: [

            new ActionRowBuilder().addComponents(mentionMenu),

            new ActionRowBuilder().addComponents(actionMenu)

          ]

        });

        return interaction.reply({ content: `تم فتح التكت في ${ticketChannel}`, ephemeral: true });

      }

      // إغلاق التكت

      if (prefix === 'modal-close') {

        const guildId = arg1;

        const channelId = arg2;

        const cfg = ticketConfig[guildId];

        const info = ticketMap.get(channelId);

        const closeReason = interaction.fields.getTextInputValue('closeReason');

        await interaction.reply({ content: 'جاري إغلاق التكت...', ephemeral: true });

        setTimeout(async () => {

          // إنشاء الترانسكريبت ورفع الملف

          const transcript = await discordTranscripts.createTranscript(interaction.channel, {

            returnBuffer: false,

            fileName: `ticket-${channelId}.html`

          });



          const logCh = interaction.guild.channels.cache.get(cfg.logChannel);

          // إرسال الإيمбед ورفع الملف ثم إضافة أزرار

          const closeEmbed = new EmbedBuilder()

            .setTitle('التكت مغلق')

            .addFields(

              { name: 'رقم التذكرة', value: `#${info.ticketNumber}`, inline: true },

              { name: 'القسم', value: info.actionLabel, inline: true },

              { name: 'مشرفي التذكرة', value: `<@&${cfg.staffRole}>`, inline: true },

              { name: 'Created by', value: `<@${info.creatorId}>`, inline: true },

              { name: 'Claim by', value: `<@${info.claimerId || 'لايوجد'}>`, inline: true },

              { name: 'Closed by', value: `<@${interaction.user.id}>`, inline: true },

              { name: 'Opened at', value: info.createdAt.toLocaleString('ar-EG'), inline: true },

              { name: 'Closed at', value: new Date().toLocaleString('ar-EG'), inline: true },

              { name: 'سبب الإغلاق', value: closeReason },
                
                  

                { name: 'Reason', value: info.reason }
                

            )

            .setColor(0x000000)

            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

          // أولاً نرسل الإيمبد والملف

          const sentMessage = await logCh.send({ embeds: [closeEmbed], files: [transcript] });

          // ثم نضيف زرين: تحميل وفتح الرابط

          const url = sentMessage.attachments.first().url;

          const downloadButton = new ButtonBuilder()

            .setLabel('تحميل الترانسكريبت')

            .setStyle(ButtonStyle.Link)

            .setURL(url);

          const viewButton = new ButtonBuilder()

            .setLabel('عرض الترانسكريبت')

            .setStyle(ButtonStyle.Link)

            .setURL(url);

          await sentMessage.edit({ components: [new ActionRowBuilder().addComponents(downloadButton, viewButton)] });

          // إرسال DM لصاحب التكت

          try {

            const user = await interaction.client.users.fetch(info.creatorId);

            await user.send({ embeds: [closeEmbed], files: [transcript],components: [new ActionRowBuilder().addComponents(downloadButton, viewButton)] });

          } catch {}

          // حذف قناة التكت

          await interaction.channel.delete();

          ticketMap.delete(channelId);

        }, 5000);

        return;

      }

      // إضافة/إعادة تسمية/إزالة

      const channelId = arg1;

      const channel = interaction.guild.channels.cache.get(channelId);

      

      switch (prefix) {

        case 'modal-add': {

          const userId = interaction.fields.getTextInputValue('userId');

          await channel.permissionOverwrites.edit(userId, { ViewChannel: true, SendMessages: true });

          return interaction.reply({ content: `تم إضافة <@${userId}>`, ephemeral: true });

        }

        case 'modal-rename': {

          const newName = interaction.fields.getTextInputValue('newName');

          await channel.setName(newName);

          return interaction.reply({ content: `تم تغيير اسم التكت إلى **${newName}**`, ephemeral: true });

        }

        case 'modal-remove': {

          const userId = interaction.fields.getTextInputValue('userId');

          await channel.permissionOverwrites.edit(userId, { SendMessages: false });

          return interaction.reply({ content: `تمت إزالة <@${userId}>`, ephemeral: true });

        }

        default:

          return;

      }

    }

  }

};

