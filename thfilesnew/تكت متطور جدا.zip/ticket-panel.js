const {

  SlashCommandBuilder,

  PermissionFlagsBits,

  ChannelType,

  EmbedBuilder,

  StringSelectMenuBuilder,

  ActionRowBuilder

} = require('discord.js');

const fs = require('fs');

const path = require('path');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('set-panel-ticket')

    .setDescription('إعداد لوحة التذاكر العامة')

    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    .addChannelOption(opt =>

      opt

        .setName('logchannel')

        .setDescription('روم اللوق')

        .setRequired(true)

        .addChannelTypes(ChannelType.GuildText)

    )

    .addStringOption(opt => opt.setName('title').setDescription('Title ticket').setRequired(true))

    .addStringOption(opt => opt.setName('message_ticket').setDescription('Message ticket').setRequired(true))

    .addStringOption(opt => opt.setName('message_in_ticket').setDescription('Message in ticket').setRequired(true))

    .addStringOption(opt => opt.setName('button1').setDescription('Button 1').setRequired(true))

    .addChannelOption(opt =>

      opt

        .setName('category')

        .setDescription('Category ticket')

        .setRequired(true)

        .addChannelTypes(ChannelType.GuildCategory)

    )

    .addRoleOption(opt => opt.setName('staffrole').setDescription('ID ROLE STAFF').setRequired(true))

    .addStringOption(opt => opt.setName('button2').setDescription('Button 2'))

    .addStringOption(opt => opt.setName('button3').setDescription('Button 3'))

    .addStringOption(opt => opt.setName('button4').setDescription('Button 4'))

    .addStringOption(opt => opt.setName('image_ticket').setDescription('Image ticket URL'))

    .addStringOption(opt => opt.setName('image_in_ticket').setDescription('Image in ticket URL')),

  async execute(interaction) {

    const configPath = path.join(__dirname, '../../data/ticketConfig.json');

    if (!fs.existsSync(configPath)) fs.writeFileSync(configPath, '{}');

    const ticketConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

    const guildId = interaction.guildId;

    // حفظ الإعدادات

    ticketConfig[guildId] = {

      logChannel: interaction.options.getChannel('logchannel').id,

      title: interaction.options.getString('title'),

      messageTicket: interaction.options.getString('message_ticket'),

      messageInTicket: interaction.options.getString('message_in_ticket'),

      buttons: [

        interaction.options.getString('button1')

      ]

        .concat(interaction.options.getString('button2') || [])

        .concat(interaction.options.getString('button3') || [])

        .concat(interaction.options.getString('button4') || []),

      categoryId: interaction.options.getChannel('category').id,

      staffRole: interaction.options.getRole('staffrole').id,

      imageTicket: interaction.options.getString('image_ticket') || null,

      imageInTicket: interaction.options.getString('image_in_ticket') || null

    };

    fs.writeFileSync(configPath, JSON.stringify(ticketConfig, null, 2));

    // بناء الإيمبد

    const cfg = ticketConfig[guildId];

    const embed = new EmbedBuilder()

      .setTitle(cfg.title)

      .setDescription(cfg.messageTicket)

      .setColor(0x000000)

      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

    if (cfg.imageTicket) embed.setImage(cfg.imageTicket);

    // بناء Select Menu لفتح التكت

    const menu = new StringSelectMenuBuilder()

      .setCustomId(`ticket-panel@${guildId}`)

      .setPlaceholder('افتح تكت الآن');

    cfg.buttons.forEach((label, i) => {

      menu.addOptions({

        label: label,

        value: `${guildId}@${i}`,

        description: `فتح تكت: ${label}`

      });

    });

    const row = new ActionRowBuilder().addComponents(menu);

    await interaction.reply({ embeds: [embed], components: [row] });

  }

};

