# -*- coding: utf-8 -*-

import nextcord
from nextcord.ext import commands
from nextcord import Interaction, ButtonStyle
from nextcord.ui import Button, View, Select

import asyncio
import json
import os
import uuid
from aiohttp import web
import aiohttp_cors # <-- تم إضافة مكتبة جديدة


BOT_TOKEN = "MTI2NDIyNDYzODk1NTk1MDE4MQ.GeDfaD.BBpG3Cx3_pNov3siPzT5ArNb6NItH5AmMbT4qw"
CONFIG_FILE = "config.json"
# عنوان ومنفذ الخادم المحلي
HOST = "0.0.0.0" 
PORT = 3000  


intents = nextcord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


DEFAULT_CONFIG = {
    "main_embed": {
        "title": "قوانين السيرفر",
        "description": "يرجى اختيار أحد القوانين أدناه لعرض تفاصيله.",
        "bannerUrl": "",
        "logoUrl": "",
        "color": "#7c3aed",
        "menuType": "buttons"
    },
    "rules": []
}


def load_config():
    if not os.path.exists(CONFIG_FILE):
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        # في حالة وجود خطأ في الملف، يتم إنشاء ملف جديد
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG


def save_config(data):
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except IOError as e:
        print(f"خطأ فادح: لا يمكن الكتابة في ملف الإعدادات: {e}")


class RulesView(View):
    def __init__(self, config):
        super().__init__(timeout=None)
        rules = config.get('rules', [])
        menu_type = config.get('main_embed', {}).get('menuType', 'buttons')

        if menu_type == 'buttons':
            
            for rule in rules[:25]:
                button = Button(label=rule.get('title'), style=ButtonStyle.secondary, custom_id=f"rule_{rule.get('id')}")
                button.callback = self.show_rule_callback
                self.add_item(button)
        elif menu_type == 'select':
            
            options = [nextcord.SelectOption(label=rule.get('title'), value=f"rule_{rule.get('id')}") for rule in rules[:25]]
            if options:
                select_menu = Select(placeholder="اختر قانونًا لعرضه", options=options, custom_id="rules_select_menu")
                select_menu.callback = self.show_rule_callback
                self.add_item(select_menu)

    async def show_rule_callback(self, interaction: Interaction):
        rule_id = ""
        if interaction.data['component_type'] == 2: # Button
            rule_id = interaction.data['custom_id'].replace('rule_', '')
        elif interaction.data['component_type'] == 3: # Select
            rule_id = interaction.data['values'][0].replace('rule_', '')

        config = load_config()
        selected_rule = next((rule for rule in config['rules'] if rule.get('id') == rule_id), None)

        if selected_rule:
            rule_embed = nextcord.Embed(
                title=selected_rule.get('title'),
                description=selected_rule.get('content'),
                color=int(selected_rule.get('color', '#FFFFFF').replace('#', '0x'), 16)
            )
            await interaction.response.send_message(embed=rule_embed, ephemeral=True)
        else:
            await interaction.response.send_message("عذراً، لم أتمكن من العثور على هذا القانون.", ephemeral=True)

@bot.slash_command(name="rules", description="عرض قوانين السيرفر.")
async def rules_command(interaction: Interaction):
    await interaction.response.defer(ephemeral=False)
    config = load_config()
    main_config = config.get('main_embed')
    rules = config.get('rules')

    if not main_config or not rules:
        await interaction.followup.send("عذراً، لم يتم إعداد القوانين بعد. يرجى إعدادها من لوحة التحكم أولاً.", ephemeral=True)
        return

    embed = nextcord.Embed(
        title=main_config.get('title'),
        description=main_config.get('description'),
        color=int(main_config.get('color', '#7c3aed').replace('#', '0x'), 16)
    )
    if main_config.get('logoUrl'):
        embed.set_thumbnail(url=main_config.get('logoUrl'))
    if main_config.get('bannerUrl'):
        embed.set_image(url=main_config.get('bannerUrl'))

    view = RulesView(config)
    await interaction.followup.send(embed=embed, view=view)


app = web.Application()
routes = web.RouteTableDef()


@routes.get('/')
async def get_dashboard(request):
    return web.FileResponse('index.html')


@routes.get('/api/status')
async def get_status(request):
    return web.json_response({"status": "ok"})

@routes.get('/api/config')
async def get_config(request):
    config = load_config()
    return web.json_response(config.get('main_embed'))

@routes.get('/api/rules')
async def get_rules(request):
    config = load_config()
    return web.json_response(config.get('rules'))

@routes.post('/api/save-config')
async def save_main_config(request):
    data = await request.json()
    config = load_config()
    config['main_embed'] = data
    save_config(config)
    print("تم تحديث الإعدادات الرئيسية من لوحة التحكم.")
    return web.json_response({"status": "success"})

@routes.post('/api/save-rule')
async def save_rule(request):
    data = await request.json()
    config = load_config()
    rule_id = data.get('id')
    if rule_id: # تعديل قانون موجود
        print(f"يتم تحديث القانون: {data.get('title')}")
        for i, rule in enumerate(config['rules']):
            if rule['id'] == rule_id:
                config['rules'][i] = data
                break
    else: # إضافة قانون جديد
        data['id'] = str(uuid.uuid4()) # إنشاء معرف فريد
        print(f"يتم إضافة قانون جديد: {data.get('title')}")
        config['rules'].append(data)
    save_config(config)
    return web.json_response({"status": "success", "id": data['id']})

@routes.post('/api/delete-rule')
async def delete_rule(request):
    data = await request.json()
    rule_id = data.get('id')
    print(f"يتم حذف القانون ذو المعرف: {rule_id}")
    config = load_config()
    config['rules'] = [rule for rule in config['rules'] if rule.get('id') != rule_id]
    save_config(config)
    return web.json_response({"status": "success"})

app.add_routes(routes)


cors = aiohttp_cors.setup(app, defaults={
    "*": aiohttp_cors.ResourceOptions(
            allow_credentials=True,
            expose_headers="*",
            allow_headers="*",
            allow_methods="*", # السماح بجميع أنواع الطلبات (GET, POST, etc)
        )
})

for route in list(app.router.routes()):
    cors.add(route)



async def start_all():
    await runner.setup()
    site = web.TCPSite(runner, HOST, PORT)
    await site.start()
    print(f" Dashboard is running on http://{HOST}:{PORT} (Access it via http://127.0.0.1:{PORT})")
    await bot.start(BOT_TOKEN)

@bot.event
async def on_ready():
    print(f'Bot is ready and logged in as {bot.user}')
    print("="*30)
    print("The bot and dashboard are now running.")
    print("You can now use the /rules command in Discord.")
    print("="*30)

if __name__ == "__main__":
    if BOT_TOKEN == "YOUR_BOT_TOKEN":
        print("="*50)
        print("!!! تنبيه هام !!!")
        print("الرجاء تعديل ملف الكود وإضافة التوكن الخاص بالبوت.")
        print("وتثبيت المكتبة الجديدة عبر الأمر: pip install aiohttp_cors")
        print("="*50)
    else:
        runner = web.AppRunner(app)
        loop = asyncio.get_event_loop()
        try:
            loop.run_until_complete(start_all())
        except KeyboardInterrupt:
            
            loop.run_until_complete(runner.cleanup())
            loop.run_until_complete(bot.close())
