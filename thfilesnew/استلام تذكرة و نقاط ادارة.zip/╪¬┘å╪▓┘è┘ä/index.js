const fs = require('fs');
const {
  Client, GatewayIntentBits, Partials,
  SlashCommandBuilder, REST, Routes,
  EmbedBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle
} = require('discord.js');

// 🔧 عدّل القيم التالية:
const BOT_TOKEN = 'توكن بوت ';
const CLIENT_ID = 'ايدي بوت';
const GUILD_ID = 'ايدي سيرفر';
const ROLE_ADMIN_ID = 'ايدي رتبه اداري';
const ROLE_RECEIVER_ID = '1389538501896175627';
const LOG_CHANNEL_ID = 'ايدي لوق';
const ROLE_PROMOTE_ID = 'ايدي ';
const TICKET_CATEGORIES = ['كتاجوري', 'كتجاوري ارسال تذكرة استلام'];

// ✅ تأكد وجود الملفات الأساسية
if (!fs.existsSync('log.txt')) fs.writeFileSync('log.txt', '');
if (!fs.existsSync('points.txt')) fs.writeFileSync('points.txt');

// 🛠️ دوال عمل النقاط واللوق
function appendLog(line) {
  fs.appendFileSync('log.txt', line + '\n');
}
function adjustPoints(userId, delta) {
  const data = {};
  fs.readFileSync('points.txt', 'utf8').split('\n').filter(Boolean).forEach(l => {
    const [id, pts] = l.split(':');
    data[id] = +pts;
  });
  data[userId] = (data[userId] || 0) + delta;
  fs.writeFileSync('points.txt', Object.entries(data).map(([i,p])=>`${i}:${p}`).join('\n'));
}
function readPoints(uid) {
  const data = {};
  fs.readFileSync('points.txt','utf8').split('\n').filter(Boolean).forEach(l => {
    const [id,p] = l.split(':');
    data[id] = +p;
  });
  return data[uid] || 0;
}
function setPoints(uid, val) {
  const data = {};
  fs.readFileSync('points.txt','utf8').split('\n').filter(Boolean).forEach(l => {
    const [id,p] = l.split(':');
    data[id] = +p;
  });
  data[uid] = val;
  fs.writeFileSync('points.txt', Object.entries(data).map(([i,p])=>`${i}:${p}`).join('\n'));
}
function topPoints(limit=10) {
  return fs.readFileSync('points.txt','utf8').split('\n').filter(Boolean)
    .map(l => {
      const [id, p] = l.split(':');
      return { id, p: +p };
    })
    .sort((a,b)=>b.p-a.p).slice(0, limit);
}
function readLogForUser(uid) {
  return fs.readFileSync('log.txt','utf8').split('\n')
    .filter(l => l.includes(uid)).map(l => `• ${l}`).join('\n');
}

// 🗃️ تخزين المستلم الحقيقي لكل تذكرة
const ticketHandlers = {};

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

// 📦 تسجيل أوامر السلاش
const commands = [
  new SlashCommandBuilder().setName('نقاطي').setDescription('عرض توب النقاط'),
  new SlashCommandBuilder()
    .setName('نقاط').setDescription('عرض نقاط شخص')
    .addUserOption(o => o.setName('user').setDescription('شخص').setRequired(true)),
  new SlashCommandBuilder().setName('توب').setDescription('عرض توب النقاط'),
  new SlashCommandBuilder()
    .setName('ملاحظة').setDescription('سجل ملاحظة')
    .addUserOption(o => o.setName('user').setDescription('شخص').setRequired(true))
    .addStringOption(o => o.setName('note').setDescription('الملاحظة').setRequired(true)),
  new SlashCommandBuilder()
    .setName('إعادة-تعيين').setDescription('إعادة نقاط')
    .addUserOption(o => o.setName('user').setDescription('شخص').setRequired(true)),
  new SlashCommandBuilder()
    .setName('إضافة-نقطة').setDescription('إضافة نقاط')
    .addUserOption(o => o.setName('user').setDescription('شخص').setRequired(true))
    .addIntegerOption(o => o.setName('عدد').setDescription('عدد النقاط').setRequired(true)),
  new SlashCommandBuilder()
    .setName('أرشفة').setDescription('عرض أرشيف شخص')
    .addUserOption(o => o.setName('user').setDescription('شخص').setRequired(true)),
  new SlashCommandBuilder()
    .setName('ترقية').setDescription('ترقية حسب نقاط')
    .addUserOption(o => o.setName('user').setDescription('شخص').setRequired(true))
];

client.once('ready', async () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  const rest = new REST({ version: '10' }).setToken(BOT_TOKEN);
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
});

client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand()) {
    if (!interaction.member.roles.cache.has(ROLE_ADMIN_ID))
      return interaction.reply({ content: '🚫 فقط للإدارة', ephemeral: true });

    const cmd = interaction.commandName;
    const target = interaction.options.getUser('user');

    if (cmd === 'نقاطي' || cmd === 'توب') {
      const arr = topPoints();
      const embed = new EmbedBuilder()
        .setTitle('🏆 توب النقاط')
        .setDescription(arr.map((u,i)=>`${i+1}. <@${u.id}> – **${u.p}**`).join('\n') || '– لا أحد');
      return interaction.reply({ embeds: [embed] });
    }

    if (cmd === 'نقاط') {
      const pts = readPoints(target.id);
      return interaction.reply(`${target} عنده **${pts}** نقطة.`);
    }

    if (cmd === 'ملاحظة') {
      const note = interaction.options.getString('note');
      appendLog(`[${new Date().toISOString()}] ملاحظة لـ${target.id}: ${note}`);
      return interaction.reply(`✅ تم تسجيل ملاحظة.`);
    }

    if (cmd === 'إعادة-تعيين') {
      setPoints(target.id, 0);
      return interaction.reply(`✅ تم إعادة نقاط ${target}`);
    }

    if (cmd === 'إضافة-نقطة') {
      const num = interaction.options.getInteger('عدد');
      adjustPoints(target.id, num);
      return interaction.reply(`✅ أضيفت ${num} نقطة لـ ${target}`);
    }

    if (cmd === 'أرشفة') {
      const pts = readPoints(target.id);
      const notes = readLogForUser(target.id) || '– لا يوجد';
      return interaction.reply(`📄 أرشيف ${target}:\n• نقاط: ${pts}\n• ملاحظات:\n${notes}`);
    }

    if (cmd === 'ترقية') {
      const pts = readPoints(target.id), need = 50;
      if (pts >= need) {
        const member = await interaction.guild.members.fetch(target.id);
        member.roles.add(ROLE_PROMOTE_ID);
        return interaction.reply(`🎉 تم ترقية ${target}`);
      }
      return interaction.reply(`⚠️ ${target} يحتاج **${need-pts}** نقطة.`);
    }
  }

  if (interaction.isButton()) {
    const { customId, message, user, member } = interaction;
    const tid = message.id;

    if (!member.roles.cache.has(ROLE_ADMIN_ID))
      return interaction.reply({ content: '🚫 فقط للإدارة', ephemeral: true });

    if (customId === 'receive_ticket') {
      if (!member.roles.cache.has(ROLE_RECEIVER_ID))
        return interaction.reply({ content: '🚫 ما عندك صلاحية', ephemeral: true });

      adjustPoints(user.id, 1);
      appendLog(`[${new Date().toISOString()}] استلم ${user.id} تذكرة ${tid}`);
      ticketHandlers[tid] = user.id;

      const embed = new EmbedBuilder()
        .setColor('Green')
        .setDescription(`✅ <@${user.id}> تم الاستلام\nكيف أقدر أخدمك؟ 📍`);
      const leaveBtn = new ButtonBuilder()
        .setCustomId('leave_ticket').setLabel('ترك الاستلام').setStyle(ButtonStyle.Danger);

      return interaction.update({ embeds: [embed], components: [new ActionRowBuilder().addComponents(leaveBtn)] });
    }

    if (customId === 'leave_ticket') {
      if (ticketHandlers[tid] !== user.id)
        return interaction.reply({ content: '🚫 فقط المستلم يقدر يتركه', ephemeral: true });

      adjustPoints(user.id, -1);
      appendLog(`[${new Date().toISOString()}] ترك ${user.id} تذكرة ${tid}`);
      delete ticketHandlers[tid];

      const receiveBtn = new ButtonBuilder()
        .setCustomId('receive_ticket').setLabel('استلام 💼').setStyle(ButtonStyle.Primary);

      return interaction.update({ embeds: [], components: [new ActionRowBuilder().addComponents(receiveBtn)] });
    }
  }
});

client.on('channelCreate', channel => {
  if (!channel.isTextBased() || !TICKET_CATEGORIES.includes(channel.parentId)) return;
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('receive_ticket').setLabel('استلام 💼').setStyle(ButtonStyle.Primary)
  );
  channel.send({ content: 'اضغط الاستلام 👇', components: [row] }).catch(console.error);
});

client.on('channelDelete', async channel => {
  if (!TICKET_CATEGORIES.includes(channel.parentId)) return;
  const perms = channel.permissionOverwrites.cache;
  const members = perms.filter(o=>o.type==='member').map(o=>o.id).join(', ') || '–';
  const watchers = perms.filter(o=>o.type!=='member').map(o=>o.id).join(', ') || '–';

  appendLog(`[${new Date().toISOString()}] حذف روم ${channel.name} (ID: ${channel.id}). أعضاء: ${members}. مراقبين: ${watchers}`);
  const logCh = await client.channels.fetch(LOG_CHANNEL_ID);
  logCh.send({ content: `🚨 تم حذف روم #${channel.name}\n◾ أعضاء: ${members}\n◾ مراقبين: ${watchers}` });
});

client.login(BOT_TOKEN).catch(console.error);