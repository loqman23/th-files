const { SlashCommandBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('twitter')
    .setDescription('فتح نموذج إرسال رسالة لروم تويتر'),

  match(interaction) {
    return interaction.commandName === 'twitter' || interaction.customId?.startsWith('send_twitter');
  },

  async execute(interaction, config) {
    if (interaction.commandName === 'twitter') {
      const button = new ButtonBuilder()
        .setCustomId('send_twitter_button')
        .setLabel('ارسال رسالة تويتر')
        .setStyle(ButtonStyle.Primary);

      const row = new ActionRowBuilder().addComponents(button);
      await interaction.reply({ content: 'اضغط الزر لإرسال رسالة:', components: [row] });
    } else if (interaction.customId === 'send_twitter_button') {
      const modal = new ModalBuilder()
        .setCustomId('send_twitter_modal')
        .setTitle('رسالة تويتر');

      const input = new TextInputBuilder()
        .setCustomId('twitter_message')
        .setLabel('اكتب رسالتك')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true);

      const row = new ActionRowBuilder().addComponents(input);
      modal.addComponents(row);

      await interaction.showModal(modal);
    } else if (interaction.customId === 'send_twitter_modal') {
      const message = interaction.fields.getTextInputValue('twitter_message');
      const channel = await interaction.client.channels.fetch(config.twitterChannelId);

      if (channel && channel.type === ChannelType.GuildText) {
        await channel.send(`📢 رسالة جديدة من <@${interaction.user.id}>:\n${message}`);
        await interaction.reply({ content: '✅ تم إرسال الرسالة بنجاح!', ephemeral: true });
      } else {
        await interaction.reply({ content: '❌ لم يتم العثور على روم تويتر.', ephemeral: true });
      }
    }
  }
};