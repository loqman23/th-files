## Prerequisites

Before you begin, make sure you have the following installed:

- [Node.js](https://nodejs.org/) (v16.x or higher)
- npm (comes with Node.js)

## Setup Guide

Follow these steps to set up and run your Discord bot with dashboard:

### 1. Create a Discord Application

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Click on "New Application" and give it a name
3. Navigate to the "Bot" tab and click "Add Bot"
4. Under the "TOKEN" section, click "Copy" to copy your bot token
5. Save this token for later use

### 2. Configure OAuth2

1. In the Discord Developer Portal, go to the "OAuth2" tab
2. Add a redirect URL: `http://localhost:3000/auth/discord/callback`
3. Copy the "CLIENT ID" and "CLIENT SECRET" for later use

### 3. Clone and Install Dependencies

1. Clone this repository to your local machine:
   ```
   git clone <repository-url>
   cd discord-bot-dashboard
   ```

2. Install the dependencies:
   ```
   npm install
   ```

### 4. Configure Environment Variables

1. Edit the `.env` file in the root directory:
   ```
   BOT_TOKEN=your_discord_bot_token
   CLIENT_ID=your_discord_client_id
   CLIENT_SECRET=your_discord_client_secret
   REDIRECT_URI=http://localhost:3000/auth/discord/callback
   PORT=3000
   ```

### 5. Invite the Bot to Your Server

1. Go back to the Discord Developer Portal, navigate to the "OAuth2" tab
2. In the "SCOPES" section, select "bot" and "applications.commands"
3. In the "BOT PERMISSIONS" section, select the permissions you want your bot to have
4. Copy the generated URL and paste it into your browser
5. Select a server to invite the bot to and authorize it

### 6. Run the Application

1. Start the application:
   ```
   npm start
   ```
   
   For development with auto-reload:
   ```
   npm run dev
   ```

2. Open your browser and navigate to `http://localhost:3000`

## Bot Commands

Currently, the bot supports the following slash commands:

- `/ping`: Checks the bot's response time and API latency

## Project Structure

```
discord-bot-dashboard/
├── app.js                 # Main application file with all routes
├── src/
│   └── bot.js             # Discord bot implementation
├── public/
│   └── css/
│       └── style.css      # CSS styles for the dashboard
├── views/
│   ├── index.ejs          # Homepage template
│   ├── login.ejs          # Login page template
│   └── dashboard.ejs      # Dashboard template
├── package.json           # Project dependencies
└── .env                   # Environment variables
```

## Adding More Commands

To add more slash commands to your bot:

1. Open `src/bot.js`
2. Add a new command to the `commands` array:
   ```javascript
   const commands = [
     // Existing commands
     new SlashCommandBuilder()
       .setName('command-name')
       .setDescription('Command description')
       .toJSON()
   ];
   ```

3. Add a handler for the command:
   ```javascript
   client.on(Events.InteractionCreate, async interaction => {
     if (!interaction.isChatInputCommand()) return;

     if (interaction.commandName === 'command-name') {
       // Command logic here
       await interaction.reply('Command response');
     }
   });
   ```

## Customizing the Dashboard

### Changing Colors

Edit the CSS variables in `public/css/style.css`:

```css
:root {
  --primary-color: #5865F2;  /* Change to your preferred color */
  --secondary-color: #3BA55C; /* Change to your preferred color */
  /* Other color variables */
}
```

### Adding Pages

1. Create a new EJS template in the `views` directory
2. Add a new route in `app.js`:
   ```javascript
   app.get('/your-page', isAuthenticated, (req, res) => {
     res.render('your-page', { user: req.user });
   });
   ```

3. Add a link to the new page in the sidebar navigation in `views/dashboard.ejs`

## Security Considerations

- Never share your `.env` file or expose your bot token
- Use HTTPS in production
- Implement rate limiting for API routes
- Regularly update dependencies to patch security vulnerabilities

## Contributing

Contributions are welcome! Feel free to submit a pull request or open an issue if you have any suggestions or find any bugs.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [Discord.js](https://discord.js.org/) - For the Discord API wrapper
- [Express](https://expressjs.com/) - For the web server
- [Passport](http://www.passportjs.org/) - For authentication
- [EJS](https://ejs.co/) - For templating

---

Good luck with your Discord bot! If you have any questions, feel free to reach out. 