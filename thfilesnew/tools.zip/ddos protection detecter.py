#!/usr/bin/env python3

import itertools
import sys

def generate_version_combinations(partial_version, missing_positions, range_start=0, range_end=255):
    """
    Generate all possible combinations for a partial version number with missing components.
    
    Args:
        partial_version: List of known version components (None for missing positions)
        missing_positions: List of positions that are missing (0-indexed)
        range_start: Minimum value for missing components (default: 0)
        range_end: Maximum value for missing components (default: 255)
        
    Returns:
        List of all possible complete version strings
    """
    # Generate all possible values for the missing positions
    possible_values = list(itertools.product(range(range_start, range_end + 1), repeat=len(missing_positions)))
    
    results = []
    
    # Apply each combination to the partial version
    for values in possible_values:
        complete_version = partial_version.copy()
        for i, pos in enumerate(missing_positions):
            complete_version[pos] = values[i]
        
        # Convert to string format
        version_str = '.'.join(map(str, complete_version))
        results.append(version_str)
    
    return results

def save_to_file(versions, filename="possible_versions.txt"):
    """Save the generated versions to a file"""
    with open(filename, 'w') as f:
        for version in versions:
            f.write(f"{version}\n")
    print(f"Saved {len(versions)} combinations to {filename}")

def main():
    # Known partial version: 2.57.19.1
    # If you're missing the 3rd and 4th positions (assuming 0-indexed positions)
    # Adapt these values based on which parts are actually missing
    
    # For "2.57.?.?.1" where ? are missing positions
    partial_version = [2, 57, None, None, 1]  # None represents missing positions
    missing_positions = [2, 3]  # 0-indexed positions that are missing
    
    # Limit the range if you have any knowledge about the possible values
    min_value = 0
    max_value = 255  # Standard range for version numbers
    
    print(f"Generating all possible combinations for version with missing values...")
    print(f"Pattern: {'.'.join(['?' if x is None else str(x) for x in partial_version])}")
    print(f"Range for missing values: {min_value}-{max_value}")
    
    # Get the possible combinations
    combinations = generate_version_combinations(partial_version, missing_positions, min_value, max_value)
    
    # Display a few examples
    print(f"\nGenerated {len(combinations)} possible combinations.")
    print("\nExample combinations:")
    for i in range(min(5, len(combinations))):
        print(combinations[i])
    
    # Ask if user wants to save all combinations to file
    save_to_file(combinations)

if __name__ == "__main__":
    main()