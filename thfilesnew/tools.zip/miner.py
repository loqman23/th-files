#!/usr/bin/env python3
import hashlib
import time
import logging
import json
import random
import matplotlib.pyplot as plt
from datetime import datetime
import argparse
import signal
import sys
import requests
import threading
import socket
import struct
import binascii
from typing import List, Dict, Callable, Optional, Any, Union

logging.basicConfig(
    filename=f"zorg_miner_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

class StratumClient:
    def __init__(self, url: str, username: str, password: str, on_result: Callable[[Dict], None]):
        self.url = url
        self.username = username
        self.password = password
        self.on_result = on_result
        self.socket = None
        self.id = 1
        self.running = True
        self.current_job = None
        self.difficulty = 1
        if "://" in url:
            self.host = url.split("://")[1].split(":")[0]
            self.port = int(url.split("://")[1].split(":")[1])
        else:
            parts = url.split(":")
            self.host = parts[0]
            self.port = int(parts[1]) if len(parts) > 1 else 3333
        self.response_thread = None

    def connect(self) -> bool:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((self.host, self.port))
            logging.info(f"Connected to {self.host}:{self.port}")
            
            self.response_thread = threading.Thread(target=self._listen_for_responses)
            self.response_thread.daemon = True
            self.response_thread.start()
            
            self._send_subscribe()
            time.sleep(0.1)
            
            self._send_authorize()
            time.sleep(0.1)
            
            return True
        except Exception as e:
            logging.error(f"Connection error: {str(e)}")
            return False

    def disconnect(self) -> None:
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        if self.response_thread and self.response_thread.is_alive():
            self.response_thread.join(1)

    def _send_message(self, method: str, params: List) -> int:
        message = {
            "id": self.id,
            "method": method,
            "params": params
        }
        message_str = json.dumps(message) + "\n"
        try:
            self.socket.sendall(message_str.encode())
            current_id = self.id
            self.id += 1
            return current_id
        except Exception as e:
            logging.error(f"Send error: {str(e)}")
            return -1

    def _send_subscribe(self) -> int:
        return self._send_message("mining.subscribe", ["zorg-miner/1.0.0", None, self.host, self.port])

    def _send_authorize(self) -> int:
        return self._send_message("mining.authorize", [self.username, self.password])

    def submit_job(self, job_id: str, nonce: int, extra_nonce2: str = "", time: str = "", version: str = "") -> bool:
        params = [self.username, job_id, extra_nonce2, time, version, f"{nonce:08x}"]
        params = [p for p in params if p]
        
        logging.debug(f"Submitting solution: {params}")
        return self._send_message("mining.submit", params) > 0

    def _listen_for_responses(self) -> None:
        if not self.socket:
            return
            
        buffer = b''
        while self.running:
            try:
                data = self.socket.recv(4096)
                if not data:
                    logging.warning("Connection closed by the server")
                    break
                    
                buffer += data
                while b'\n' in buffer:
                    line, buffer = buffer.split(b'\n', 1)
                    self._handle_response(line.decode('utf-8'))
                    
            except Exception as e:
                logging.error(f"Read error: {str(e)}")
                break
                
        logging.info("Response listener stopped")

    def _handle_response(self, response_str: str) -> None:
        try:
            response = json.loads(response_str)
            logging.debug(f"← {response}")
            
            if "method" in response and response["method"] == "mining.notify":
                job_params = response["params"]
                self.current_job = {
                    "id": job_params[0],
                    "prev_hash": job_params[1],
                    "coinbase1": job_params[2],
                    "coinbase2": job_params[3],
                    "merkle_branches": job_params[4],
                    "version": job_params[5],
                    "bits": job_params[6],
                    "time": job_params[7],
                    "clean_jobs": job_params[8],
                    "target": self._bits_to_target(job_params[6])
                }
                logging.info(f"New job received: {self.current_job['id']}")
                
            elif "method" in response and response["method"] == "mining.set_difficulty":
                self.difficulty = float(response["params"][0])
                logging.info(f"New difficulty: {self.difficulty}")
                
            elif "result" in response:
                result = {
                    "id": response.get("id"),
                    "accepted": response["result"] is True,
                    "error": response.get("error")
                }
                if self.on_result:
                    self.on_result(result)
                    
        except Exception as e:
            logging.error(f"Error handling response: {str(e)} - Response: {response_str}")

    def get_job(self) -> Optional[Dict]:
        return self.current_job

    def check_target(self, hash_result: str, target: str) -> bool:
        hash_int = int(hash_result, 16)
        
        target_int = int(target, 16) if target else 0
        
        if target_int == 0 and self.difficulty > 0:
            target_int = int(0xffff * 2**(256-32) / self.difficulty)
            
        return hash_int < target_int

    def _bits_to_target(self, bits_hex: str) -> str:
        try:
            bits = int(bits_hex, 16)
            
            exponent = bits >> 24
            coefficient = bits & 0xffffff
            
            if exponent <= 3:
                target = coefficient >> (8 * (3 - exponent))
            else:
                target = coefficient << (8 * (exponent - 3))
                
            target_hex = f"{target:064x}"
            return target_hex
            
        except Exception as e:
            logging.error(f"Error converting bits to target: {str(e)}")
            return "0" * 64


class ZorgCryptoAnnihilator:
    def __init__(self, pool_url: str, username: str, password: str, algo: str = "sha256", wallet: str = "", stealth_mode: bool = False):
        self.pool_url = pool_url
        self.username = username
        self.password = password
        self.algo = algo.lower()
        self.wallet = wallet
        self.stealth_mode = stealth_mode
        self.running = True
        self.lock = threading.Lock()
        self.stats = {"hashrate": 0, "accepted": 0, "rejected": 0}
        self.client = None
        self.plot_thread = None
        self.mining_thread = None
        self.hashrate_counter = 0
        self.last_hashrate_update = time.time()
        signal.signal(signal.SIGINT, self.signal_handler)

    def signal_handler(self, sig, frame):
        print("\n[!] ZORG👽 TERMINATING MINING CHAOS...")
        self.running = False
        if self.client:
            self.client.disconnect()
        if self.plot_thread:
            plt.close('all')
        sys.exit(0)

    def hash_data(self, data: str) -> str:
        if self.algo == "sha256":
            return hashlib.sha256(hashlib.sha256(data.encode()).digest()).hexdigest()
        elif self.algo == "scrypt":
            try:
                import scrypt
                return scrypt.hash(data.encode(), b"", N=1024, r=1, p=1).hex()
            except ImportError:
                print("[!] scrypt module not installed. Falling back to SHA-256.")
                return hashlib.sha256(hashlib.sha256(data.encode()).digest()).hexdigest()
        elif self.algo == "ethash":
            try:
                from eth_hash.auto import keccak
                return keccak(data.encode()).hex()
            except ImportError:
                print("[!] eth_hash module not installed. Falling back to SHA-256.")
                return hashlib.sha256(hashlib.sha256(data.encode()).digest()).hexdigest()
        else:
            print(f"[!] Unsupported algorithm: {self.algo}. Falling back to SHA-256.")
            return hashlib.sha256(hashlib.sha256(data.encode()).digest()).hexdigest()

    def update_hashrate(self):
        current_time = time.time()
        elapsed = current_time - self.last_hashrate_update
        if elapsed >= 1.0:
            with self.lock:
                self.stats["hashrate"] = int(self.hashrate_counter / elapsed)
                self.hashrate_counter = 0
                self.last_hashrate_update = current_time

    def mine(self):
        if self.mining_thread and self.mining_thread.is_alive():
            print("[!] Mining already in progress")
            return
        
        self.mining_thread = threading.Thread(target=self._mine_worker)
        self.mining_thread.daemon = True
        self.mining_thread.start()
        print("[*] Mining started in the background")

    def _mine_worker(self):
        print(f"[*] ZORG👽 CONNECTING TO POOL {self.pool_url}...")
        logging.debug(f"Connecting to {self.pool_url} with user {self.username}")
        
        def on_mining_result(result: Dict):
            with self.lock:
                if result.get("accepted"):
                    self.stats["accepted"] += 1
                    print(f"[+] Share accepted! Total: {self.stats['accepted']}")
                    logging.info("Share accepted")
                else:
                    self.stats["rejected"] += 1
                    print(f"[!] Share rejected. Total: {self.stats['rejected']}")
                    error = result.get("error")
                    if error:
                        print(f"[!] Error: {error}")
                    logging.error(f"Share rejected: {error}")

        try:
            self.client = StratumClient(
                url=self.pool_url,
                username=self.username,
                password=self.password,
                on_result=on_mining_result
            )
            
            if not self.client.connect():
                print("[!] Failed to connect to mining pool")
                return
                
            print(f"[+] Connected to pool. Waiting for jobs...")
            
            while self.running:
                job = self.client.get_job()
                if not job:
                    time.sleep(0.5)
                    continue
                
                merkle_root = self._calculate_merkle_root(
                    job.get("coinbase1", ""),
                    job.get("coinbase2", ""),
                    job.get("merkle_branches", [])
                )
                
                version = job.get("version", "00000002")
                prev_hash = job.get("prev_hash", "0" * 64)
                time_stamp = job.get("time", "")
                bits = job.get("bits", "")
                
                nonce = random.randint(0, 0xFFFFFFFF) if self.stealth_mode else 0
                max_nonce = 0xFFFFFFFF
                
                start_time = time.time()
                hashes = 0
                
                while self.running and nonce <= max_nonce:
                    nonce_hex = f"{nonce:08x}"
                    
                    header = f"{version}{prev_hash}{merkle_root}{time_stamp}{bits}{nonce_hex}"
                    
                    hash_result = self.hash_data(header)
                    hashes += 1
                    self.hashrate_counter += 1
                    
                    if hashes % 1000 == 0:
                        self.update_hashrate()
                    
                    if self.client.check_target(hash_result, job.get("target", "")):
                        print(f"[+] Solution found! Nonce: {nonce_hex}, Hash: {hash_result}")
                        self.client.submit_job(job["id"], nonce)
                        break
                    
                    nonce += 1
                    
                    if time.time() - start_time > 60:
                        break
                    
                    if self.stealth_mode:
                        time.sleep(random.uniform(0.001, 0.01))
                
        except Exception as e:
            print(f"[!] Mining error: {str(e)}")
            logging.error(f"Mining error: {str(e)}")
            
        finally:
            if self.client:
                self.client.disconnect()

    def _calculate_merkle_root(self, coinbase1: str, coinbase2: str, merkle_branches: List[str]) -> str:
        try:
            coinbase = coinbase1 + coinbase2
            coinbase_hash = hashlib.sha256(hashlib.sha256(binascii.unhexlify(coinbase)).digest()).digest()
            
            current_hash = coinbase_hash
            for branch in merkle_branches:
                combined = current_hash + binascii.unhexlify(branch)
                current_hash = hashlib.sha256(hashlib.sha256(combined).digest()).digest()
                
            return binascii.hexlify(current_hash).decode('utf-8')
            
        except Exception as e:
            logging.error(f"Error calculating merkle root: {str(e)}")
            return "0" * 64

    def plot_stats(self):
        def update_plot():
            plt.ion()
            fig, ax = plt.subplots(figsize=(10, 6))
            
            x_data = []
            hashrate_data = []
            accepted_data = []
            rejected_data = []
            
            start_time = time.time()
            
            while self.running:
                try:
                    current_time = time.time() - start_time
                    x_data.append(current_time)
                    
                    with self.lock:
                        hashrate = self.stats["hashrate"]
                        accepted = self.stats["accepted"]
                        rejected = self.stats["rejected"]
                    
                    hashrate_data.append(hashrate)
                    accepted_data.append(accepted)
                    rejected_data.append(rejected)
                    
                    if len(x_data) > 100:
                        x_data = x_data[-100:]
                        hashrate_data = hashrate_data[-100:]
                        accepted_data = accepted_data[-100:]
                        rejected_data = rejected_data[-100:]
                    
                    ax.clear()
                    
                    ax.plot(x_data, hashrate_data, 'r-', label=f'Hashrate: {hashrate} H/s')
                    
                    ax.bar([0], [accepted], color='green', alpha=0.5, label=f'Accepted: {accepted}')
                    ax.bar([1], [rejected], color='black', alpha=0.5, label=f'Rejected: {rejected}')
                    
                    ax.set_title("ZORG👽 Mining Stats")
                    ax.set_xlabel("Time (seconds)")
                    ax.set_ylabel("Hashrate (H/s)")
                    ax.legend(loc='upper left')
                    
                    plt.pause(1)
                except Exception as e:
                    logging.error(f"Plot error: {str(e)}")
                    time.sleep(1)
                    
            plt.close()

        self.plot_thread = threading.Thread(target=update_plot)
        self.plot_thread.daemon = True
        self.plot_thread.start()

    def check_wallet(self):
        if not self.wallet:
            print("[!] No wallet address provided")
            return
            
        try:
            if self.algo == "sha256":
                response = requests.get(f"https://blockchain.info/balance?active={self.wallet}")
                data = response.json()
                if self.wallet in data:
                    balance = data[self.wallet]["final_balance"] / 1e8
                    print(f"[*] Wallet balance: {balance} BTC")
                    logging.info(f"Wallet balance: {balance} BTC")
                else:
                    print(f"[!] Could not retrieve wallet balance")
            else:
                print(f"[!] Wallet balance check not implemented for {self.algo}")
                
        except Exception as e:
            print(f"[!] Wallet check failed: {str(e)}")
            logging.error(f"Wallet check failed: {str(e)}")

    def menu(self):
        self.plot_stats()
        while self.running:
            print("\n=== ZORG👽 CRYPTO ANNIHILATOR ===")
            print(f"1. Start mining ({self.algo})")
            print("2. Check wallet balance")
            print("3. View stats")
            print("4. Toggle Stealth Mode (Current: {})".format("ON" if self.stealth_mode else "OFF"))
            print("5. Exit")
            
            choice = input("Choose your chaos [1-5]: ").strip()
            
            if choice == "1":
                self.mine()
            elif choice == "2":
                self.check_wallet()
            elif choice == "3":
                with self.lock:
                    print(f"\nCurrent Stats:")
                    print(f"- Hashrate: {self.stats['hashrate']} H/s")
                    print(f"- Accepted Shares: {self.stats['accepted']}")
                    print(f"- Rejected Shares: {self.stats['rejected']}")
            elif choice == "4":
                self.stealth_mode = not self.stealth_mode
                print(f"[*] Stealth Mode {'ON' if self.stealth_mode else 'OFF'}")
                logging.info(f"Stealth Mode: {self.stealth_mode}")
            elif choice == "5":
                print("[*] ZORG👽 RETREATS... FOR NOW.")
                logging.info("Exiting")
                self.running = False
            else:
                print("[!] Invalid choice.")

def main():
    parser = argparse.ArgumentParser(description="ZORG👽 Crypto Annihilator")
    parser.add_argument("--pool", required=True, help="Stratum pool URL (e.g., stratum+tcp://pool.example.com:3333)")
    parser.add_argument("--user", required=True, help="Pool username/worker")
    parser.add_argument("--pass", dest="password", default="x", help="Pool password")
    parser.add_argument("--algo", default="sha256", choices=["sha256", "scrypt", "ethash"], help="Mining algorithm")
    parser.add_argument("--wallet", default="", help="Wallet address for rewards")
    parser.add_argument("--stealth", action="store_true", help="Enable stealth mode")
    args = parser.parse_args()

    print("""
    ╔════════════════════════════════════╗
    ║    ZORG👽 CRYPTO ANNIHILATOR      ║
    ║    MINE. DOMINATE. PROFIT.        ║
    ╚════════════════════════════════════╝
    """)
    
    annihilator = ZorgCryptoAnnihilator(
        pool_url=args.pool,
        username=args.user,
        password=args.password,
        algo=args.algo,
        wallet=args.wallet,
        stealth_mode=args.stealth
    )
    annihilator.menu()

if __name__ == "__main__":
    main()