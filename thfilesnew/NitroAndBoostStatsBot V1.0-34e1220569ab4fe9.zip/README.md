# Discord Stats Bot (Posts & Nitro) — صورة إحصائيات

هذا مشروع جاهز لبوت ديسكورد بسيط يسجّل عدد البوستات وعدد الـNitro لكل مستخدم، ويُرجع صورة فيها الإحصاءات.

**مميزات**
- أوامر سلاش:
  - `/post` — يزيد عداد "البوست" للمستخدم.
  - `/nitro` — يزيد عداد "النيترو" للمستخدم.
  - `/stats` — يعرض صورة تحتوي على اسم المستخدم وعددي البوست والنيترو.
- يخزن البيانات محليًا في `data.json`.
- يولّد صورة باستخدام مكتبة `canvas`.

**تنصيب**
```bash
git clone <this-zip-or-folder>
cd discord-stats-bot
npm install
```
نسخ ملف المثال `.env.example` إلى `.env` واملأ المتغيرات ثم شغّل:
```bash
cp .env.example .env
# عدل .env ثم:
npm start
```

**المتطلبات**
- Node.js 18+ (موصى به)
- قد تحتاج إلى تثبيت مكتبة cairo / build tools لأن `canvas` قد تحتاج بناتيف. على أوبونتو:
```bash
sudo apt-get install build-essential libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev
```
على Windows استخدم تعليمات تثبيت `canvas` الرسمية.

**تكوين (.env)**
- DISCORD_TOKEN: توكن بوت الديسكورد (لا تشاركه)
- CLIENT_ID: Client/Application ID من بوابة Discord Developer
- GUILD_ID: (اختياري أثناء التجربة) ID للسيرفر لتسجيل أوامر السلاش مباشرة

**ملاحظات قانونية**
هذا المشروع مخصص لأغراض شرعية فقط. لا يستخدم لتوليد أو توزيع رموز Nitro مزيفة أو أي نشاط ينتهك شروط Discord.

