// index.js
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const config = require('./config.js');
const { loadSrcFiles } = require("./utils/loader.js");
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildScheduledEvents,
        GatewayIntentBits.AutoModerationConfiguration,
        GatewayIntentBits.AutoModerationExecution,
    ],
    partials: [
        Partials.User,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Message,
        Partials.Reaction,
        Partials.ThreadMember,
        Partials.GuildScheduledEvent,
    ],
    presence: {
        status: 'online',
        activities: [{ name: 'Islamic', type: 4 }]
    }
});
process.on('unhandledRejection', (reason, promise) => {console.error('Unhandled Rejection:', reason);});process.on('uncaughtException', (err) => {console.error('Uncaught Exception:', err);});
client.once("clientReady", () => {
    console.log(`Logged ${client.user.tag}`);
    try {
        loadSrcFiles(client);
    } catch (err) {
        console.error('Error loading source files:', err);}});
client.login(config.token).catch(err => {console.error('Login failed:', err);});
