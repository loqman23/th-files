const { createCanvas, registerFont, loadImage } = require('canvas');
const { AttachmentBuilder } = require('discord.js');
const path = require('path');

try {
  registerFont(path.join(__dirname, './Amiri-Regular.ttf'), { family: 'Amiri' });
  registerFont(path.join(__dirname, './Amiri-Bold.ttf'), { family: 'Amiri Bold' });
} catch (error) {
  console.error('[Font Registration Error]', error.message);
  console.warn('Falling back to "Arial" font.');
}

async function createQuranDesignImage(text, footerText = '', options = {}) {
  const width = options.width || 800;
  const maxTextWidth = options.maxTextWidth || 650;
  const lineHeight = options.lineHeight || 50;
  const gradientColors = options.gradientColors || ['#414141', '#12c79a']; 
  const maxHeight = options.maxHeight || 4000;
  const fontSize = options.fontSize || 36;

  const surahMatch = text.match(/\((\D+):(\d+)\)/);
  const surahName = surahMatch ? surahMatch[1] : 'Unknown Surah';
  const speaker = options.speaker || 'القرآن الكريم'; 
  const cleanText = text.replace(/\(\D+:\d+\)/g, '').trim();

  const tempCanvas = createCanvas(1, 1);
  const tempCtx = tempCanvas.getContext('2d');
  tempCtx.font = `${fontSize}px Amiri, Arial`;
  const lines = wrapText(tempCtx, cleanText, maxTextWidth);

  let height = Math.max(500, lines.length * lineHeight + 250); 
  if (height > maxHeight) height = maxHeight;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const centerX = width / 2;

  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, gradientColors[0]);
  gradient.addColorStop(1, gradientColors[1]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  try {
    const patternImage = await loadImage(path.join(__dirname, './islamic_pattern.png'));
    ctx.globalAlpha = 0.1; 
    ctx.drawImage(patternImage, 0, 0, width, height);
    ctx.globalAlpha = 1.0;
  } catch (error) {
  //  console.warn('Could not load background pattern:', error.message);
  }

  ctx.beginPath();
  ctx.arc(centerX, height / 2, 220, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.fill();
  ctx.strokeStyle = gradientColors[0];
  ctx.lineWidth = 4;
  ctx.stroke();

  ctx.font = '40px Amiri Bold, Arial';
  ctx.fillStyle = '#f0e6d2';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 5;
  ctx.shadowOffsetY = 2;
  ctx.fillText('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', centerX, 30);
  ctx.font = `${fontSize}px Amiri, Arial`;
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const startY = 100;
  lines.forEach((line, index) => {
    ctx.fillText(line, centerX, startY + index * lineHeight);
  });

  ctx.font = '36px Amiri Bold, Arial';
  ctx.fillStyle = '#f0e6d2';
  ctx.fillText('صدق الله العظيم', centerX, height - 100);
  ctx.font = '28px Amiri, Arial';
  ctx.fillStyle = '#f0e6d2';
  ctx.shadowBlur = 0;
  ctx.fillText(`سورة ${surahName}`, centerX, height - 70);
  ctx.font = '24px Amiri, Arial';
  ctx.fillText(`- ${speaker} -`, centerX, height - 40);
  ctx.beginPath();
  ctx.moveTo(60, 80);
  ctx.lineTo(width - 60, 80);
  ctx.moveTo(60, height - 130);
  ctx.lineTo(width - 60, height - 130);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.font = '40px Amiri, Arial';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
  //ctx.fillText('﷽', 50, 50);
  //ctx.fillText('﷽', width - 50, height - 160);

  const buffer = canvas.toBuffer('image/jpeg', { quality: 0.95 }); 
  const attachment = new AttachmentBuilder(buffer, { name: 'quran_design.jpg' });

  return { attachment };
}

function wrapText(ctx, text, maxWidth, cache = new Map()) {
  const words = text.split(' ');
  const lines = [];
  let currentLine = words[0] || '';

  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const key = currentLine + ' ' + word;
    let width = cache.get(key);

    if (!width) {
      width = ctx.measureText(key).width;
      cache.set(key, width);
    }

    if (width < maxWidth) {
      currentLine += ' ' + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);
  return lines;
}

module.exports = { createQuranDesignImage };