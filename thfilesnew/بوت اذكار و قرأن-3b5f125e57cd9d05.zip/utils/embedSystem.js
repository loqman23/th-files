// embedSystem.js
const { EmbedBuilder } = require("discord.js");

function createEmbed({
  title,
  description,
  color,
  image,
  thumbnail,
  fields,
  timestamp,
  guild,
  showAuthor = false, 
  showFooter = false  
} = {}) {
  const embed = new EmbedBuilder();

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (color) embed.setColor(color);
  if (image) embed.setImage(image);
  if (thumbnail) embed.setThumbnail(thumbnail);
  if (fields && Array.isArray(fields)) embed.addFields(fields);
  if (timestamp) embed.setTimestamp();

  if (guild && showAuthor) {
    embed.setAuthor({
      name: guild.name,
      iconURL: guild.iconURL({ dynamic: true }) || undefined
    });
  }

  if (guild && showFooter) {
    embed.setFooter({
      text: guild.name,
      iconURL: guild.iconURL({ dynamic: true }) || undefined
    });
  }

  return embed;
}

module.exports = { createEmbed };
