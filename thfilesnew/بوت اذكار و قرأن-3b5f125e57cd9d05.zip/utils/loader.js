// loader.js
const fs = require("fs");
const path = require("path");

function loadSrcFiles(client) {
    const srcPath = path.join(__dirname, "..", "src");
    if (!fs.existsSync(srcPath)) {
        console.warn("[Loader] no f src");
        return;
    }

    const files = fs.readdirSync(srcPath);

    for (const file of files) {
        const filePath = path.join(srcPath, file);

        if (file.endsWith(".js")) {
            try {
                const runFile = require(filePath);

                if (typeof runFile === "function") {
                    runFile(client);
                    console.log(`[Loader] Good ${file}`);
                } else {
                    console.log(`[Loader]  الملف ${file} دالة.`);
                }
            } catch (err) {
                console.error(`[Loader]  خطأ  تحميل ${file}:`, err);
            }
        }
    }
}

module.exports = { loadSrcFiles };
