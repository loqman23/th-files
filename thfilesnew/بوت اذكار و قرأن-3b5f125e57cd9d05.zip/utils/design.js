// design.js
const { createCanvas, registerFont } = require('canvas');
const { AttachmentBuilder } = require('discord.js');
const path = require('path');

registerFont(path.join(__dirname, './Amiri-Regular.ttf'), { family: 'Amiri' });

async function createDesignImage(text, footerText = '', options = {}) {
  const width = options.width || 600;
  const height = options.height || 300;
  const gradientColors = options.gradientColors || ['#04856c', '#1e1e2e'];
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const centerX = width / 2;
  const centerY = height / 2;
  const gradient = ctx.createRadialGradient(centerX, centerY, 50, centerX, centerY, width / 1.5);
  gradient.addColorStop(0, gradientColors[0]);
  gradient.addColorStop(1, gradientColors[1]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
  ctx.beginPath();
  ctx.arc(centerX, centerY, 150, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  ctx.fill();
  ctx.strokeStyle = gradientColors[0];
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.font = '32px Amiri';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.3)';
  ctx.shadowBlur = 3;
  ctx.shadowOffsetY = 1;
  const maxTextWidth = 300;
  const lines = wrapText(ctx, text, maxTextWidth);
  const lineHeight = 40;
  const startY = (height - lines.length * lineHeight) / 2;
  lines.forEach((line, index) => {
    ctx.fillText(line, centerX, startY + index * lineHeight);
  });

  if (footerText) {
    ctx.font = '20px Amiri';
    ctx.fillStyle = '#ffffff';
    ctx.shadowBlur = 0;
    ctx.fillText(footerText, centerX, height - 30);
  }

  ctx.beginPath();
  ctx.moveTo(40, 20);
  ctx.lineTo(width - 40, 20);
  ctx.moveTo(40, height - 15);
  ctx.lineTo(width - 40, height - 15);
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1;
  ctx.stroke();

  const buffer = canvas.toBuffer('image/png');
  const attachment = new AttachmentBuilder(buffer, { name: 'design.png' });

  return { attachment };
}

function wrapText(ctx, text, maxWidth, cache = new Map()) {
  const words = text.split(' ');
  const lines = [];
  let currentLine = words[0];

  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const key = currentLine + ' ' + word;
    let width = cache.get(key);

    if (!width) {
      width = ctx.measureText(key).width;
      cache.set(key, width);
    }

    if (width < maxWidth) {
      currentLine += ' ' + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);
  return lines;
}

module.exports = { createDesignImage };
