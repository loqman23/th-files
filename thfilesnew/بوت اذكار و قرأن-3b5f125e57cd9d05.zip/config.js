module.exports = {
 token: "", // توكن بوتك ميطلعش لي حد 

    //=================== اعدادات =================//
    channelId: '1411667296782389299',
    azkarInterval: '60s', 
    useEmbed: false,   

    //-------------------- إعدادات----------------//
    quranChannelId: '1411680053812527134',
    quranInterval: '1h', 
    useQuranEmbed: false,  


    //=================== اعدادات =================//
     pageChannelId: '1411667310225129473', 
     pageInterval: '60s',
     usepageEmbed: true, 

//لو عاوزه دخل امبيد اكتب   
// بدون امبيد <true>
// بي امبيد true

/*
الوقت كدا 
1s كدا ثواني
1h كدا ساعه 
1m كدا دقيقه
1d يوم 
*/
};
