const { request } = require('undici'); 
const { Client, REST, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createQuranDesignImage } = require('../utils/designpage.js');
const { createEmbed } = require('../utils/embedSystem.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.js');
const rest = new REST({ timeout: 15000 }).setToken(config.token);
const audioCache = new Map();
const ayahDataFile = path.join(__dirname, '../ayahData.json');
let ayahData = {};

if (fs.existsSync(ayahDataFile)) {
  ayahData = JSON.parse(fs.readFileSync(ayahDataFile, 'utf-8'));
}

function saveAyahData() {
  fs.writeFileSync(ayahDataFile, JSON.stringify(ayahData, null, 2));
}

function parseInterval(interval) {
  if (typeof interval === 'number') return interval;
  const match = interval.match(/^(\d+)([smhd])$/);
  if (!match) return 60000;
  const value = parseInt(match[1]);
  const unit = match[2];
  switch (unit) {
    case 's': return value * 1000;
    case 'm': return value * 60 * 1000;
    case 'h': return value * 60 * 60 * 1000;
    case 'd': return value * 24 * 60 * 60 * 1000;
    default: return 60000;
  }
}

async function getRandomAudioEdition() {
  try {
    const { body } = await request('http://api.alquran.cloud/v1/edition?format=audio&language=ar&type=versebyverse', {
      maxRedirections: 5,
      timeout: 5000, 
    });
    const response = await body.json();
    const editions = response.data;
    if (!editions.length) return null;
    return editions[Math.floor(Math.random() * editions.length)].identifier;
  } catch (err) {
    console.error('[Error fetching audio editions]', { message: err.message, stack: err.stack });
    return null;
  }
}

async function getRandomPageAyahs(edition = 'quran-uthmani') {
  const page = Math.floor(Math.random() * 604) + 1;
  try {
    const { body } = await request(`http://api.alquran.cloud/v1/page/${page}/${edition}`, {
      maxRedirections: 5,
      timeout: 5000,
    });
    const response = await body.json();
    const data = response.data.ayahs;
    const randomAyah = data[Math.floor(Math.random() * data.length)];
    return {
      text: `${randomAyah.text} (${randomAyah.surah.name}:${randomAyah.numberInSurah})`,
      surah: randomAyah.surah.name,
      ayahNumber: randomAyah.number,
    };
  } catch (err) {
    console.error('[Error fetching Quran page]', { message: err.message, stack: err.stack });
    return {
      text: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
      surah: 'Unknown',
      ayahNumber: 1,
    };
  }
}

async function getAyahAudio(ayahNumber, edition) {
  const cacheKey = `${ayahNumber}_${edition}`;
  if (audioCache.has(cacheKey)) {
    return audioCache.get(cacheKey);
  }

  if (!edition) return null;
  try {
    const { body: metadataBody } = await request(`http://api.alquran.cloud/v1/ayah/${ayahNumber}/${edition}`, {
      maxRedirections: 5,
      timeout: 5000,
    });
    const metadata = await metadataBody.json();
    const audioUrl = metadata.data.audio;
    const { body: audioBody } = await request(audioUrl, {
      maxRedirections: 5,
      timeout: 10000, 
    });

    const chunks = [];
    for await (const chunk of audioBody) {
      chunks.push(chunk);
    }
    const audioBuffer = Buffer.concat(chunks);

    const audio = {
      name: `ayah_${ayahNumber}.mp3`,
      data: audioBuffer,
    };
    audioCache.set(cacheKey, audio);
    return audio;
  } catch (err) {
    console.error('[Error fetching ayah audio]', { message: err.message, stack: err.stack });
    return null;
  }
}

module.exports = async (client) => {
  client.rest = rest;

  async function sendAyah() {
    const channel = client.channels.cache.get(config.quranChannelId);
    if (!channel) {
      console.error('[Channel not found!]', { channelId: config.quranChannelId });
      return;
    }

    try {
      console.time('sendAyah');
      const audioEdition = await getRandomAudioEdition();
      const { text, surah, ayahNumber } = await getRandomPageAyahs();
      const audioAttachment = await getAyahAudio(ayahNumber, audioEdition);

      const { attachment } = await createQuranDesignImage(text, 'القرآن', { speaker: surah });
      const files = [attachment];

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`play_ayah_audio_${ayahNumber}`)
          .setEmoji('<:question11:1087007903250124800>')
          .setStyle(ButtonStyle.Secondary)
      );

      let embed;
      if (config.useQuranEmbed) {
        embed = createEmbed({
          image: `attachment://${attachment.name}`,
          guild: channel.guild,
          showAuthor: false,
          showFooter: false,
        });
      }

      const msgOptions = { content: null, files, components: [row] };
      if (embed) msgOptions.embeds = [embed];

      const msg = await channel.send(msgOptions);

      ayahData[msg.id] = {
        ayahNumber,
        audioEdition,
      };
      saveAyahData();

      console.timeEnd('sendAyah');
    } catch (err) {
      console.error('[Error sending Quran page]', {
        message: err.message,
        stack: err.stack,
      });
      await channel.send({ content: 'حدث خطأ أثناء إرسال الآية. يرجى المحاولة لاحقًا.' });
    }
  }

  setInterval(sendAyah, parseInterval(config.quranInterval));
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith('play_ayah_audio_')) return;

    try {
      await interaction.deferReply({ ephemeral: true });

      const ayahNumber = parseInt(interaction.customId.replace('play_ayah_audio_', ''));
      const msgId = interaction.message.id;
      const info = ayahData[msgId];

      if (!info || info.ayahNumber !== ayahNumber) {
        return interaction.editReply({ content: 'لم يتم العثور على بيانات الآية. قد تكون الرسالة قديمة.' });
      }

      const audio = await getAyahAudio(info.ayahNumber, info.audioEdition);
      if (!audio) {
        return interaction.editReply({ content: 'لا يوجد صوت متاح لهذه الآية' });
      }

      await interaction.editReply({
        files: [{ attachment: audio.data, name: audio.name }],
      });
    } catch (err) {
      console.error('[Error in button interaction]', {
        message: err.message,
        stack: err.stack,
        custom: interaction.customId,
        messageId: interaction.message.id,
      });
      await interaction.editReply({ content: 'حدث خطأ أثناء تشغيل الصوت. يرجى المحاولة لاحقًا.' });
    }
  });

  client.once('ready', async () => {
    const channel = client.channels.cache.get(config.quranChannelId);
    if (!channel) {
      console.error('[Channel not found on ready!]', { channelId: config.quranChannelId });
      return;
    }

    for (const [msgId, info] of Object.entries(ayahData)) {
      try {
        const msg = await channel.messages.fetch(msgId);
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`play_ayah_audio_${info.ayahNumber}`)
            .setEmoji('<:question11:1087007903250124800>')
            .setStyle(ButtonStyle.Secondary)
        );

        await msg.edit({ components: [row] });
      } catch (err) {
        console.error('[Error restoring buttons]', {
          message: err.message,
          stack: err.stack,
          msgId,
        });
      }
    }
  });
};








































    /*const { Client, REST, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
    const { createQuranDesignImage } = require('../utils/designpage.js');
    const { createEmbed } = require('../utils/embedSystem.js');
    const axios = require('axios');
    const fs = require('fs');
    const path = require('path');
    const config = require('../config.js');
    const rest = new REST({ timeout: 15000 }).setToken(config.token);
    const audioCache = new Map();
    const ayahDataFile = path.join(__dirname, '../ayahData.json');
    let ayahData = {};

    if (fs.existsSync(ayahDataFile)) {
    ayahData = JSON.parse(fs.readFileSync(ayahDataFile, 'utf-8'));
    }

    function saveAyahData() {
    fs.writeFileSync(ayahDataFile, JSON.stringify(ayahData, null, 2));
    }

    function parseInterval(interval) {
    if (typeof interval === 'number') return interval;
    const match = interval.match(/^(\d+)([smhd])$/);
    if (!match) return 60000;
    const value = parseInt(match[1]);
    const unit = match[2];
    switch (unit) {
        case 's': return value * 1000;
        case 'm': return value * 60 * 1000;
        case 'h': return value * 60 * 60 * 1000;
        case 'd': return value * 24 * 60 * 60 * 1000;
        default: return 60000;
    }
    }

    async function getRandomAudioEdition() {
    try {
        const response = await axios.get('http://api.alquran.cloud/v1/edition?format=audio&language=ar&type=versebyverse', {
        timeout: 5000,
        });
        const editions = response.data.data;
        if (!editions.length) return null;
        return editions[Math.floor(Math.random() * editions.length)].identifier;
    } catch (err) {
        console.error('[Error fetching audio editions]', { message: err.message, stack: err.stack });
        return null;
    }
    }

    async function getRandomPageAyahs(edition = 'quran-uthmani') {
    const page = Math.floor(Math.random() * 604) + 1;
    try {
        const response = await axios.get(`http://api.alquran.cloud/v1/page/${page}/${edition}`, {
        timeout: 5000,
        });
        const data = response.data.data.ayahs;
        const randomAyah = data[Math.floor(Math.random() * data.length)];
        return {
        text: `${randomAyah.text} (${randomAyah.surah.name}:${randomAyah.numberInSurah})`,
        surah: randomAyah.surah.name,
        ayahNumber: randomAyah.number,
        };
    } catch (err) {
        console.error('[Error fetching Quran page]', { message: err.message, stack: err.stack });
        return {
        text: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
        surah: 'Unknown',
        ayahNumber: 1,
        };
    }
    }

    async function getAyahAudio(ayahNumber, edition) {
    const cacheKey = `${ayahNumber}_${edition}`;
    if (audioCache.has(cacheKey)) {
        return audioCache.get(cacheKey);
    }

    if (!edition) return null;
    try {
        const response = await axios.get(`http://api.alquran.cloud/v1/ayah/${ayahNumber}/${edition}`, {
        timeout: 5000,
        });
        const audioUrl = response.data.data.audio;
        const audioResponse = await axios.get(audioUrl, {
        responseType: 'arraybuffer',
        timeout: 10000,
        });
        const audio = {
        name: `ayah_${ayahNumber}.mp3`,
        data: audioResponse.data,
        };
        audioCache.set(cacheKey, audio);
        return audio;
    } catch (err) {
        console.error('[Error fetching ayah audio]', { message: err.message, stack: err.stack });
        return null;
    }
    }

    function mergesort(a, left, right) {
    if (left < right) {
        const mid = Math.floor((left + right) / 2);
        mergesort(a, left, mid);
        mergesort(a, mid + 1, right);
        merge(a, left, mid, right);
    }
    }


    module.exports = async (client) => {
    client.rest = rest;

    async function sendAyah() {
        const channel = client.channels.cache.get(config.quranChannelId);
        if (!channel) {
        console.error('[Channel not found!]', { channelId: config.quranChannelId });
        return;
        }

        try {
        console.time('sendAyah');
        const audioEdition = await getRandomAudioEdition();
        const { text, surah, ayahNumber } = await getRandomPageAyahs();
        const audioAttachment = await getAyahAudio(ayahNumber, audioEdition);
        const msg = await channel.send({ content: 'جاري تحميل الآية...', components: [] });
        const { attachment } = await createQuranDesignImage(text, 'القرآن', { speaker: surah });
        const files = [attachment];
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
            .setCustomId(`play_ayah_audio_${ayahNumber}`)
            //.setLabel('صوت')
            .setEmoji('<:question11:1087007903250124800>')
            .setStyle(ButtonStyle.Secondary)
        );

        let embed;
        if (config.useQuranEmbed) {
            embed = createEmbed({
            image: `attachment://${attachment.name}`,
            guild: channel.guild,
            showAuthor: false,
            showFooter: false,
            });
        }

        const msgOptions = { content: null, files, components: [row] };
        if (embed) msgOptions.embeds = [embed];

        await msg.edit(msgOptions);

        ayahData[msg.id] = {
            ayahNumber,
            audioEdition,
        };
        saveAyahData();

        const filter = (i) => i.customId === `play_ayah_audio_${ayahNumber}`;
        const collector = msg.createMessageComponentCollector({ filter, time: 5 * 60 * 1000 });

        collector.on('collect', async (interaction) => {
            try {
            await interaction.deferReply({ ephemeral: true });
            const audio = audioAttachment || await getAyahAudio(ayahNumber, audioEdition);
            if (!audio) {
                return interaction.editReply({ content: 'لا يوجد صوت متاح لهذه الآية' });
            }
            await interaction.editReply({
                files: [{ attachment: audio.data, name: audio.name }],
            });
            } catch (err) {
            console.error('[Error in button interaction]', {
                message: err.message,
                stack: err.stack,
                ayahNumber,
                audioEdition,
            });
            await interaction.editReply({ content: 'حدث خطأ أثناء تشغيل الصوت. يرجى المحاولة لاحقًا.' });
            }
        });

        collector.on('end', () => {
            msg.edit({ components: [] });
        });

        console.timeEnd('sendAyah');
        } catch (err) {
        console.error('[Error sending Quran page]', {
            message: err.message,
            stack: err.stack,
        });
        await channel.send({ content: 'حدث خطأ أثناء إرسال الآية. يرجى المحاولة لاحقًا.' });
        }
    }
    setInterval(sendAyah, parseInterval(config.quranInterval));
    client.once('ready', async () => {
        const channel = client.channels.cache.get(config.quranChannelId);
        if (!channel) {
        console.error('[Channel not found on ready!]', { channelId: config.quranChannelId });
        return;
        }

        for (const [msgId, info] of Object.entries(ayahData)) {
        try {
            const msg = await channel.messages.fetch(msgId);
            const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`play_ayah_audio_${info.ayahNumber}`)
                //.setLabel('صوت')
                .setEmoji('<:question11:1087007903250124800>')
                .setStyle(ButtonStyle.Secondary)
            );

            const filter = (i) => i.customId === `play_ayah_audio_${info.ayahNumber}`;
            const collector = msg.createMessageComponentCollector({ filter, time: 5 * 60 * 1000 });

            collector.on('collect', async (interaction) => {
            try {
                await interaction.deferReply({ ephemeral: true });
                const audio = await getAyahAudio(info.ayahNumber, info.audioEdition);
                if (!audio) {
                return interaction.editReply({ content: 'لا يوجد صوت متاح لهذه الآية' });
                }
                await interaction.editReply({
                files: [{ attachment: audio.data, name: audio.name }],
                });
            } catch (err) {
                console.error('[Error in restored button interaction]', {
                message: err.message,
                stack: err.stack,
                ayahNumber: info.ayahNumber,
                audioEdition: info.audioEdition,
                });
                await interaction.editReply({ content: 'حدث خطأ أثناء تشغيل الصوت. يرجى المحاولة لاحقًا.' });
            }
            });

            collector.on('end', () => {
            msg.edit({ components: [] });
            });
        } catch (err) {
            console.error('[Error restoring buttons]', {
            message: err.message,
            stack: err.stack,
            msgId,
            });
        }
        }
    });
    };*/