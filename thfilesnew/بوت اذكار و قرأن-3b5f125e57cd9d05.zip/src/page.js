const { createQuranDesignImage } = require('../utils/designpage.js');
const { createEmbed } = require('../utils/embedSystem.js');
const axios = require('axios');
const config = require('../config.js');

function parseInterval(interval) {
  if (typeof interval === 'number') return interval;
  const match = interval.match(/^(\d+)([smhd])$/);
  if (!match) return 60000;
  const value = parseInt(match[1]);
  const unit = match[2];
  switch (unit) {
    case 's': return value * 1000;
    case 'm': return value * 60 * 1000;
    case 'h': return value * 60 * 60 * 1000;
    case 'd': return value * 24 * 60 * 60 * 1000;
    default: return 60000;
  }
}

async function getRandomPageAyahs() {
  const page = Math.floor(Math.random() * 604) + 1;
  const url = `http://api.alquran.cloud/v1/page/${page}/quran-uthmani`;

  try {
    const response = await axios.get(url);
    const data = response.data.data.ayahs;
    const ayahsText = data.map(a => `${a.text} (${a.surah.name}:${a.numberInSurah})`).join(' ');
    return { text: ayahsText || 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', surah: data[0]?.surah.name || 'Unknown' };
  } catch (error) {
    console.error('[Error fetching Quran page]', error);
    return { text: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', surah: 'Unknown' };
  }
}

module.exports = (client) => {
  setInterval(async () => {
    const channel = client.channels.cache.get(config.pageChannelId);
    if (!channel) return console.error('[Channel not found!]');

    const { text, surah } = await getRandomPageAyahs();

    try {
      const { attachment } = await createQuranDesignImage(text, 'القرآن', { speaker: surah });

      if (config.usepageEmbed) {
        const embed = createEmbed({
          image: `attachment://${attachment.name}`,
          guild: channel.guild,
          showAuthor: false,
          showFooter: false
        });
        await channel.send({ embeds: [embed], files: [attachment] });
      } else {
        await channel.send({ files: [attachment] });
      }
    } catch (error) {
      console.error('[Error sending Quran page]', error);
    }
  }, parseInterval(config.pageInterval));
};
