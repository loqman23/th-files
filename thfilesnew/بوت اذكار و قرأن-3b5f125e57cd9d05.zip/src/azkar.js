const { createDesignImage } = require('../utils/design');
const { createEmbed } = require('../utils/embedSystem');
const azkar = require('azkar');
const config = require('../config.js');

function parseInterval(interval) {
  const match = interval.match(/^(\d+)([smhd])$/);
  if (!match) return 60000;

  const value = parseInt(match[1]);
  const unit = match[2];

  switch(unit) {
    case 's': return value * 1000;
    case 'm': return value * 60 * 1000;
    case 'h': return value * 60 * 60 * 1000;
    case 'd': return value * 24 * 60 * 60 * 1000;
    default: return 60000;
  }
}

module.exports = (client) => {
  setInterval(async () => {
    const channel = client.channels.cache.get(config.channelId);
    if (!channel) return console.error('[Channel not found!]');

    const zikrObj = azkar.random();
    const zikrText = zikrObj.zekr || 'سبحان الله';
    const zikrCategory = zikrObj.category || 'ذكر عام';

    try {
      const { attachment } = await createDesignImage(zikrText, `ذكر: ${zikrCategory}`);

      if (config.useEmbed) {
        const embed = createEmbed({
          image: `attachment://${attachment.name}`,
          timestamp: true,
          guild: channel.guild, 
        });

        await channel.send({ embeds: [embed], files: [attachment] });
      } else {
        await channel.send({ files: [attachment] });
      }

    } catch (error) {
      console.error('[Error sending Zikr:]', error);
    }
  }, parseInterval(config.azkarInterval));
};
