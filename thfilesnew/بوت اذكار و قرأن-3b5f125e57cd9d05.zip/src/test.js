const { createDesignImage } = require('../utils/design');
/*const { createEmbed } = require('../utils/embedSystem');
module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        if (message.content === '*تست') {
            const { attachment } = await createDesignImage("سبحان الله", "ذكر عام");
            // message.channel.send({ files: [attachment] });
            const embed = createEmbed({
                image: "attachment://design.png",
                color: "#04856c",
                guild: message.guild
            });

            message.channel.send({ embeds: [embed], files: [attachment] });
        }
    });
};*/
module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        if (message.content === '*تست') {
            const { attachment } = await createDesignImage("سبحان الله", "ذكر عام");
            message.channel.send({ files: [attachment] });
        }
    });
};
