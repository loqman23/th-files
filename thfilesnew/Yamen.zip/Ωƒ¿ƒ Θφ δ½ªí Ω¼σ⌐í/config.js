module.exports = {
  prefix: process.env.PREFIX || '-',
  
  commands: {
    whatif: {
      name: 'ماذا-لو',
      aliases: ['whatif', 'what-if', 'ماذالو'],
      cooldown: 60000, 
      description: 'يرسل سؤال "ماذا لو؟" لإثارة التفاعل في السيرفر'
    }
  },
  
  embed: {
    color: '#7289DA', 
    accentColor: '#FFD700', 
    footer: {
      text: '💭 ماذا لو؟ | سؤال رقم {questionNumber} من {totalQuestions}',
      iconURL: '{serverIcon}'
    },
    author: {
      name: '{serverName} - أسئلة ماذا لو؟',
      iconURL: '{serverIcon}'
    }
  }
};