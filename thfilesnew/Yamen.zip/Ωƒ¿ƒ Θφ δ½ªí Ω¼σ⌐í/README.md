# Discord "What If?" Bot

A professional Discord bot that sends "What if?" questions in Arabic to spark conversation and engagement in your server.

## Features

- Command (`-ماذا-لو`) that sends beautifully designed embedded messages
- Large collection of thought-provoking "What if?" questions in Arabic
- Professional embed design with server branding integration
- Random question selection with no repetition until all questions are used
- Cooldown system to prevent command spam
- Error handling and logging for reliability
- Easy configuration through a config file
- Permission checks for command usage

## Setup

1. Clone this repository
2. Create a `.env` file based on `.env.example`
3. Add your Discord bot token to the `.env` file
4. Install dependencies with `npm install`
5. Start the bot with `npm start`

## Commands

- `-ماذا-لو` - Sends a random "What if?" question to spark conversation
- Aliases: `whatif`, `what-if`, `ماذالو`

## Customization

You can customize the bot by editing the following files:

- `config.js` - Bot configuration including prefix, cooldowns, and embed styling
- `data/questions.js` - Add or modify the list of "What if?" questions

## License

MIT