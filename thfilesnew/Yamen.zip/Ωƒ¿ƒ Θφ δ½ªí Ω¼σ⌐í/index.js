require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const config = require('./config');
const { displayLoginInfo } = require('./utils/loginDisplay');

const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ] 
});

client.commands = new Collection();
client.cooldowns = new Collection();

displayLoginInfo(client);

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  
  if ('data' in command && 'execute' in command) {
    client.commands.set(command.data.name, command);
    console.log(chalk.green(`[✅] Loaded command: ${command.data.name}`));
  } else {
    console.log(chalk.red(`[❌] The command at ${filePath} is missing a required "data" or "execute" property.`));
  }
}

client.once(Events.ClientReady, () => {
  console.log(chalk.green(`[✅] Logged in as ${client.user.tag}!`));
  console.log(chalk.blue(`[📊] Serving ${client.guilds.cache.size} servers`));
  console.log(chalk.yellow('[🤖] Bot is ready!'));
  
  displayLoginInfo(client);
});

client.on(Events.MessageCreate, async message => {
  if (message.author.bot || !message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command = client.commands.find(cmd => 
    cmd.data.name === commandName || 
    (cmd.data.aliases && cmd.data.aliases.includes(commandName))
  );

  if (!command) return;

  const { cooldowns } = client;
  
  if (!cooldowns.has(command.data.name)) {
    cooldowns.set(command.data.name, new Collection());
  }
  
  const now = Date.now();
  const timestamps = cooldowns.get(command.data.name);
  const cooldownAmount = (command.cooldown || config.commands[command.data.name]?.cooldown || 3) * 1000;
  
  if (timestamps.has(message.author.id)) {
    const expirationTime = timestamps.get(message.author.id) + cooldownAmount;
    
    if (now < expirationTime) {
      const timeLeft = (expirationTime - now) / 1000;
      return message.reply(`⏰ يرجى الانتظار ${timeLeft.toFixed(1)} ثوانٍ قبل استخدام الأمر \`${command.data.name}\` مرة أخرى.`);
    }
  }
  
  timestamps.set(message.author.id, now);
  setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

  // Execute the command
  try {
    await command.execute(message, args);
  } catch (error) {
    console.error(error);
    await message.reply('❌ حدث خطأ أثناء تنفيذ هذا الأمر!');
  }
});


client.login('MTM0NzQwMjgwNjQxNTQ1ODMzNg.Gp9o6A.y1ES-oywJ3LHDzfbrFpqIy09ADOwpXFyR2zDUk');