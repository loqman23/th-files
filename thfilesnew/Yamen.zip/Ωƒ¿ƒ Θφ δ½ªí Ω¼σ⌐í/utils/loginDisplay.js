const chalk = require('chalk');
const figlet = require('figlet');
const gradient = require('gradient-string');

function displayLoginInfo(client) {
  console.log('\n');
  console.log(gradient.rainbow.multiline(figlet.textSync('What If Bot', {
    font: 'ANSI Shadow',
    horizontalLayout: 'fitted',
    verticalLayout: 'fitted'
  })));

  const palestineColors = ['#007A3D', '#FFFFFF', '#000000', '#CE1126'];
  console.log('\n' + gradient(palestineColors)('═'.repeat(100)));
  console.log(gradient(palestineColors).multiline('🇵🇸 فلسطين حرة 🇵🇸'));
  console.log(gradient(palestineColors)('═'.repeat(100)) + '\n');

  const stats = {
    servers: client?.guilds.cache.size || 'Loading...',
    users: client?.users.cache.size || 'Loading...',
    channels: client?.channels.cache.size || 'Loading...',
    uptime: client ? formatUptime(client.uptime) : 'Starting...'
  };

  console.log(chalk.bold.cyan('📊 Bot Statistics'));
  console.log(chalk.blue('┌' + '─'.repeat(48) + '┐'));
  console.log(chalk.blue('│') + gradient.passion(` 🏰 Servers      : ${stats.servers}`.padEnd(47)) + chalk.blue('│'));
  console.log(chalk.blue('│') + gradient.passion(` 👥 Users        : ${stats.users}`.padEnd(47)) + chalk.blue('│'));
  console.log(chalk.blue('│') + gradient.passion(` 📺 Channels     : ${stats.channels}`.padEnd(47)) + chalk.blue('│'));
  console.log(chalk.blue('│') + gradient.passion(` ⏱️  Uptime       : ${stats.uptime}`.padEnd(47)) + chalk.blue('│'));
  console.log(chalk.blue('└' + '─'.repeat(48) + '┘\n'));

  console.log(chalk.bold.green('🤖 Bot Information'));
  console.log(chalk.green('┌' + '─'.repeat(58) + '┐'));
  console.log(chalk.green('│') + chalk.cyan(' • Professional Discord bot for engaging conversations'.padEnd(57)) + chalk.green('│'));
  console.log(chalk.green('│') + chalk.cyan(' • Thought-provoking "What If?" questions in Arabic'.padEnd(57)) + chalk.green('│'));
  console.log(chalk.green('│') + chalk.cyan(' • Beautiful embedded messages with custom designs'.padEnd(57)) + chalk.green('│'));
  console.log(chalk.green('│') + chalk.cyan(' • Advanced question tracking and analytics system'.padEnd(57)) + chalk.green('│'));
  console.log(chalk.green('└' + '─'.repeat(58) + '┘\n'));

  console.log(chalk.bold.yellow('👑 Credits'));
  console.log(chalk.yellow('┌' + '─'.repeat(38) + '┐'));
  console.log(chalk.yellow('│') + gradient.morning(' Thailand Codes - Development Partner'.padEnd(37)) + chalk.yellow('│'));
  console.log(chalk.yellow('│') + gradient.morning(' Yamen (jeramoentr) - Project Creator + loqman '.padEnd(37)) + chalk.yellow('│'));
  console.log(chalk.yellow('└' + '─'.repeat(38) + '┘\n'));

  console.log(chalk.bold.magenta('🖥️  System Information'));
  console.log(chalk.magenta('┌' + '─'.repeat(48) + '┐'));
  console.log(chalk.magenta('│') + chalk.white(` Node.js: ${process.version}`.padEnd(47)) + chalk.magenta('│'));
  console.log(chalk.magenta('│') + chalk.white(` Discord.js: ${require('discord.js').version}`.padEnd(47)) + chalk.magenta('│'));
  console.log(chalk.magenta('│') + chalk.white(` Platform: ${process.platform}`.padEnd(47)) + chalk.magenta('│'));
  console.log(chalk.magenta('└' + '─'.repeat(48) + '┘\n'));

  console.log(gradient(palestineColors)('═'.repeat(100)) + '\n');
}

function formatUptime(ms) {
  if (!ms) return 'Starting...';
  
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));

  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0) parts.push(`${minutes}m`);
  parts.push(`${seconds}s`);

  return parts.join(' ');
}

module.exports = {
  displayLoginInfo
};