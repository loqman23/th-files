const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

// Register custom Arabic font
registerFont(path.join(__dirname, 'yamen.ttf'), { family: 'Yamen' });

async function createQuestionImage(question) {
  // Create canvas with 16:9 aspect ratio
  const width = 1200;
  const height = 675;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Load and draw background
  const background = await loadImage('https://images.pexels.com/photos/998641/pexels-photo-998641.jpeg');
  ctx.drawImage(background, 0, 0, width, height);

  // Add gradient overlay
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, 'rgba(0, 0, 0, 0.8)');
  gradient.addColorStop(0.5, 'rgba(47, 53, 66, 0.8)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0.8)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Add decorative frame
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 8;
  ctx.strokeRect(30, 30, width - 60, height - 60);
  
  // Add inner frame
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
  ctx.lineWidth = 2;
  ctx.strokeRect(45, 45, width - 90, height - 90);

  // Add decorative corners
  const cornerSize = 40;
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 4;
  
  // Top left corner
  ctx.beginPath();
  ctx.moveTo(30, 90);
  ctx.lineTo(30, 30);
  ctx.lineTo(90, 30);
  ctx.stroke();
  
  // Top right corner
  ctx.beginPath();
  ctx.moveTo(width - 90, 30);
  ctx.lineTo(width - 30, 30);
  ctx.lineTo(width - 30, 90);
  ctx.stroke();
  
  // Bottom left corner
  ctx.beginPath();
  ctx.moveTo(30, height - 90);
  ctx.lineTo(30, height - 30);
  ctx.lineTo(90, height - 30);
  ctx.stroke();
  
  // Bottom right corner
  ctx.beginPath();
  ctx.moveTo(width - 90, height - 30);
  ctx.lineTo(width - 30, height - 30);
  ctx.lineTo(width - 30, height - 90);
  ctx.stroke();

  // Add title with glow effect
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Glow effect
  ctx.shadowColor = '#FFD700';
  ctx.shadowBlur = 15;
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 120px "Yamen"'; // Increased font size
  ctx.fillText('ماذا لو؟', width / 2, 120);
  
  // Reset shadow
  ctx.shadowBlur = 0;

  // Improved text wrapping for questions
  ctx.font = '900 80px "Yamen"'; // Increased font size
  const maxWidth = width - 160;
  const lineHeight = 100; // Increased line height
  
  // Split text into words and handle text wrapping
  const words = question.split(' ');
  let lines = [];
  let currentLine = '';
  
  // Process words from right to left for Arabic
  for (let i = words.length - 1; i >= 0; i--) {
    const word = words[i];
    const testLine = word + (currentLine ? ' ' + currentLine : '');
    const metrics = ctx.measureText(testLine);
    
    if (metrics.width > maxWidth && currentLine !== '') {
      lines.unshift(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  lines.unshift(currentLine);

  // Calculate starting Y position to center text vertically
  let startY = (height - (lines.length * lineHeight)) / 2;
  
  // Draw each line
  lines.forEach((line, index) => {
    // Add subtle text shadow for depth
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 5;
    ctx.shadowOffsetY = 3;
    ctx.fillText(line, width / 2, startY + (index * lineHeight));
  });

  // Add decorative divider
  const dividerY = height - 100;
  const dividerWidth = 300;
  
  ctx.beginPath();
  ctx.moveTo(width / 2 - dividerWidth / 2, dividerY);
  ctx.lineTo(width / 2 + dividerWidth / 2, dividerY);
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 4;
  ctx.stroke();

  // Add small decorative dots
  const dotRadius = 4;
  ctx.fillStyle = '#FFD700';
  ctx.beginPath();
  ctx.arc(width / 2 - dividerWidth / 2 - 15, dividerY, dotRadius, 0, Math.PI * 2);
  ctx.arc(width / 2 + dividerWidth / 2 + 15, dividerY, dotRadius, 0, Math.PI * 2);
  ctx.fill();

  return canvas.toBuffer();
}

module.exports = {
  createQuestionImage
};