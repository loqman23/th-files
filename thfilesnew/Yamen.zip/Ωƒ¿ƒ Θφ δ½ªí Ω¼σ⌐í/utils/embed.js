const { EmbedBuilder } = require('discord.js');
const config = require('../config');

function createWhatIfEmbed({ question, questionNumber, totalQuestions, guild, imageUrl }) {
  const serverName = guild.name;
  const serverIcon = guild.iconURL({ dynamic: true }) || 'https://i.imgur.com/6YToyEF.png';
  
  const footerText = config.embed.footer.text
    .replace('{questionNumber}', questionNumber)
    .replace('{totalQuestions}', totalQuestions);
  
  const authorName = config.embed.author.name
    .replace('{serverName}', serverName);
  
  const colors = [
    '#7289DA', 
    '#5865F2', 
    '#9B59B6', 
    '#8A2BE2', 
    '#4B0082', 
    '#483D8B'  
  ];
  
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  

  const embed = new EmbedBuilder()
    .setColor(randomColor)
    .setAuthor({
      name: authorName,
      iconURL: serverIcon
    })
    .setTitle('💭 ماذا لو؟')
    .setDescription(`**${question}**`)
    .setImage(imageUrl)
    .setTimestamp()
    .setFooter({
      text: footerText.replace('{serverIcon}', serverIcon),
      iconURL: serverIcon
    });
  
  embed.addFields({ name: '\u200B', value: '```اكتب رأيك ورد على هذا السؤال```' });
  
  return embed;
}

module.exports = {
  createWhatIfEmbed
};