module.exports = {
    TOKEN: '', // توكن البوت من dev portal
    GUILD_ID: '1422871675594342403', // ID السيرفر 
    supportRoleId: '1422871842879705119', // ID رول الدعم
    ticketCategoryId: '1422871676365832274', // ID كاتيغوري التذاكر
    logTickets: '1422871933787050096', // ID روم اللوج
    embedColor: '#B19072', 
    EMOJIS: {
        english: '<:lettere1:1421461161697738793>',
        arabic: '<:ain1:1421461536760926403>',
        support: '<:support:1421777799420710963>',
        shop: '<:shop:1421777799420710963>',
        cooperation: '<:cooperation:1421777799420710963>',
        adduser: '<:adduser:1421777481110786150>',
        bot: '<:91601botroleicon:1376241548617846946>',
        tools: '<:WindowsAdministrativeTools:1384623618742288474>',
        design: '<:Design:1055770358432665600>',
        web: '<:50558web:1295975037030895696>',
        codeEdit: '<:edit:1404195144995176560>',
        designEdit: '<:36438designer:1295975024435658762>',
        close: '<:close:1421461914571116715>',
        movie: '<:movie:1421451158374973450>', // لزر الشوب في البينل
        star: '<:01whitestar:1384624799984123975>',
        paypal: '<a:aC_PayPal_op:1094684328706986195>',
        visa: '<:Visa:1254347737588301918>',
        vodafone: '<:vodafone:1335605924576100433>',
        credit: '<a:11Credit:1296489410963050568>',
        mastercard: '<:Mastercardlogo:1326051454183804979>',
        customPayment: '<a:Haraketli_Emoji_212:1409970835434766368>',
        lifetime: '<a:utility4:1217328671204053022>',
        subscription: '<:subscriptionmodel:1367203672064266250>'
    },

    // روابط الصور (للبينل والتذاكر)
    IMAGES: {
        panelTop: 'https://cdn.discordapp.com/attachments/1421428684505485474/1421453783178809487/jj.png?ex=68d9177f&is=68d7c5ff&hm=5b0650ab9aaaf402c1146b4d20c65a5ad1c8715b29c8170fe9f21424310a59b3&',
        panelBottom: 'https://cdn.discordapp.com/attachments/1421428684505485474/1421435692969496597/image.png?ex=68d906a6&is=68d7b526&hm=462f91fa1409868510880673b23188ec54fcbbf56d7b8190636f6dfeabe54eb3&',
        ticketImage: 'https://cdn.discordapp.com/attachments/1421499087383167088/1421518338416447488/image.png?ex=68d9fc5e&is=68d8aade&hm=d6673428f5a382183330bf7db1710843f8448b824ed1db58310a67486eaca188&'
    },

    restrictMultipleTickets: false, // true/false لمنع تذاكر متعددة
    initialTicketNumber: 1 
};