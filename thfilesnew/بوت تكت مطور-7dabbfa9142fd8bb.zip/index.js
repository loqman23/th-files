const { Client, GatewayIntentBits, Collection, SlashCommandBuilder, PermissionFlagsBits, ChannelType, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextDisplayBuilder, ContainerBuilder, MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, SeparatorBuilder, SeparatorSpacingSize, ThumbnailBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder } = require('discord.js');
const { REST, Routes } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');
const fs = require('fs');
const path = require('path');
const config = require('./config.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
client.commands = new Collection();
client.buttons = new Collection();
const hexToDecimal = (hex) => parseInt(hex.replace('#', ''), 16);
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const ticketsFile = path.join(dataDir, 'tickets.json');
function getLastTicketNumber() {
    if (!fs.existsSync(ticketsFile)) {
        saveLastTicketNumber(config.initialTicketNumber);
        return config.initialTicketNumber;
    }
    const data = JSON.parse(fs.readFileSync(ticketsFile, 'utf8'));
    return data.lastTicket || config.initialTicketNumber;
}
function saveLastTicketNumber(number) {
    fs.writeFileSync(ticketsFile, JSON.stringify({ lastTicket: number }, null, 4));
}

const commands = [
    new SlashCommandBuilder()
        .setName('ticket-panel')
        .setDescription('إرسال أو تحديث لوحة التذاكر')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(option => option.setName('channel').setDescription('القناة').setRequired(true))
        .addStringOption(option => option.setName('text_before').setDescription('النص قبل الزر').setRequired(false))
        .addStringOption(option => option.setName('text_after').setDescription('النص بعد الزر').setRequired(false))
        .addStringOption(option => option.setName('message_id').setDescription('معرف الرسالة لتحديث اللوحة').setRequired(false))
        .addStringOption(option => option.setName('shop_button_label').setDescription('نص زر التذكرة').setRequired(false))
        .addStringOption(option => option.setName('shop_button_emoji').setDescription('إيموجي زر التذكرة').setRequired(false))
        .addStringOption(option =>
            option.setName('shop_button_style').setDescription('لون زر التذكرة').addChoices(
                { name: 'Primary', value: 'Primary' }, { name: 'Secondary', value: 'Secondary' },
                { name: 'Success', value: 'Success' }, { name: 'Danger', value: 'Danger' }
            ).setRequired(false)
        )
        .addBooleanOption(option => option.setName('shop_button_enabled').setDescription('تفعيل زر التذكرة').setRequired(false))
        .addBooleanOption(option => option.setName('shop_button_visible').setDescription('إظهار زر التذكرة').setRequired(false))
        .addStringOption(option => option.setName('accent_color').setDescription('لون الحافة (hex code like #B19072)').setRequired(false)).toJSON()
].map(command => ({ name: command.name, description: command.description, options: command.options }));

client.commands.set('ticket-panel', { data: commands[0], async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const channel = interaction.options.getChannel('channel');
    const messageId = interaction.options.getString('message_id');
    const textBefore = interaction.options.getString('text_before') || '> **مرحباً بك في نظام التذاكر الخاص بنا!**\n> **اضغط على الزر أدناه لإنشاء تذكرة دعم.**';
    const textAfter = interaction.options.getString('text_after') || null;
    const shopButtonLabel = interaction.options.getString('shop_button_label') || 'Create Ticket';
    const shopButtonEmoji = interaction.options.getString('shop_button_emoji') || config.EMOJIS.movie;
    const shopButtonStyle = interaction.options.getString('shop_button_style') || 'Secondary';
    const shopButtonEnabled = interaction.options.getBoolean('shop_button_enabled') ?? true;
    const shopButtonVisible = interaction.options.getBoolean('shop_button_visible') ?? true;
    const accentColor = interaction.options.getString('accent_color') || config.embedColor;
    const accentColorDecimal = hexToDecimal(accentColor);

    const buttonStyles = { Primary: ButtonStyle.Primary, Secondary: ButtonStyle.Secondary, Success: ButtonStyle.Success, Danger: ButtonStyle.Danger };
    const container = new ContainerBuilder().setAccentColor(accentColorDecimal).addTextDisplayComponents(textDisplay => textDisplay.setContent(textBefore));

    if (shopButtonVisible) {
        container.addActionRowComponents(actionRow => actionRow.setComponents(
            new ButtonBuilder().setLabel(shopButtonLabel).setEmoji(shopButtonEmoji).setStyle(buttonStyles[shopButtonStyle] || ButtonStyle.Primary)
                .setDisabled(!shopButtonEnabled).setCustomId('shop_button')
        ));
    }

    const mediaGallery = new MediaGalleryBuilder().addItems(mediaGalleryItem => mediaGalleryItem.setDescription('سطر').setURL(config.IMAGES.panelTop));
    const components = [mediaGallery, new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small), container];

    if (textAfter) {
        components.push(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small), new TextDisplayBuilder().setContent(textAfter),
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small), new MediaGalleryBuilder().addItems(
                mediaGalleryItem => mediaGalleryItem.setDescription('سطر').setURL(config.IMAGES.panelBottom)
            ));
    }

    const dataPath = path.join(__dirname, 'data/ticket-panels.json');
    try {
        const panelsData = fs.existsSync(dataPath) ? JSON.parse(fs.readFileSync(dataPath)) : {};
        if (messageId) {
            const msg = await channel.messages.fetch(messageId).catch(() => null);
            if (!msg) return interaction.editReply({ content: 'خطأ: لم أستطع جلب الرسالة' });
            await msg.edit({ components, flags: [MessageFlags.IsComponentsV2], content: null, embeds: null, stickers: null, poll: null });
            panelsData[channel.id] = { messageId };
            fs.writeFileSync(dataPath, JSON.stringify(panelsData, null, 2));
            return interaction.editReply({ content: `تم تحديث لوحة التذاكر في ${channel}` });
        } else {
            const sentMsg = await channel.send({ components, flags: [MessageFlags.IsComponentsV2] });
            panelsData[channel.id] = { messageId: sentMsg.id };
            fs.writeFileSync(dataPath, JSON.stringify(panelsData, null, 2));
            return interaction.editReply({ content: `تم إرسال لوحة التذاكر في ${channel}` });
        }
    } catch (err) {
        console.error('[TicketPanel Error]', err);
        interaction.editReply({ content: 'حصل خطأ أثناء إرسال/تحديث الرسالة' });
    }
} });

client.buttons.set('shop_button', { async execute(interaction) {
    const member = interaction.member;
    if (config.restrictMultipleTickets) {
        const existingTicket = interaction.guild.channels.cache.find(c => c.topic === `[${member.id}]`);
        if (existingTicket) {
            const alreadyText = new TextDisplayBuilder().setContent(`> ** - You already have an open ticket: ${existingTicket}**`);
            return interaction.reply({ components: [alreadyText], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });
        }
    }

    const languageContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent('> ** - Please select your preferred language**'))
        .addActionRowComponents(row => row.addComponents(
            new ButtonBuilder().setCustomId('lang_english').setLabel('English').setEmoji(config.EMOJIS.english).setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('lang_arabic').setLabel('العربية').setEmoji(config.EMOJIS.arabic).setStyle(ButtonStyle.Secondary)
        ));

    await interaction.reply({ components: [languageContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

    const languageFilter = i => i.customId.startsWith('lang_') && i.user.id === interaction.user.id;
    const languageCollector = interaction.channel.createMessageComponentCollector({ filter: languageFilter, time: 60000 });

    languageCollector.on('collect', async i => {
        const language = i.customId === 'lang_english' ? 'english' : 'arabic';
        await showTicketTypeMenu(i, member, language, interaction);
        languageCollector.stop();
    });

    languageCollector.on('end', async (collected, reason) => {
        if (reason === 'time' && collected.size === 0) {
            const timeoutText = new TextDisplayBuilder().setContent('> ** - Language selection timed out**');
            await interaction.editReply({ components: [timeoutText], flags: [MessageFlags.IsComponentsV2] });
        }
    });
}});

async function showTicketTypeMenu(interaction, member, language, originalInteraction) {
    const isArabic = language === 'arabic';
    const ticketTypeMenu = new StringSelectMenuBuilder().setCustomId('ticket_type_select')
        .setPlaceholder(isArabic ? 'اختر نوع التذكرة' : 'Select ticket type')
        .addOptions(
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تذكرة عادية' : 'Regular Ticket').setValue('regular')
                .setDescription(isArabic ? 'طلب تذكرة عادية للدعم' : 'Request a regular support ticket').setEmoji(config.EMOJIS.support),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تذكرة المتجر' : 'Shop Ticket').setValue('shop')
                .setDescription(isArabic ? 'طلب منتجات أو خدمات من المتجر' : 'Request products or services from the shop').setEmoji(config.EMOJIS.shop)
        );

    const ticketTypeContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(isArabic ? '> ** - من فضلك اختر نوع التذكرة**' : '> ** - Please select the ticket type**'))
        .addActionRowComponents(row => row.addComponents(ticketTypeMenu));

    await interaction.update({ components: [ticketTypeContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

    const ticketTypeFilter = i => i.customId === 'ticket_type_select' && i.user.id === interaction.user.id;
    const ticketTypeCollector = interaction.channel.createMessageComponentCollector({ filter: ticketTypeFilter, time: 60000 });

    ticketTypeCollector.on('collect', async i => {
        const ticketType = i.values[0];
        if (ticketType === 'shop') await showCategoryMenu(i, member, language, originalInteraction);
        else await showRegularTicketMenu(i, member, language, originalInteraction);
        ticketTypeCollector.stop();
    });

    ticketTypeCollector.on('end', async (collected, reason) => {
        if (reason === 'time' && collected.size === 0) {
            const timeoutText = new TextDisplayBuilder().setContent(isArabic ? '> ** - انتهت مهلة اختيار نوع التذكرة**' : '> ** - Ticket type selection timed out**');
            await interaction.update({ components: [timeoutText], flags: [MessageFlags.IsComponentsV2] });
        }
    });
}

async function showRegularTicketMenu(interaction, member, language, originalInteraction) {
    const isArabic = language === 'arabic';
    const regularMenu = new StringSelectMenuBuilder().setCustomId('regular_ticket_select')
        .setPlaceholder(isArabic ? 'اختر نوع التذكرة العادية' : 'Select regular ticket type')
        .addOptions(
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'طلب شراكة' : 'Partners').setValue('partners')
                .setDescription(isArabic ? 'تقديم طلب للشراكة' : 'Submit a partnership request').setEmoji(config.EMOJIS.cooperation),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تقديم مبرمج' : 'Apply as Programmer').setValue('programmer')
                .setDescription(isArabic ? 'تقديم طلب للانضمام كمبرمج' : 'Apply to join as a programmer').setEmoji(config.EMOJIS.adduser)
        );

    const regularContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(isArabic ? '> ** - من فضلك اختر نوع التذكرة العادية**' : '> ** - Please select a regular ticket type**'))
        .addActionRowComponents(row => row.addComponents(regularMenu));

    await interaction.update({ components: [regularContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

    const regularFilter = i => i.customId === 'regular_ticket_select' && i.user.id === interaction.user.id;
    const regularCollector = interaction.channel.createMessageComponentCollector({ filter: regularFilter, time: 60000 });

    regularCollector.on('collect', async i => {
        const type = i.values[0] === 'partners' ? (isArabic ? 'طلب شراكة' : 'Partners') : (isArabic ? 'تقديم مبرمج' : 'Apply as Programmer');
        await createTicket(i, member, type, language, originalInteraction);
        regularCollector.stop();
    });

    regularCollector.on('end', async (collected, reason) => {
        if (reason === 'time' && collected.size === 0) {
            const timeoutText = new TextDisplayBuilder().setContent(isArabic ? '> ** - انتهت مهلة اختيار التذكرة العادية**' : '> ** - Regular ticket selection timed out**');
            await interaction.update({ components: [timeoutText], flags: [MessageFlags.IsComponentsV2] });
        }
    });
}

async function showCategoryMenu(interaction, member, language, originalInteraction) {
    const isArabic = language === 'arabic';
    const selectMenu = new StringSelectMenuBuilder().setCustomId('shop_category_select')
        .setPlaceholder(isArabic ? 'اختر الفئة' : 'Select a category')
        .addOptions(
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'بوت' : 'Bot').setValue('bot').setDescription(isArabic ? 'طلب بوت مخصص' : 'Order a custom bot').setEmoji(config.EMOJIS.bot),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'أدوات' : 'Tools').setValue('tools').setDescription(isArabic ? 'طلب اشتراك أدوات' : 'Order tools subscription').setEmoji(config.EMOJIS.tools),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تصميم' : 'Design').setValue('design').setDescription(isArabic ? 'طلب تصميم مخصص' : 'Order a custom design').setEmoji(config.EMOJIS.design),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'إنشاء موقع' : 'Website Creation').setValue('website_creation').setDescription(isArabic ? 'طلب إنشاء موقع جديد' : 'Order a new website').setEmoji(config.EMOJIS.web),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تعديل كود' : 'Code Editing').setValue('code_editing').setDescription(isArabic ? 'طلب تعديل كود' : 'Order code editing').setEmoji(config.EMOJIS.codeEdit),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تعديل تصميم' : 'Design Editing').setValue('design_editing').setDescription(isArabic ? 'طلب تعديل تصميم' : 'Order design editing').setEmoji(config.EMOJIS.designEdit),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'تعديل موقع' : 'Website Editing').setValue('website_editing').setDescription(isArabic ? 'طلب تعديل موقع' : 'Order website editing').setEmoji(config.EMOJIS.web),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'حماية موقع' : 'Website Protection').setValue('website_protection').setDescription(isArabic ? 'طلب حماية موقع' : 'Order website protection').setEmoji(config.EMOJIS.web)
        );

    const selectContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(isArabic ? '> ** - من فضلك اختر فئة التذكرة**' : '> ** - Please select a category for your ticket**'))
        .addActionRowComponents(row => row.addComponents(selectMenu));

    await interaction.update({ components: [selectContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

    const filter = i => i.customId === 'shop_category_select' && i.user.id === interaction.user.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
        const selection = i.values[0];
        if (selection === 'tools') {
            const toolsMenu = new StringSelectMenuBuilder().setCustomId('tools_duration_select')
                .setPlaceholder(isArabic ? 'اختر المدة' : 'Select a duration')
                .addOptions(
                    new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'مدى الحياة' : 'Lifetime').setValue('lifetime')
                        .setDescription(isArabic ? 'الوصول مدى الحياة للأدوات' : 'Lifetime tools access').setEmoji(config.EMOJIS.lifetime),
                    new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'اشتراك' : 'Subscription').setValue('subscription')
                        .setDescription(isArabic ? 'اشتراك شهري للأدوات' : 'Monthly tools subscription').setEmoji(config.EMOJIS.subscription)
                );

            const toolsContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
                .addTextDisplayComponents(text => text.setContent(isArabic ? '> ** - من فضلك اختر مدة الأدوات**' : '> ** - Please select a duration for tools**'))
                .addActionRowComponents(row => row.addComponents(toolsMenu));

            await i.update({ components: [toolsContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

            const toolsFilter = t => t.customId === 'tools_duration_select' && t.user.id === interaction.user.id;
            const toolsCollector = interaction.channel.createMessageComponentCollector({ filter: toolsFilter, time: 60000 });

            toolsCollector.on('collect', async t => {
                const duration = t.values[0];
                const type = isArabic ? `أدوات (${duration === 'lifetime' ? 'مدى الحياة' : 'اشتراك'})` : `Tools (${duration.charAt(0).toUpperCase() + duration.slice(1)})`;
                await showPaymentMenu(t, member, type, language, originalInteraction);
                toolsCollector.stop();
            });

            toolsCollector.on('end', async (collected, reason) => {
                if (reason === 'time' && collected.size === 0) {
                    const timeoutText = new TextDisplayBuilder().setContent(isArabic ? '> ** - انتهت مهلة إنشاء التذكرة**' : '> ** - Ticket creation timed out**');
                    await i.update({ components: [timeoutText], flags: [MessageFlags.IsComponentsV2] });
                }
            });
        } else {
            const type = isArabic ?
                (selection === 'bot' ? 'بوت مخصص' : selection === 'design' ? 'تصميم' : selection === 'website_creation' ? 'إنشاء موقع' :
                 selection === 'code_editing' ? 'تعديل كود' : selection === 'design_editing' ? 'تعديل تصميم' :
                 selection === 'website_editing' ? 'تعديل موقع' : 'حماية موقع') :
                (selection === 'bot' ? 'Developer Bot' : selection === 'design' ? 'Design' : selection === 'website_creation' ? 'Website Creation' :
                 selection === 'code_editing' ? 'Code Editing' : selection === 'design_editing' ? 'Design Editing' :
                 selection === 'website_editing' ? 'Website Editing' : 'Website Protection');
            await showPaymentMenu(i, member, type, language, originalInteraction);
        }
        collector.stop();
    });

    collector.on('end', async (collected, reason) => {
        if (reason === 'time' && collected.size === 0) {
            const timeoutText = new TextDisplayBuilder().setContent(isArabic ? '> ** - انتهت مهلة إنشاء التذكرة**' : '> ** - Ticket creation timed out**');
            await originalInteraction.editReply({ components: [timeoutText], flags: [MessageFlags.IsComponentsV2] });
        }
    });
}

async function showPaymentMenu(interaction, member, type, language, originalInteraction) {
    const isArabic = language === 'arabic';
    const paymentMenu = new StringSelectMenuBuilder().setCustomId('payment_method_select')
        .setPlaceholder(isArabic ? 'اختر طريقة الدفع' : 'Select a payment method')
        .addOptions(
            new StringSelectMenuOptionBuilder().setLabel('PayPal').setValue('paypal').setDescription(isArabic ? 'الدفع عبر PayPal' : 'Pay via PayPal').setEmoji(config.EMOJIS.paypal),
            new StringSelectMenuOptionBuilder().setLabel('Visa').setValue('visa').setDescription(isArabic ? 'الدفع عبر Visa' : 'Pay via Visa').setEmoji(config.EMOJIS.visa),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'فودافون كاش' : 'Vodafone Cash').setValue('vodafone_cash')
                .setDescription(isArabic ? 'الدفع عبر فودافون كاش' : 'Pay via Vodafone Cash').setEmoji(config.EMOJIS.vodafone),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'عملة الكرديت' : 'Credit Coin').setValue('credit_coin')
                .setDescription(isArabic ? 'الدفع بعملة الكرديت' : 'Pay via Credit Coin').setEmoji(config.EMOJIS.credit),
            new StringSelectMenuOptionBuilder().setLabel('MasterCard').setValue('mastercard').setDescription(isArabic ? 'الدفع عبر MasterCard' : 'Pay via MasterCard').setEmoji(config.EMOJIS.mastercard),
            new StringSelectMenuOptionBuilder().setLabel(isArabic ? 'دفع مخصص' : 'Custom Payment').setValue('custom_payment')
                .setDescription(isArabic ? 'حدد طريقة دفع مخصصة' : 'Specify a custom payment method').setEmoji(config.EMOJIS.customPayment)
        );

    const paymentContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(isArabic ? '> ** - من فضلك اختر طريقة الدفع**' : '> ** - Please select a payment method**'))
        .addActionRowComponents(row => row.addComponents(paymentMenu));

    await interaction.update({ components: [paymentContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

    const paymentFilter = i => i.customId === 'payment_method_select' && i.user.id === interaction.user.id;
    const paymentCollector = interaction.channel.createMessageComponentCollector({ filter: paymentFilter, time: 60000 });

    paymentCollector.on('collect', async i => {
        const paymentMethod = i.values[0];
        const paymentDisplay = isArabic ?
            (paymentMethod === 'paypal' ? 'PayPal' : paymentMethod === 'visa' ? 'Visa' : paymentMethod === 'vodafone_cash' ? 'فودافون كاش' :
             paymentMethod === 'credit_coin' ? 'عملة الكرديت' : paymentMethod === 'mastercard' ? 'MasterCard' : 'دفع مخصص') :
            (paymentMethod === 'paypal' ? 'PayPal' : paymentMethod === 'visa' ? 'Visa' : paymentMethod === 'vodafone_cash' ? 'Vodafone Cash' :
             paymentMethod === 'credit_coin' ? 'Credit Coin' : paymentMethod === 'mastercard' ? 'MasterCard' : 'Custom Payment');
        const finalType = isArabic ? `${type} (${paymentDisplay})` : `${type} (${paymentDisplay})`;
        await createTicket(i, member, finalType, language, originalInteraction);
        paymentCollector.stop();
    });

    paymentCollector.on('end', async (collected, reason) => {
        if (reason === 'time' && collected.size === 0) {
            const timeoutText = new TextDisplayBuilder().setContent(isArabic ? '> ** - انتهت مهلة اختيار طريقة الدفع**' : '> ** - Payment method selection timed out**');
            await interaction.update({ components: [timeoutText], flags: [MessageFlags.IsComponentsV2] });
        }
    });
}

async function createTicket(interaction, member, type, language, originalInteraction) {
    const isArabic = language === 'arabic';
    const processingText = new TextDisplayBuilder().setContent(isArabic ? '> ** - جاري معالجة تذكرتك... ' + config.EMOJIS.star + ' **' : '> ** - Processing your ticket... ' + config.EMOJIS.star + ' **');
    await interaction.update({ components: [processingText], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral] });

    let lastNumber = getLastTicketNumber();
    const newTicketNumber = lastNumber + 1;
    saveLastTicketNumber(newTicketNumber);
    const ticketNumberStr = newTicketNumber.toString().padStart(4, '0');
    const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${ticketNumberStr}`,
        type: ChannelType.GuildText,
        parent: config.ticketCategoryId,
        topic: `[${member.id}]`,
        permissionOverwrites: [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: config.supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
            { id: member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
        ]
    });

    const ticketContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(`<@${member.id}>`))
        .addTextDisplayComponents(text => text.setContent(isArabic ? 'الدعم سيكون معك قريبًا' : 'Support will be with you shortly.'))
        .addTextDisplayComponents(text => text.setContent(isArabic ? `> ** - لإغلاق التذكرة اضغط على زر الإغلاق**\n> **المستخدم:** <@${member.id}>\n> **النوع:** ${type}` : `> ** - To close this press the close button**\n> **User:** <@${member.id}>\n> **Type:** ${type}`))
        .addTextDisplayComponents(text => text.setContent(isArabic ? 'تذكرة بدون فوضى' : 'Ticketing without clutter'))
        .addActionRowComponents(row => row.addComponents(new ButtonBuilder().setCustomId('close_ticket').setEmoji(config.EMOJIS.close).setStyle(ButtonStyle.Secondary)));

    await ticketChannel.send({
        components: [ticketContainer],
        flags: [MessageFlags.IsComponentsV2],
        files: [{ attachment: config.IMAGES.ticketImage, name: 'ticket_image.png' }]
    });

    const successText = new TextDisplayBuilder().setContent(isArabic ? `> ** - تم إنشاء تذكرتك: ${ticketChannel}** ${config.EMOJIS.star}` : `> ** - Your ticket has been created: ${ticketChannel}** ${config.EMOJIS.star}`);
    await originalInteraction.editReply({ components: [successText], flags: [MessageFlags.IsComponentsV2] });

    const logChannel = interaction.guild.channels.cache.get(config.logTickets);
    if (logChannel) {
        const logContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
            .addTextDisplayComponents(text => text.setContent(isArabic ? 'تم إنشاء تذكرة جديدة' : 'New Ticket Created'))
            .addTextDisplayComponents(text => text.setContent(`${isArabic ? '**المستخدم:**' : '**User:**'} <@${member.id}>   ${isArabic ? '**القناة:**' : '**Channel:**'} ${ticketChannel}   ${isArabic ? '**النوع:**' : '**Type:**'} ${type}`));
        logChannel.send({ components: [logContainer], flags: [MessageFlags.IsComponentsV2] });
    }
}

// باقي الأزرار
client.buttons.set('close_ticket', { async execute(interaction) {
    const member = interaction.member;
    const confirmContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(`> ${member}, are you sure you want to close this ticket?`))
        .addActionRowComponents(row => row.addComponents(
            new ButtonBuilder().setCustomId('cancel_close_ticket').setLabel('Cancel').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('force_close_ticket').setLabel('Close').setStyle(ButtonStyle.Danger)
        ));

    await interaction.reply({ components: [confirmContainer], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral], content: null, embeds: null, stickers: null, poll: null });

    const filter = i => i.user.id === member.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
        if (i.customId === 'cancel_close_ticket') {
            const cancelText = new TextDisplayBuilder().setContent('> - **Ticket closure canceled.**');
            await i.update({ components: [cancelText], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral], content: null, embeds: null, stickers: null, poll: null });
            collector.stop();
        } else if (i.customId === 'force_close_ticket') {
            const hidingText = new TextDisplayBuilder().setContent('> - **Hiding the ticket...**');
            await i.update({ components: [hidingText], flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral], content: null, embeds: null, stickers: null, poll: null });

            const topic = interaction.channel.topic;
            const ownerId = topic?.match(/\[(\d+)\]/)?.[1];
            await closeTicket(interaction.channel, ownerId, member, interaction.guild);
            collector.stop();
        }
    });
}});

async function closeTicket(channel, ownerId, member, guild) {
    if (ownerId) await channel.permissionOverwrites.edit(ownerId, { ViewChannel: false, SendMessages: false }).catch(console.error);

    const closedByContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent(`Ticket Closed by ${member}`));

    const controlContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
        .addTextDisplayComponents(text => text.setContent('```Support:disable-run'))
        .addActionRowComponents(row => row.addComponents(
            new ButtonBuilder().setCustomId('ticket_transcript').setLabel('Transcript').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ticket_open').setLabel('Open').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ticket_delete').setLabel('Delete').setStyle(ButtonStyle.Secondary)
        ));

    await channel.send({ components: [closedByContainer, controlContainer], flags: [MessageFlags.IsComponentsV2], content: null, embeds: null, stickers: null, poll: null });

    const logChannel = guild.channels.cache.get(config.logTickets);
    if (logChannel) {
        const logContainer = new ContainerBuilder().setAccentColor(hexToDecimal(config.embedColor))
            .addTextDisplayComponents(text => text.setContent('**Ticket Hidden**'))
            .addTextDisplayComponents(text => text.setContent(`**Channel:** ${channel}\n**Hidden From:** ${ownerId ? `<@${ownerId}>` : 'Unknown'}\n**Closed By:** ${member}\n**Timestamp:** <t:${Math.floor(Date.now() / 1000)}:F>`));
        await logChannel.send({ components: [logContainer], flags: [MessageFlags.IsComponentsV2], content: null, embeds: null, stickers: null, poll: null });
    }
}

client.buttons.set('ticket_transcript', { async execute(interaction) {
    const member = interaction.member;
    if (!member.permissions.has(PermissionFlagsBits.Administrator) && !member.roles.cache.has(config.supportRoleId)) {
        return interaction.reply({ content: '> ** - NO Access staff.**', ephemeral: true });
    }
    await interaction.reply({ content: '> ** - Generating transcript...**', ephemeral: true });

    const channel = interaction.channel;
    const guild = interaction.guild;
    const topic = channel.topic;
    let owner = null;
    if (topic) {
        const match = topic.match(/$$ (\d+) $$/);
        if (match) owner = await guild.members.fetch(match[1]).catch(() => null);
    }

    try {
        const transcript = await discordTranscripts.createTranscript(channel, { fileName: `${channel.name}.html`, returnBuffer: false, saveImages: true });
        const logChannel = guild.channels.cache.get(config.logTickets);
        if (logChannel) {
            const embed = new EmbedBuilder().setTitle(`Transcript: ${channel.name}`)
                .setDescription(`Transcript generated by ${interaction.user}${owner ? ` | Owner: <@${owner.id}>` : ''}`).setColor(config.embedColor).setTimestamp();
            await logChannel.send({ content: owner ? `<@${owner.id}>` : '', embeds: [embed], files: [transcript] });
        }
        await interaction.editReply({ content: '** - Transcript sent to logs!**', ephemeral: true });
    } catch (err) {
        console.error(err);
        await interaction.editReply({ content: '** - Failed to generate transcript.**', ephemeral: true });
    }
}});

client.buttons.set('ticket_delete', { async execute(interaction) {
    const member = interaction.member;
    if (!member.roles.cache.has(config.supportRoleId) && !member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '> ** - NO Access staff.**', ephemeral: true });
    }
    await interaction.reply({ content: '> ** - Deleting ticket...**', ephemeral: true });

    const channel = interaction.channel;
    const guild = interaction.guild;
    const topic = channel.topic;
    let owner = null;
    if (topic) {
        const match = topic.match(/$$ (\d+) $$/);
        if (match) owner = await guild.members.fetch(match[1]).catch(() => null);
    }

    try {
        const transcript = await discordTranscripts.createTranscript(channel, { fileName: `${channel.name}.html`, returnBuffer: false, saveImages: true });
        const logChannel = guild.channels.cache.get(config.logTickets);
        if (logChannel) {
            const embed = new EmbedBuilder().setTitle(`Transcript: ${channel.name}`)
                .setDescription(`Ticket deleted by ${member}${owner ? ` | Owner: <@${owner.id}>` : ''}`).setColor(config.embedColor).setTimestamp();
            await logChannel.send({ content: owner ? `<@${owner.id}>` : '', embeds: [embed], files: [transcript] });
        }
        setTimeout(() => channel.delete().catch(console.error), 1000);
    } catch (err) {
        console.error(err);
        await interaction.followUp({ content: '> ** - Failed to create transcript.**', ephemeral: true });
    }
}});

client.buttons.set('ticket_open', { async execute(interaction) {
    const member = interaction.member;
    if (!member.roles.cache.has(config.supportRoleId) && !member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '> ** - NO Access staff.**', ephemeral: true });
    }
    const topic = interaction.channel.topic;
    if (!topic) return interaction.reply({ content: '> ** - Could not find ticket owner in channel topic.**', ephemeral: true });
    const match = topic.match(/$$ (\d+) $$/);
    if (!match) return interaction.reply({ content: '> ** - Invalid channel topic format.**', ephemeral: true });

    const ownerId = match[1];
    try {
        await interaction.channel.permissionOverwrites.edit(ownerId, { ViewChannel: true });
        const reopenEmbed = new EmbedBuilder().setTitle('Ticket Reopened').setDescription(`> **User:** <@${ownerId}>`).setColor(config.embedColor)
            .setFooter({ text: 'Ticketing system' }).setTimestamp();
        await interaction.channel.send({ embeds: [reopenEmbed] });
        await interaction.reply({ content: '> ** - Ticket reopened!**', ephemeral: true });
    } catch (err) {
        console.error(err);
        await interaction.reply({ content: ' Failed to reopen ticket.', ephemeral: true });
    }
}});
client.on('interactionCreate', async interaction => {
    try {
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;
            await command.execute(interaction);
        } else if (interaction.isButton() || interaction.isStringSelectMenu()) {
            const button = client.buttons.get(interaction.customId);
            if (!button) return;
            await button.execute(interaction);
        }
    } catch (error) {
        console.error('Error in interactionCreate:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'حدث خطأ أثناء معالجة الطلب.', ephemeral: true }).catch(() => {});
        } else {
            await interaction.editReply({ content: 'حدث خطأ أثناء معالجة الطلب.' }).catch(() => {});
        }
    }
});
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    if (!config.TOKEN || !config.GUILD_ID) {
        console.error('Error: TOKEN or GUILD_ID is not defined in config.js');
        process.exit(1);
    }
    const rest = new REST().setToken(config.TOKEN);
    try {
        await rest.put(Routes.applicationGuildCommands(client.user.id, config.GUILD_ID), { body: commands });
        console.log('Successfully registered application commands.');
    } catch (error) {
        console.error('Error registering application commands:', error);
        console.error('Application ID:', client.user.id);
        console.error('Guild ID:', config.GUILD_ID);
        console.error('Commands:', commands);
    }
});

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', error => {
    console.error('Uncaught exception:', error);
});

client.login(config.TOKEN);