import requests
from colorama import Fore, Style, init
import json
import os
import ssl
import socket
from urllib.parse import urlparse
import urllib3

# Initialize colorama for colored terminal output
init(autoreset=True)

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ScannerMaster:
    def __init__(self, url):
        self.url = url if url.startswith("http") else "http://" + url
        self.parsed = urlparse(self.url)
        self.domain = self.parsed.netloc
        self.report = {
            "URL": self.url,
            "Status Code": None,
            "Headers": {},
            "SSL Valid": False,
            "SSL Info": {},
            "Error": None
        }

    def print_info(self, msg):
        print(f"{Fore.CYAN}[INFO]{Style.RESET_ALL} {msg}")

    def print_success(self, msg):
        print(f"{Fore.GREEN}[OK]{Style.RESET_ALL} {msg}")

    def print_warning(self, msg):
        print(f"{Fore.YELLOW}[WARNING]{Style.RESET_ALL} {msg}")

    def print_error(self, msg):
        print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} {msg}")

    def check_http(self):
        try:
            response = requests.get(self.url, timeout=10, verify=False)
            self.report["Status Code"] = response.status_code
            self.report["Headers"] = dict(response.headers)
            self.print_success(f"{self.url} | HTTP Status Code: {response.status_code}")
        except Exception as e:
            self.report["Error"] = str(e)
            self.print_error(f"Error accessing {self.url} : {e}")

    def check_ssl(self):
        if self.parsed.scheme != "https":
            self.print_warning(f"{self.url} does not use HTTPS, no SSL to check.")
            return

        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.domain, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.domain) as ssock:
                    cert = ssock.getpeercert()
                    self.report["SSL Valid"] = True
                    self.report["SSL Info"] = {
                        "Issuer": dict(x[0] for x in cert['issuer']),
                        "Subject": dict(x[0] for x in cert['subject']),
                        "Valid From": cert['notBefore'],
                        "Valid To": cert['notAfter']
                    }
                    self.print_success(f"Valid SSL certificate found for {self.domain}")
        except Exception as e:
            self.report["SSL Valid"] = False
            self.report["SSL Info"] = {"Error": str(e)}
            self.print_warning(f"Failed SSL check for {self.domain}: {e}")

    def save_report(self, folder="reports"):
        if not os.path.exists(folder):
            os.makedirs(folder)
        safe_domain = self.domain.replace(":", "_").replace("/", "_")
        file_path = os.path.join(folder, f"{safe_domain}.json")
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(self.report, f, indent=4, ensure_ascii=False)
        self.print_success(f"Report saved at {file_path}")


def scan_links_from_file(filename):
    if not os.path.isfile(filename):
        print(f"{Fore.RED}File not found: {filename}")
        return

    with open(filename, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip()]
    
    if not urls:
        print(f"{Fore.YELLOW}The file contains no URLs.")
        return

    for url in urls:
        print(f"\n{Fore.MAGENTA}Scanning URL: {url}{Style.RESET_ALL}")
        scanner = ScannerMaster(url)
        scanner.check_http()
        scanner.check_ssl()
        scanner.save_report()


def main():
    print(f"{Fore.MAGENTA}ScannerMaster - Professional URL Scanner{Style.RESET_ALL}")
    choice = input("Scan URLs from a file? (y/n): ").strip().lower()

    if choice == 'y':
        file_name = input("Enter the filename (one URL per line): ").strip()
        scan_links_from_file(file_name)
    else:
        url = input("Enter the URL to scan: ").strip()
        if not url:
            print(f"{Fore.RED}No URL entered.")
            return
        scanner = ScannerMaster(url)
        scanner.check_http()
        scanner.check_ssl()
        scanner.save_report()


if __name__ == "__main__":
    main()
