const { REST, Routes } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
require('dotenv').config();

// Validate environment variables
if (!process.env.DISCORD_TOKEN) {
    console.error('ERROR: DISCORD_TOKEN is not set in .env file');
    process.exit(1);
}

if (!process.env.CLIENT_ID) {
    console.error('ERROR: CLIENT_ID is not set in .env file');
    process.exit(1);
}

// Command registration function
async function registerCommands() {
    const commands = [];
    const commandsPath = path.join(__dirname, 'commands');
    
    // Create commands directory if it doesn't exist
    if (!fs.existsSync(commandsPath)) {
        fs.mkdirSync(commandsPath, { recursive: true });
        console.log(`Created commands directory at ${commandsPath}`);
    }
    
    // Get all command files
    try {
        const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
        
        if (commandFiles.length === 0) {
            console.warn('WARNING: No command files found in commands directory.');
        }

        // Load commands from files
        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            const command = require(filePath);
            
            if (!command.data || !command.execute) {
                console.warn(`Command at ${filePath} is missing required "data" or "execute" property.`);
                continue;
            }
            
            commands.push(command.data.toJSON());
            console.log(`Loaded command: ${command.data.name}`);
        }
    } catch (error) {
        console.error('Error loading command files:', error);
        process.exit(1);
    }

    // Create and configure REST client
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

    try {
        console.log(`Started refreshing ${commands.length} application (/) commands.`);

        let data;
        
        // Check if this is guild-specific or global deployment
        if (process.env.GUILD_ID) {
            // Guild commands - faster but only in specific guild
            data = await rest.put(
                Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
                { body: commands },
            );
            console.log(`Successfully registered ${data.length} commands to guild ${process.env.GUILD_ID}`);
        } else {
            // Global commands - can take up to an hour to propagate
            data = await rest.put(
                Routes.applicationCommands(process.env.CLIENT_ID),
                { body: commands },
            );
            console.log(`Successfully registered ${data.length} global commands (may take up to an hour to propagate to all servers)`);
        }
    } catch (error) {
        console.error('Error registering commands:', error);
        process.exit(1);
    }
}

// Run the registration
registerCommands().catch(console.error); 