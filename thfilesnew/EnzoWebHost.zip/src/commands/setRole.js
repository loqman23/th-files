const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const User = require('../models/User');
const { isAdmin } = require('../config/roles');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setrole')
        .setDescription('تعيين رتبة (Free/Premium/Ultimate) لمستخدم معين (للمشرفين فقط)')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('المستخدم المراد تعديل رتبته')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('role')
                .setDescription('الرتبة الجديدة للمستخدم')
                .setRequired(true)
                .addChoices(
                    { name: 'Free (مجاني)', value: 'Free' },
                    { name: 'Premium (بريميوم)', value: 'Premium' },
                    { name: 'Ultimate (أقصى)', value: 'Ultimate' }
                ))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        try {
            // التحقق من صلاحيات المشرف باستخدام الوظيفة الجديدة
            const admin = isAdmin(interaction.member);
            
            if (!admin) {
                return await interaction.reply({
                    content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر. يجب أن تكون مشرفًا.',
                    ephemeral: true
                });
            }
            
            // الحصول على المستخدم المحدد
            const targetUser = interaction.options.getUser('user');
            const newRole = interaction.options.getString('role');
            
            if (!targetUser || !newRole) {
                return await interaction.reply({
                    content: '❌ يرجى تحديد المستخدم والرتبة.',
                    ephemeral: true
                });
            }
            
            // البحث عن المستخدم في قاعدة البيانات أو إنشاء مستخدم جديد
            let user = await User.findOne({ userId: targetUser.id });
            
            if (!user) {
                user = new User({
                    userId: targetUser.id,
                    role: 'Free'
                });
            }
            
            // حفظ الرتبة القديمة للعرض
            const oldRole = user.role;
            
            // تحديث الرتبة وحفظها
            user.role = newRole;
            await user.save();
            
            // إنشاء إمبد للتأكيد
            const embed = new EmbedBuilder()
                .setTitle('✅ تم تغيير الرتبة بنجاح')
                .setColor('#00FF00')
                .setDescription(`تم تغيير رتبة المستخدم ${targetUser} من **${oldRole}** إلى **${newRole}**!`)
                .addFields(
                    {
                        name: 'المستخدم',
                        value: `<@${targetUser.id}>`,
                        inline: true
                    },
                    {
                        name: 'الرتبة الجديدة',
                        value: newRole,
                        inline: true
                    },
                    {
                        name: 'الحد الأقصى للمواقع',
                        value: `${user.maxWebsites}`,
                        inline: true
                    }
                )
                .setTimestamp();
            
            // إرسال تأكيد التغيير
            await interaction.reply({
                embeds: [embed],
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error in setRole command:', error);
            await interaction.reply({ 
                content: 'حدث خطأ أثناء معالجة تغيير الرتبة. الرجاء المحاولة مرة أخرى لاحقاً.',
                ephemeral: true 
            }).catch(() => {});
        }
    }
}; 