const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Website = require('../models/Website');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dashboard')
        .setDescription('Display the web hosting dashboard'),
    
    async execute(interaction) {
        // Use a flag to track if we've responded
        let hasResponded = false;
        
        try {
            // Create a basic embed with placeholder values first
            const initialEmbed = new EmbedBuilder()
                .setTitle('📊 Web Hosting Dashboard')
                .setColor('#0099ff')
                .setDescription('Loading dashboard data...')
                .setFooter({ text: `Requested by ${interaction.user.tag}` })
                .setTimestamp();
                
            // Initial row with loading message
            const initialRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('loading')
                        .setLabel('⏳ Loading...')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                );
            
            // Reply immediately with loading state
            await interaction.reply({ 
                embeds: [initialEmbed],
                components: [initialRow],
                fetchReply: true
            });
            
            hasResponded = true;
            
            // Fetch data in background
            let totalWebsites = 0;
            let totalViews = 0;
            let totalUniqueVisitors = 0;
            let topCountryDisplay = 'None yet';
            let uniqueUserCount = 0;
            
            // Simplified queries with basic error handling
            try {
                totalWebsites = await Website.countDocuments().catch(() => 0);
                
                const viewsResult = await Website.aggregate([
                    { $group: { _id: null, total: { $sum: '$views' } } }
                ]).catch(() => [{ total: 0 }]);
                totalViews = viewsResult[0]?.total || 0;
                
                const visitorsResult = await Website.aggregate([
                    { $group: { _id: null, total: { $sum: '$uniqueVisitors' } } }
                ]).catch(() => [{ total: 0 }]);
                totalUniqueVisitors = visitorsResult[0]?.total || 0;
                
                const usersResult = await Website.aggregate([
                    { $group: { _id: '$ownerId' } },
                    { $count: 'total' }
                ]).catch(() => [{ total: 0 }]);
                uniqueUserCount = usersResult[0]?.total || 0;
                
                try {
                    const topCountryInfo = await Website.getTopCountry();
                    topCountryDisplay = topCountryInfo.country !== 'None' 
                        ? `${topCountryInfo.country} (${topCountryInfo.views} views)` 
                        : 'None yet';
                } catch {
                    // Keep default value
                }
            } catch (error) {
                console.error('Error fetching dashboard stats:', error);
            }
            
            // Create final embed with actual data
            const statsEmbed = new EmbedBuilder()
                .setTitle('📊 Web Hosting Dashboard')
                .setColor('#0099ff')
                .addFields(
                    { name: '🌐 المواقع الكلية', value: totalWebsites.toString(), inline: true },
                    { name: '👁️ المشاهدات الكلية', value: totalViews.toString(), inline: true },
                    { name: '👥 الزوار ', value: totalUniqueVisitors.toString(), inline: true },
                    { name: '🌍 الدولة الأكثر مشاهدة', value: topCountryDisplay, inline: true },
                    { name: '👤 المستخدمين ', value: uniqueUserCount.toString(), inline: true }
                )
                .setFooter({ text: `Last Updated: ${new Date().toLocaleString()}` })
                .setImage('https://cdn.discordapp.com/attachments/1356301003556786186/1360492014713704559/image_2.png?ex=67fdf36d&is=67fca1ed&hm=4392b18381d9337f5fd820da20d6d48f09604918f0eadfad417c3ee97bdaf094&')
                .setTimestamp();
            
            // Add final action buttons
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('add_website')
                        .setLabel('إضافة موقع')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('my_websites')
                        .setLabel('مواقعي')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('settings')
                        .setLabel('الإعدادات')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('upgrade')
                        .setLabel('ترقية الحساب')
                        .setStyle(ButtonStyle.Success)
                );
            
            // Register channel for dashboard updates
            try {
                if (interaction.client.registerDashboardChannel) {
                    interaction.client.registerDashboardChannel(interaction.channelId);
                }
            } catch (error) {
                console.error('Error registering dashboard channel:', error);
            }
            
            // Edit the reply with the complete dashboard
            await interaction.editReply({
                embeds: [statsEmbed],
                components: [row]
            }).catch(err => {
                console.error('Failed to update dashboard:', err);
            });
            
            console.log(`Dashboard displayed for ${interaction.user.tag} in channel ${interaction.channelId}`);
            
        } catch (error) {
            console.error('Error in dashboard command:', error);
            
            // Only try to respond if we haven't already
            if (!hasResponded) {
                try {
                    await interaction.reply({
                        content: 'Sorry, there was an error displaying the dashboard. Please try again.',
                        ephemeral: true
                    }).catch(() => {});
                } catch (replyError) {
                    console.error('Could not send error message:', replyError);
                }
            }
        }
    }
}; 