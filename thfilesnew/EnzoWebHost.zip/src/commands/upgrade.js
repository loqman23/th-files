const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const User = require('../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('upgrade')
        .setDescription('ترقية حسابك للحصول على مزايا بريميوم (Premium) أو أقصى (Ultimate)'),
    
    async execute(interaction) {
        try {
            // البحث عن المستخدم في قاعدة البيانات
            let user = await User.findOne({ userId: interaction.user.id });
            
            if (!user) {
                // إنشاء مستخدم جديد إذا لم يكن موجوداً
                user = new User({
                    userId: interaction.user.id,
                    role: 'Free'
                });
                await user.save();
            }
            
            // إنشاء إمبد (Embed) لعرض معلومات الترقية
            const embed = new EmbedBuilder()
                .setTitle('🌟 ترقية الحساب')
                .setColor('#FFD700')
                .setDescription('اختر خطة الترقية للحصول على مزايا أكثر ومواقع أكثر!')
                .addFields(
                    {
                        name: '🆓 الخطة الحالية',
                        value: `**${user.role}**\n` +
                              `الحد الأقصى للمواقع: **${user.maxWebsites}**\n` +
                              `المواقع الحالية: **${user.websiteCount}**`
                    },
                    {
                        name: '💎 Premium',
                        value: '• الحد الأقصى للمواقع: **50** موقع\n' +
                              '• دعم فني متميز\n' + 
                              '• تحميل ملفات بحجم أكبر\n' +
                              '• السعر: **$10/شهرياً**'
                    },
                    {
                        name: '👑 Ultimate',
                        value: '• الحد الأقصى للمواقع: **100** موقع\n' +
                              '• دعم فني على مدار الساعة\n' + 
                              '• تحميل ملفات بحجم غير محدود\n' +
                              '• مجال فرعي مخصص\n' +
                              '• السعر: **$25/شهرياً**'
                    }
                )
                .setFooter({ text: 'ملاحظة: تواصل مع الإدارة بعد الشراء لتفعيل الترقية' });
            
            // إنشاء أزرار للترقية
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('upgrade_premium')
                        .setLabel('ترقية إلى Premium')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(user.role === 'Premium' || user.role === 'Ultimate'),
                    new ButtonBuilder()
                        .setCustomId('upgrade_ultimate')
                        .setLabel('ترقية إلى Ultimate')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(user.role === 'Ultimate'),
                    new ButtonBuilder()
                        .setURL('https://discord.com/channels/@me')  // رابط للتواصل مع الإدارة (قم بتغييره)
                        .setLabel('تواصل مع الإدارة للشراء')
                        .setStyle(ButtonStyle.Link)
                );
            
            // إرسال الرد
            await interaction.reply({
                embeds: [embed],
                components: [row],
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error in upgrade command:', error);
            await interaction.reply({ 
                content: 'حدث خطأ أثناء معالجة طلب الترقية. الرجاء المحاولة مرة أخرى لاحقاً.',
                ephemeral: true 
            }).catch(() => {});
        }
    }
}; 