const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Website = require('../models/Website');
const { isAdmin } = require('../config/roles');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reset_stats')
        .setDescription('إعادة تعيين إحصائيات جميع المواقع')
        .addStringOption(option =>
            option.setName('domain')
                .setDescription('اسم الموقع (اختياري)')
                .setRequired(false)),
    
    async execute(interaction) {
        try {
            // التحقق من صلاحيات المستخدم
            if (!isAdmin(interaction.member)) {
                return interaction.reply({
                    content: '❌ ليس لديك صلاحية إعادة تعيين الإحصائيات.',
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });
            const domain = interaction.options.getString('domain');
            
            if (domain) {
                // إعادة تعيين إحصائيات موقع محدد
                const website = await Website.findOne({ name: domain });
                if (!website) {
                    return interaction.editReply({
                        content: `❌ لم يتم العثور على الموقع: ${domain}`,
                        ephemeral: true
                    });
                }

                website.views = 0;
                website.uniqueVisitors = 0;
                website.countries = new Map();
                website.topCountry = 'None';
                website.lastUpdated = new Date();
                await website.save();

                const embed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('✅ تم إعادة تعيين الإحصائيات')
                    .setDescription(`تم إعادة تعيين إحصائيات الموقع **${website.name}** بنجاح.`)
                    .setTimestamp();

                return interaction.editReply({
                    embeds: [embed],
                    ephemeral: true
                });
            } else {
                // إعادة تعيين إحصائيات جميع المواقع
                const websites = await Website.find({});
                
                for (const website of websites) {
                    website.views = 0;
                    website.uniqueVisitors = 0;
                    website.countries = new Map();
                    website.topCountry = 'None';
                    website.lastUpdated = new Date();
                    await website.save();
                }

                const embed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('✅ تم إعادة تعيين الإحصائيات')
                    .setDescription(`تم إعادة تعيين إحصائيات **${websites.length}** موقع بنجاح.`)
                    .setTimestamp();

                return interaction.editReply({
                    embeds: [embed],
                    ephemeral: true
                });
            }
        } catch (error) {
            console.error('Error resetting stats:', error);
            return interaction.editReply({
                content: '❌ حدث خطأ أثناء إعادة تعيين الإحصائيات.',
                ephemeral: true
            });
        }
    }
}; 