const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { isAdmin } = require('../config/roles');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('roles')
        .setDescription('عرض آيديات رولات السيرفر (للمشرفين فقط)')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        try {
            // التحقق من صلاحيات المشرف
            const admin = isAdmin(interaction.member);
            
            if (!admin) {
                return await interaction.reply({
                    content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر. يجب أن تكون مشرفًا.',
                    ephemeral: true
                });
            }
            
            // جمع معلومات عن الرولات
            const roles = interaction.guild.roles.cache
                .sort((a, b) => b.position - a.position) // ترتيب الرولات حسب المكانة
                .map(role => {
                    return {
                        name: role.name,
                        id: role.id,
                        color: role.hexColor,
                        position: role.position,
                        memberCount: role.members.size
                    };
                })
                .filter(role => role.name !== '@everyone' && role.position > 0); // استبعاد الرولة الافتراضية
            
            // إنشاء إمبد لعرض الرولات
            const embed = new EmbedBuilder()
                .setTitle('🔍 آيديات رولات السيرفر')
                .setColor('#0099ff')
                .setDescription('يمكنك استخدام هذه الآيديات في ملف `.env` لتحديد صلاحيات المستخدمين:\n```\nADMIN_ROLE_IDS=role1,role2\nPREMIUM_ROLE_IDS=role3,role4\nULTIMATE_ROLE_IDS=role5,role6\n```');
            
            // إضافة أقسام للإمبد
            // رولات المشرفين المحتملة
            const adminRoles = roles.filter(r => 
                r.name.toLowerCase().includes('admin') || 
                r.name.toLowerCase().includes('مشرف') ||
                r.name.toLowerCase().includes('owner') ||
                r.name.toLowerCase().includes('مالك') ||
                r.name.toLowerCase().includes('mod') ||
                r.position > roles.length - 5 // أعلى 5 رولات
            );
            
            if (adminRoles.length > 0) {
                let adminText = '';
                adminRoles.forEach(role => {
                    adminText += `${role.name} = \`${role.id}\` (${role.memberCount} عضو)\n`;
                });
                embed.addFields({ name: '👑 رولات الإدارة المحتملة', value: adminText });
            }
            
            // رولات البريميوم المحتملة
            const premiumRoles = roles.filter(r => 
                r.name.toLowerCase().includes('premium') || 
                r.name.toLowerCase().includes('بريميوم') ||
                r.name.toLowerCase().includes('vip') ||
                r.name.toLowerCase().includes('مميز')
            );
            
            if (premiumRoles.length > 0) {
                let premiumText = '';
                premiumRoles.forEach(role => {
                    premiumText += `${role.name} = \`${role.id}\` (${role.memberCount} عضو)\n`;
                });
                embed.addFields({ name: '💎 رولات البريميوم المحتملة', value: premiumText });
            }
            
            // جميع الرولات الأخرى
            const otherRoles = roles.filter(r => 
                !adminRoles.some(ar => ar.id === r.id) && 
                !premiumRoles.some(pr => pr.id === r.id)
            );
            
            if (otherRoles.length > 0) {
                let otherText = '';
                // عرض أول 15 فقط لتجنب تجاوز حدود ديسكورد
                const displayRoles = otherRoles.slice(0, 15);
                displayRoles.forEach(role => {
                    otherText += `${role.name} = \`${role.id}\` (${role.memberCount} عضو)\n`;
                });
                
                if (otherRoles.length > 15) {
                    otherText += `\n... و ${otherRoles.length - 15} رولات أخرى.`;
                }
                
                embed.addFields({ name: '🔹 رولات أخرى', value: otherText });
            }
            
            // إرسال الإمبد
            await interaction.reply({
                embeds: [embed],
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error in roles command:', error);
            await interaction.reply({ 
                content: 'حدث خطأ أثناء جلب معلومات الرولات. الرجاء المحاولة مرة أخرى لاحقاً.',
                ephemeral: true 
            }).catch(() => {});
        }
    }
}; 