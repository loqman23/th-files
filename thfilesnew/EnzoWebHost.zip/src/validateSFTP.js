require('dotenv').config();
const fs = require('fs');
const path = require('path');
const SFTPHandler = require('./utils/sftpHandler');

console.log('==========================================');
console.log('SFTP CONFIGURATION VALIDATION');
console.log('==========================================');

let isValid = true;

// Check required environment variables
const requiredVars = [
    'SFTP_HOST',
    'SFTP_USER', 
    'SFTP_PASS',
    'SFTP_BASE_PATH'
];

const optionalVars = [
    'SFTP_PORT'
];

// Check required variables
for (const varName of requiredVars) {
    if (!process.env[varName]) {
        console.log(`❌ ${varName}: Missing from .env file`);
        isValid = false;
    } else {
        console.log(`✅ ${varName}: ${process.env[varName]}`);
    }
}

// Check optional variables with defaults
for (const varName of optionalVars) {
    if (!process.env[varName]) {
        console.log(`⚠️ ${varName}: Not set, using default value`);
    } else {
        console.log(`✅ ${varName}: ${process.env[varName]}`);
    }
}

// Log base path and disabled path for confirmation
console.log(`SFTP Base Path: ${process.env.SFTP_BASE_PATH}`);
console.log(`SFTP Disabled Path: ${process.env.SFTP_DISABLED_PATH}`);

// Try to load the handler
let sftpHandler = null;
try {
    sftpHandler = new SFTPHandler();
    console.log('✅ Successfully loaded SFTP handler');
    
    console.log('\nActual configuration used:');
    console.log(`Host: ${process.env.SFTP_HOST}`);
    console.log(`Port: ${process.env.SFTP_PORT || '22'}`);
    console.log(`Username: ${process.env.SFTP_USER}`);
    console.log(`Password: ${'*'.repeat(8)}`);
    console.log(`Base Path: ${process.env.SFTP_BASE_PATH}`);
    console.log(`Disabled Path: ${process.env.SFTP_DISABLED_PATH}`);
} catch (error) {
    console.log(`❌ Failed to load SFTP handler: ${error.message}`);
    isValid = false;
}

// Check temporary directory
const tempDir = path.join(process.cwd(), 'temp');
if (!fs.existsSync(tempDir)) {
    try {
        fs.mkdirSync(tempDir, { recursive: true });
        console.log(`✅ Created temporary directory: ${tempDir}`);
    } catch (error) {
        console.log(`❌ Failed to create temporary directory: ${error.message}`);
        isValid = false;
    }
} else {
    console.log(`✅ Temporary directory exists: ${tempDir}`);
}

// Check if temp directory is writable
try {
    const testFile = path.join(tempDir, 'write_test.txt');
    fs.writeFileSync(testFile, 'Test write');
    fs.unlinkSync(testFile);
    console.log('✅ Temporary directory is writable');
} catch (error) {
    console.log(`❌ Temporary directory is not writable: ${error.message}`);
    isValid = false;
}

console.log('==========================================');
if (isValid) {
    console.log('✅ SFTP configuration looks valid!');
    console.log('Now run the test connection script to verify connectivity:');
    console.log('node src/utils/testSFTPConnection.js');
} else {
    console.log('❌ SFTP configuration has errors!');
    console.log('Please fix the issues above and try again.');
}
console.log('==========================================');

// If running directly, exit with appropriate code
if (require.main === module) {
    process.exit(isValid ? 0 : 1);
}

module.exports = isValid; 