const { Client, GatewayIntentBits, Collection } = require('discord.js');
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ]
});

// Initialize collections
client.commands = new Collection();
client.buttons = new Collection();
client.modals = new Collection();

// Create directories if they don't exist
const dirs = [
    path.join(__dirname, 'commands'),
    path.join(__dirname, 'handlers'),
    path.join(__dirname, 'handlers', 'buttons'),
    path.join(__dirname, 'handlers', 'modals'),
    path.join(__dirname, '..', 'temp')
];

dirs.forEach(dir => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
});

// Load commands
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    client.commands.set(command.data.name, command);
}

// Load button handlers
const buttonsPath = path.join(__dirname, 'handlers', 'buttons');
if (fs.existsSync(buttonsPath)) {
    const buttonFiles = fs.readdirSync(buttonsPath).filter(file => file.endsWith('.js'));
    console.log(`Found ${buttonFiles.length} button handlers: ${buttonFiles.join(', ')}`);
    
    for (const file of buttonFiles) {
        try {
            const filePath = path.join(buttonsPath, file);
            const button = require(filePath);
            
            if (!button.name) {
                console.error(`Button handler ${file} is missing a name property`);
                continue;
            }
            
            console.log(`Registering button handler: ${button.name}`);
            client.buttons.set(button.name, button);
        } catch (error) {
            console.error(`Error loading button handler ${file}:`, error);
        }
    }
}

// Load modal handlers
const modalsPath = path.join(__dirname, 'handlers', 'modals');
if (fs.existsSync(modalsPath)) {
    const modalFiles = fs.readdirSync(modalsPath).filter(file => file.endsWith('.js'));
    for (const file of modalFiles) {
        const filePath = path.join(modalsPath, file);
        const modal = require(filePath);
        client.modals.set(modal.name, modal);
    }
}

// Check if MongoDB connection settings are valid
if (!process.env.MONGODB_URI) {
    console.error('ERROR: MONGODB_URI is not set in the .env file');
    process.exit(1);
}

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => {
        console.error('MongoDB connection error:', err);
        console.error('Exiting application due to database connection failure');
        process.exit(1);
    });

// Event handlers
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}`);

    // Initialize dashboard channels set
    if (!client.dashboardChannels) {
        client.dashboardChannels = new Set();
    }

    // Test SFTP connection
    try {
        const testSFTPConnection = require('./utils/testSFTPConnection');
        const sftpConnected = await testSFTPConnection();
        
        if (!sftpConnected) {
            console.error('⚠️ WARNING: SFTP connection test failed - website uploads may not work!');
            console.error('Please check your SFTP credentials and connection settings.');
        } else {
            console.log('✅ SFTP connection test passed successfully');
        }
    } catch (error) {
        console.error('⚠️ WARNING: SFTP connection test error:', error.message);
        console.error('Website uploads may not work. Bot will continue running.');
    }
    
    // Start the stats update interval
    try {
        const statsUpdater = require('./utils/statsUpdater');
        statsUpdater(client);
        console.log('Stats updater initialized');
    } catch (error) {
        console.error('Stats updater error:', error);
    }

    // Start analytics simulation for demonstration
    try {
        const analyticsTracker = require('./utils/analyticsTracker');
        analyticsTracker.startSimulation(60000); // Update every minute for demo purposes
        console.log('Analytics simulation started');
    } catch (error) {
        console.error('Analytics tracker error:', error);
    }
});

// Handle file uploads in DMs
client.on('messageCreate', async message => {
    if (message.author.bot) return;
    
    // Handle DM file uploads
    if (message.channel.isDMBased() && message.attachments.size > 0) {
        try {
            const fileUploadHandler = require('./handlers/fileUpload');
            await fileUploadHandler(message);
        } catch (error) {
            console.error('File upload handler error:', error);
            message.reply('There was an error processing your file upload. Please try again later.')
                .catch(err => console.error('Error sending error message:', err));
        }
    }
});

client.on('interactionCreate', async interaction => {
    try {
        if (interaction.isCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;

            console.log(`Command executed: ${interaction.commandName} by ${interaction.user.tag}`);
            
            try {
                await command.execute(interaction);
            } catch (error) {
                // Handle common Discord API errors without attempting to respond again
                if (error.code === 10062 || error.code === 40060) { 
                    console.warn(`Discord API Error ${error.code} for command ${interaction.commandName}: ${error.message}`);
                    return;
                }
                
                console.error(`Error executing command ${interaction.commandName}:`, error);
                
                // Only try to respond if we haven't already
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({ 
                            content: 'There was an error executing this command!', 
                            ephemeral: true 
                        }).catch(() => {});
                    } catch {
                        // Ignore any errors from the error handler
                    }
                }
            }
        } else if (interaction.isButton()) {
            console.log(`Button interaction received: ${interaction.customId}`);
            console.log(`Registered button handlers: ${[...client.buttons.keys()].join(', ')}`);
            
            // Get the entire button ID first
            const fullButtonId = interaction.customId;
            
            // Handle special cases for buttons with parameters
            let handlerName = fullButtonId;
            
            // Check for parameters or special button naming
            if (fullButtonId.includes('_')) {
                // Special case for adminToggle_
                if (fullButtonId.startsWith('adminToggle_')) {
                    handlerName = 'adminToggle';
                }
                // Special case for view_website_
                else if (fullButtonId.startsWith('view_website_')) {
                    handlerName = 'viewWebsite';
                }
                // Special case for add_website
                else if (fullButtonId === 'add_website') {
                    handlerName = 'addWebsite';
                }
                // Special case for my_websites
                else if (fullButtonId === 'my_websites') {
                    handlerName = 'myWebsites';
                }
                // Special case for upgrade button
                else if (fullButtonId === 'upgrade') {
                    handlerName = 'upgrade';
                }
                // Special case for upgrade_account
                else if (fullButtonId === 'upgrade_account') {
                    handlerName = 'upgrade_account';
                }
                // Special case for upgrade_premium and upgrade_ultimate
                else if (fullButtonId.startsWith('upgrade_premium') || fullButtonId.startsWith('upgrade_ultimate')) {
                    handlerName = 'upgrade';
                }
                // For other buttons with parameters, use the part before the first underscore
                else {
                    handlerName = fullButtonId.split('_')[0];
                }
            }
            
            console.log(`Looking for button handler: ${handlerName}`);
            
            // Try to find the handler
            const button = client.buttons.get(handlerName);
            
            if (!button) {
                console.warn(`No handler found for button ${interaction.customId}`);
                return;
            }

            console.log(`Button clicked: ${interaction.customId} by ${interaction.user.tag} (Handler: ${button.name})`);
            
            try {
                await button.execute(interaction);
            } catch (error) {
                // Handle common Discord API errors without attempting to respond again
                if (error.code === 10062 || error.code === 40060) { 
                    console.warn(`Discord API Error ${error.code} for button ${handlerName}: ${error.message}`);
                    return;
                }
                
                console.error(`Error handling button ${handlerName}:`, error);
                
                // Only try to respond if we haven't already
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({ 
                            content: 'There was an error handling this button!', 
                            ephemeral: true 
                        }).catch(() => {});
                    } catch {
                        // Ignore any errors from the error handler
                    }
                }
            }
        } else if (interaction.isModalSubmit()) {
            const modal = client.modals.get(interaction.customId);
            if (!modal) return;

            console.log(`Modal submitted: ${interaction.customId} by ${interaction.user.tag}`);
            
            try {
                await modal.execute(interaction);
            } catch (error) {
                // Handle common Discord API errors without attempting to respond again
                if (error.code === 10062 || error.code === 40060) { 
                    console.warn(`Discord API Error ${error.code} for modal ${interaction.customId}: ${error.message}`);
                    return;
                }
                
                console.error(`Error handling modal ${interaction.customId}:`, error);
                
                // Only try to respond if we haven't already
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({ 
                            content: 'There was an error handling this form!', 
                            ephemeral: true 
                        }).catch(() => {});
                    } catch {
                        // Ignore any errors from the error handler
                    }
                }
            }
        }
    } catch (error) {
        console.error('Global interaction error:', error);
    }
});

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', error => {
    console.error('Uncaught exception:', error);
});

client.login(process.env.DISCORD_TOKEN); 