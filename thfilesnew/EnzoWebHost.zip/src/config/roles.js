/**
 * وظائف للتحقق من صلاحيات المستخدمين المختلفة
 */

const User = require('../models/User');

/**
 * التحقق من صلاحيات المشرف
 * @param {GuildMember} member - عضو السيرفر
 * @returns {boolean} إذا كان المستخدم يملك صلاحيات المشرف
 */
function isAdmin(member) {
    try {
        // 1. التحقق من الصلاحيات المباشرة
        if (member.permissions && member.permissions.has('Administrator')) {
            return true;
        }

        // 2. التحقق من الأدوار بالاسم
        const adminRoleByName = member.guild.roles.cache.find(role => 
            role.name.toLowerCase().includes('admin') || 
            role.name.toLowerCase().includes('administrator') || 
            role.name === 'مشرف' || 
            role.name === 'إدارة'
        );
        
        if (adminRoleByName && member.roles.cache.has(adminRoleByName.id)) {
            return true;
        }

        // 3. التحقق من أي دور في قائمة الإعدادات
        const adminRoleIds = process.env.ADMIN_ROLE_IDS ? process.env.ADMIN_ROLE_IDS.split(',') : [];
        for (const roleId of adminRoleIds) {
            if (roleId && roleId.trim() && member.roles.cache.has(roleId.trim())) {
                return true;
            }
        }

        // لا يملك المستخدم أي صلاحيات إدارية
        return false;
    } catch (error) {
        console.error('Error checking admin role:', error);
        // في حالة الخطأ، نعتبر المستخدم ليس مشرفاً
        return false;
    }
}

/**
 * التحقق من صلاحيات المستخدم المميز (Premium)
 * @param {GuildMember} member - عضو السيرفر
 * @returns {boolean} إذا كان المستخدم يملك رتبة مميزة
 */
function isPremium(member) {
    try {
        // التحقق من الأدوار بالاسم
        const premiumRoleByName = member.guild.roles.cache.find(role => 
            role.name.toLowerCase().includes('premium') || 
            role.name === 'مميز'
        );
        
        if (premiumRoleByName && member.roles.cache.has(premiumRoleByName.id)) {
            return true;
        }

        // التحقق من الرولات بالآيدي
        const premiumRoleIds = process.env.PREMIUM_ROLE_IDS ? process.env.PREMIUM_ROLE_IDS.split(',') : [];
        for (const roleId of premiumRoleIds) {
            if (roleId && roleId.trim() && member.roles.cache.has(roleId.trim())) {
                return true;
            }
        }

        // المستخدم ليس مميزاً
        return false;
    } catch (error) {
        console.error('Error checking premium role:', error);
        return false;
    }
}

/**
 * التحقق مما إذا كان المستخدم مالكًا للسيرفر
 * @param {Object} member - كائن عضو الدسكورد
 * @returns {boolean} - هل المستخدم مالك
 */
function isOwner(member) {
    try {
        return member.id === member.guild.ownerId || isAdmin(member);
    } catch (error) {
        console.error('Error checking owner status:', error);
        return false;
    }
}

/**
 * التحقق من صلاحيات المستخدم الأقصى (Ultimate)
 * @param {GuildMember} member - عضو السيرفر
 * @returns {boolean} إذا كان المستخدم يملك رتبة أقصى
 */
function isUltimate(member) {
    try {
        // التحقق من الأدوار بالاسم
        const ultimateRoleByName = member.guild.roles.cache.find(role => 
            role.name.toLowerCase().includes('ultimate') || 
            role.name === 'أقصى'
        );
        
        if (ultimateRoleByName && member.roles.cache.has(ultimateRoleByName.id)) {
            return true;
        }

        // التحقق من الرولات بالآيدي
        const ultimateRoleIds = process.env.ULTIMATE_ROLE_IDS ? process.env.ULTIMATE_ROLE_IDS.split(',') : [];
        for (const roleId of ultimateRoleIds) {
            if (roleId && roleId.trim() && member.roles.cache.has(roleId.trim())) {
                return true;
            }
        }

        // المستخدم ليس في أعلى رتبة
        return false;
    } catch (error) {
        console.error('Error checking ultimate role:', error);
        return false;
    }
}

/**
 * تحديث رتبة المستخدم في قاعدة البيانات بناءً على رولات الدسكورد
 * @param {Object} member - كائن عضو الدسكورد
 * @returns {Promise<void>}
 */
async function updateUserRole(member) {
    try {
        if (!member || !member.roles) return;

        // البحث عن المستخدم في قاعدة البيانات
        let user = await User.findOne({ userId: member.id });
        if (!user) {
            user = new User({
                userId: member.id,
                role: 'Free'
            });
        }

        // التحقق من الرتبة الحالية وتحديثها إذا لزم الأمر
        let newRole = 'Free';
        
        if (isUltimate(member)) {
            newRole = 'Ultimate';
        } else if (isPremium(member)) {
            newRole = 'Premium';
        }

        // تحديث الرتبة فقط إذا تغيرت
        if (user.role !== newRole) {
            user.role = newRole;
            await user.save();
            console.log(`Updated user ${member.id} role from ${user.role} to ${newRole}`);
        }
    } catch (error) {
        console.error('Error updating user role:', error);
    }
}

module.exports = {
    isAdmin,
    isPremium,
    isUltimate,
    isOwner,
    updateUserRole
}; 