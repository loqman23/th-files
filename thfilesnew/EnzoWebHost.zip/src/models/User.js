const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        unique: true
    },
    role: {
        type: String,
        enum: ['Free', 'Premium', 'Ultimate'],
        default: 'Free'
    },
    websiteCount: {
        type: Number,
        default: 0
    },
    maxWebsites: {
        type: Number,
        default: 2 // Default for Free tier
    },
    lastActive: {
        type: Date,
        default: Date.now
    }
});

// Update maxWebsites based on role
userSchema.pre('save', function(next) {
    switch(this.role) {
        case 'Premium':
            this.maxWebsites = 50;
            break;
        case 'Ultimate':
            this.maxWebsites = 100;
            break;
        default:
            this.maxWebsites = 2; // Free tier limit
    }
    next();
});

module.exports = mongoose.model('User', userSchema); 