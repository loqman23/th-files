const mongoose = require('mongoose');

const websiteSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    ownerId: {
        type: String,
        required: true
    },
    path: {
        type: String,
        required: true
    },
    isActive: {
        type: Boolean,
        default: true
    },
    views: {
        type: Number,
        default: 0
    },
    uniqueVisitors: {
        type: Number,
        default: 0
    },
    countries: {
        type: Map,
        of: Number,
        default: new Map()
    },
    topCountry: {
        type: String,
        default: 'None'
    },
    lastUpdated: {
        type: Date,
        default: Date.now
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Method to add a view from a specific country
websiteSchema.methods.addView = async function(country) {
    this.views += 1;
    
    // Update country stats
    if (country) {
        const currentViews = this.countries.get(country) || 0;
        this.countries.set(country, currentViews + 1);
        
        // Update top country
        let maxViews = 0;
        let maxCountry = 'None';
        
        this.countries.forEach((views, countryName) => {
            if (views > maxViews) {
                maxViews = views;
                maxCountry = countryName;
            }
        });
        
        this.topCountry = maxCountry;
    }
    
    this.lastUpdated = new Date();
    return this.save();
};

// Static method to get the top country across all websites
websiteSchema.statics.getTopCountry = async function() {
    try {
        const websites = await this.find();
        
        if (!websites || websites.length === 0) {
            return { country: 'None', views: 0 };
        }
        
        const countryMap = new Map();
        
        websites.forEach(website => {
            if (website.countries && website.countries instanceof Map) {
                website.countries.forEach((views, country) => {
                    if (country && views) {
                        const currentTotal = countryMap.get(country) || 0;
                        countryMap.set(country, currentTotal + views);
                    }
                });
            }
        });
        
        if (countryMap.size === 0) {
            return { country: 'None', views: 0 };
        }
        
        let maxViews = 0;
        let topCountry = 'None';
        
        countryMap.forEach((views, country) => {
            if (views > maxViews) {
                maxViews = views;
                topCountry = country;
            }
        });
        
        return { country: topCountry, views: maxViews };
    } catch (error) {
        console.error('Error in getTopCountry:', error);
        return { country: 'None', views: 0 };
    }
};

module.exports = mongoose.model('Website', websiteSchema); 