const fs = require('fs');
const path = require('path');
const https = require('https');
const Website = require('../models/Website');
const SFTPHandler = require('../utils/sftpHandler');

module.exports = async (message) => {
    try {
        // Check if message is in DM and has attachments
        if (!message.channel.isDMBased() || message.attachments.size === 0) return;

        // Find the user's most recent website that needs files
        const website = await Website.findOne({
            ownerId: message.author.id,
            isActive: true
        }).sort({ createdAt: -1 });

        if (!website) {
            return message.reply('❌ You don\'t have any active websites that need files. Please create a website first using the "Add Website" button.');
        }

        // Check if the attachment is a zip file
        const attachment = message.attachments.first();
        if (!attachment.name.endsWith('.zip')) {
            return message.reply('❌ Please upload a .zip file containing your website files.');
        }

        // Check file size (max 10MB)
        if (attachment.size > 10 * 1024 * 1024) {
            return message.reply('❌ File size exceeds 10MB limit. Please compress your files and try again.');
        }

        // Send acknowledgment message
        await message.reply('📤 Processing your file... This may take a moment.');

        // Create temp directory if it doesn't exist
        const tempDir = path.join(__dirname, '..', '..', 'temp');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        // Download the file directly without using fetch
        try {
            console.log(`Downloading file from URL: ${attachment.url}`);
            console.log(`Attachment details: Name: ${attachment.name}, Size: ${attachment.size} bytes`);
            
            // Download path
            const downloadPath = path.join(tempDir, `${website.name}_${Date.now()}.zip`);
            console.log(`Saving file to: ${downloadPath}`);
            
            // Manual download with https
            await new Promise((resolve, reject) => {
                const file = fs.createWriteStream(downloadPath);
                https.get(attachment.url, (response) => {
                    if (response.statusCode !== 200) {
                        reject(new Error(`Failed to download: ${response.statusCode}`));
                        return;
                    }
                    
                    response.pipe(file);
                    
                    file.on('finish', () => {
                        file.close();
                        console.log(`File downloaded successfully! Size: ${fs.statSync(downloadPath).size} bytes`);
                        resolve();
                    });
                }).on('error', (err) => {
                    fs.unlink(downloadPath, () => {}); // Delete the file if there was an error
                    reject(err);
                });
            });
            
            // Read the file
            const zipBuffer = fs.readFileSync(downloadPath);
            console.log(`Read zip file with size: ${zipBuffer.length} bytes`);
            
            // Upload to SFTP server
            console.log(`Uploading website: ${website.name}`);
            const sftp = new SFTPHandler();
            const success = await sftp.uploadWebsite(zipBuffer, website.name);
            
            // Clean up the downloaded file
            try {
                fs.unlinkSync(downloadPath);
                console.log(`Deleted temporary file: ${downloadPath}`);
            } catch (cleanupError) {
                console.error('Failed to delete temporary file:', cleanupError);
            }
            
            if (success) {
                // Update website record
                website.lastUpdated = new Date();
                await website.save();

                // Send success message
                await message.reply({
                    content: `✅ Website files uploaded successfully!\n\nYour website is now available at: https://${process.env.BASE_DOMAIN}/${website.name}\n\nYou can manage your website using the "My Websites" button in the server.`
                });
            } else {
                await message.reply('❌ Failed to upload website files to the server. Please try again later.');
            }
        } catch (error) {
            console.error('File download/upload error:', error);
            await message.reply('❌ An error occurred while processing your file. Please try again later.');
        }
    } catch (error) {
        console.error('File upload handler error:', error);
        try {
            await message.reply('❌ Something went wrong. Please try again later.');
        } catch (dmError) {
            console.error('Could not send error message to user:', dmError);
        }
    }
}; 