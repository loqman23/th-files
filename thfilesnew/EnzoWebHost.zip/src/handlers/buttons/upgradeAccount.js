const { ButtonInteraction, EmbedBuilder } = require('discord.js');
const { createTicket } = require('../../utils/ticketSystem');

module.exports = {
    name: 'upgrade_account',
    /**
     * معالج زر ترقية الحساب
     * @param {ButtonInteraction} interaction - تفاعل الزر
     */
    async execute(interaction) {
        // استخدام deferReply لمنع أخطاء timeout
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // إنشاء تذكرة جديدة بدون تمرير أي معاملات إضافية
            const ticket = await createTicket(interaction.guild, interaction.member);
            
            // إرسال رسالة التأكيد
            const embed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle('✅ تم إنشاء تذكرة ترقية الحساب')
                .setDescription(`تم إنشاء تذكرة لترقية حسابك.\nيرجى الانتقال إلى: ${ticket.toString()}`)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], ephemeral: true });
            
        } catch (error) {
            console.error('Error in upgrade account handler:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء إنشاء التذكرة. الرجاء المحاولة مرة أخرى أو الاتصال بفريق الدعم.',
                ephemeral: true
            });
        }
    }
}; 