const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Website = require('../../models/Website');
const { isAdmin } = require('../../config/roles');

module.exports = {
    name: 'settings',
    async execute(interaction) {
        try {
            console.log(`Settings button clicked by ${interaction.user.tag}`);
            
            // استخدام deferReply لمنع أخطاء timeout
            await interaction.deferReply({ ephemeral: true });
            
            // التحقق من صلاحيات المستخدم باستخدام الدالة isAdmin
            if (!isAdmin(interaction.member)) {
                // عرض معلومات عن الموقع للمستخدم العادي
                const userWebsites = await Website.find({ ownerId: interaction.user.id })
                    .sort({ createdAt: -1 })
                    .catch(() => []);
                
                if (!userWebsites || userWebsites.length === 0) {
                    await interaction.editReply({
                        content: '🌐 ليس لديك أي مواقع حالياً.\n• يمكنك استخدام زر "إضافة موقع" لإنشاء موقع جديد.\n• لترقية حسابك، استخدم زر "ترقية الحساب".',
                        ephemeral: true
                    });
                    return;
                }
                
                // إنشاء قائمة بمواقع المستخدم وإحصائياتها
                const embed = new EmbedBuilder()
                    .setTitle('🌐 مواقعك')
                    .setColor('#0099ff')
                    .setDescription(`لديك ${userWebsites.length} موقع:`);
                
                userWebsites.forEach(website => {
                    embed.addFields({
                        name: website.name,
                        value: `المشاهدات: ${website.views}\nالحالة: ${website.isActive ? '🟢 نشط' : '🔴 معطل'}\nتاريخ الإنشاء: <t:${Math.floor(website.createdAt.getTime() / 1000)}:R>`
                    });
                });
                
                await interaction.editReply({
                    embeds: [embed],
                    ephemeral: true
                });
                return;
            }

            // Get all websites with error handling
            const websites = await Website.find()
                .sort({ createdAt: -1 })
                .limit(20) // Limit to 20 websites to avoid too many fields
                .catch(err => {
                    console.error('Error fetching websites:', err);
                    return [];
                });

            if (!websites || websites.length === 0) {
                await interaction.editReply({
                    content: 'لا توجد مواقع مستضافة حالياً.',
                    ephemeral: true
                });
                return;
            }

            // Create embed
            const embed = new EmbedBuilder()
                .setTitle('⚙️ إعدادات المشرف')
                .setColor('#0099ff')
                .setDescription('إدارة جميع المواقع المستضافة:');

            // Add website fields (max 25 fields in an embed)
            const displayWebsites = websites.slice(0, 25);
            displayWebsites.forEach(website => {
                try {
                    embed.addFields({
                        name: website.name,
                        value: `صاحب الموقع: <@${website.ownerId}>\nالمشاهدات: ${website.views}\nالحالة: ${website.isActive ? '🟢 نشط' : '🔴 معطل'}\nتاريخ الإنشاء: <t:${Math.floor(website.createdAt.getTime() / 1000)}:R>`
                    });
                } catch (err) {
                    console.error(`Error adding field for website ${website.name}:`, err);
                }
            });

            // Create action rows with buttons (max 5 buttons per row, max 5 rows)
            const rows = [];
            
            // Only show up to 15 websites to avoid button limit
            const actionWebsites = displayWebsites.slice(0, 15);
            
            // Create website buttons (max 5 per row)
            for (let i = 0; i < actionWebsites.length; i += 5) {
                const currentRow = new ActionRowBuilder();
                
                // Add up to 5 buttons to the current row
                const rowWebsites = actionWebsites.slice(i, i + 5);
                rowWebsites.forEach(website => {
                    currentRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId(`adminToggle_${website.name}`)
                            .setLabel(website.isActive ? `🗑️ حذف ${website.name}` : `🟢 تفعيل ${website.name}`)
                            .setStyle(website.isActive ? ButtonStyle.Danger : ButtonStyle.Success)
                    );
                });
                
                rows.push(currentRow);
            }

            // Add management buttons
            const managementRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('adminRefresh')
                        .setLabel('🔄 تحديث')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('backToDashboard')
                        .setLabel('⬅️ العودة للوحة الرئيسية')
                        .setStyle(ButtonStyle.Secondary)
                );

            rows.push(managementRow);

            // Send response
            await interaction.editReply({
                embeds: [embed],
                components: rows,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error in settings button handler:', error);
            await interaction.editReply({
                content: 'حدث خطأ أثناء الوصول للإعدادات. يرجى المحاولة مرة أخرى.',
                ephemeral: true
            }).catch(() => {});
        }
    }
}; 