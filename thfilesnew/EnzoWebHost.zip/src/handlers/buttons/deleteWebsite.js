const { ButtonInteraction, EmbedBuilder } = require('discord.js');
const Website = require('../../models/Website');
const SFTPHandler = require('../../utils/sftpHandler');
const { isAdmin } = require('../../config/roles');

module.exports = {
    name: 'delete_website',
    /**
     * معالج زر حذف الموقع
     * @param {ButtonInteraction} interaction - تفاعل الزر
     */
    async execute(interaction) {
        try {
            // التحقق من صلاحيات المستخدم
            if (!isAdmin(interaction.member)) {
                return interaction.reply({
                    content: '❌ ليس لديك صلاحية حذف المواقع.',
                    ephemeral: true
                });
            }

            // استخراج معرف الموقع من معرف الزر
            const websiteId = interaction.customId.split('_')[2];
            if (!websiteId) {
                return interaction.reply({
                    content: '❌ لم يتم العثور على معرف الموقع.',
                    ephemeral: true
                });
            }

            // البحث عن الموقع في قاعدة البيانات
            const website = await Website.findById(websiteId);
            if (!website) {
                return interaction.reply({
                    content: '❌ لم يتم العثور على الموقع.',
                    ephemeral: true
                });
            }

            // حذف الموقع من السيرفر
            const sftp = new SFTPHandler();
            try {
                await sftp.connect();
                const deleted = await sftp.deleteWebsite(website.domain);
                await sftp.disconnect();
                
                if (!deleted) {
                    return interaction.reply({
                        content: '❌ حدث خطأ أثناء حذف ملفات الموقع.',
                        ephemeral: true
                    });
                }
            } catch (error) {
                console.error('Error deleting website files:', error);
                return interaction.reply({
                    content: '❌ حدث خطأ أثناء حذف ملفات الموقع.',
                    ephemeral: true
                });
            }

            // حذف الموقع من قاعدة البيانات
            await Website.findByIdAndDelete(websiteId);

            // إرسال تأكيد الحذف
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('✅ تم حذف الموقع بنجاح')
                .setDescription(`تم حذف الموقع ${website.domain} بنجاح.`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error in delete website handler:', error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء حذف الموقع.',
                ephemeral: true
            });
        }
    }
}; 