const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Website = require('../../models/Website');

module.exports = {
    name: 'myWebsites',
    async execute(interaction) {
        try {
            console.log(`My Websites button clicked by ${interaction.user.tag}`);
            
            // Get user's websites with error handling
            const websites = await Website.find({ ownerId: interaction.user.id }).catch(err => {
                console.error('Error fetching websites:', err);
                return [];
            });

            if (!websites || websites.length === 0) {
                await interaction.reply({
                    content: '❌ You don\'t have any websites yet. Click the "Add Website" button to create one!',
                    ephemeral: true
                }).catch(() => {});
                return;
            }

            // Create embed
            const embed = new EmbedBuilder()
                .setTitle('🌐 Your Websites')
                .setColor('#0099ff')
                .setDescription('Here are all your hosted websites:');

            // Add website fields
            websites.forEach(website => {
                embed.addFields({
                    name: website.name,
                    value: `Views: ${website.views}\nUnique Visitors: ${website.uniqueVisitors}\nStatus: ${website.isActive ? '🟢 Active' : '🔴 Inactive'}\nURL: https://${process.env.BASE_DOMAIN}/${website.name}`
                });
            });

            // Create buttons for each website (max 5 per row, max 25 total)
            const rows = [];
            
            // Only show up to 15 websites to avoid button limit
            const displayWebsites = websites.slice(0, 15);
            
            // Create website buttons (max 5 per row)
            for (let i = 0; i < displayWebsites.length; i += 5) {
                const currentRow = new ActionRowBuilder();
                
                // Add up to 5 buttons to the current row
                const rowWebsites = displayWebsites.slice(i, i + 5);
                rowWebsites.forEach(website => {
                    currentRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId(`view_website_${website.name}`)
                            .setLabel(website.name)
                            .setStyle(ButtonStyle.Primary)
                    );
                });
                
                rows.push(currentRow);
            }

            // Add management buttons
            const managementRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('refreshWebsites')
                        .setLabel('🔄 Refresh')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('backToDashboard')
                        .setLabel('⬅️ Back to Dashboard')
                        .setStyle(ButtonStyle.Secondary)
                );

            rows.push(managementRow);

            // Send response
            await interaction.reply({
                embeds: [embed],
                components: rows,
                ephemeral: true
            }).catch(err => {
                console.error('Error sending website list:', err);
            });
        } catch (error) {
            console.error('Error in my websites button handler:', error);
            
            try {
                if (!interaction.replied) {
                    await interaction.reply({
                        content: 'There was an error fetching your websites. Please try again.',
                        ephemeral: true
                    }).catch(() => {});
                }
            } catch (replyError) {
                console.error('Error sending error message:', replyError);
            }
        }
    }
}; 