const { ButtonInteraction, EmbedBuilder } = require('discord.js');
const Website = require('../../models/Website');
const SFTPHandler = require('../../utils/sftpHandler');
const { isAdmin } = require('../../config/roles');

module.exports = {
    name: 'adminToggle',
    /**
     * معالج زر تبديل حالة الموقع للمشرفين
     * @param {ButtonInteraction} interaction - تفاعل الزر
     */
    async execute(interaction) {
        try {
            // استخدام deferReply لمنع أخطاء timeout
            await interaction.deferReply({ ephemeral: true });
            
            // التحقق من صلاحيات المستخدم
            if (!isAdmin(interaction.member)) {
                return await interaction.editReply({
                    content: 'ليس لديك صلاحية لتنفيذ هذا الإجراء. هذا الزر مخصص للمشرفين فقط.',
                    ephemeral: true
                });
            }

            // استخراج اسم الموقع من معرف الزر
            const websiteName = interaction.customId.split('_')[1];
            
            if (!websiteName) {
                return await interaction.editReply({
                    content: 'معرف موقع غير صالح.',
                    ephemeral: true
                });
            }

            // البحث عن الموقع في قاعدة البيانات
            const website = await Website.findOne({ name: websiteName }).catch(err => {
                console.error(`Error finding website ${websiteName}:`, err);
                return null;
            });

            if (!website) {
                return await interaction.editReply({
                    content: `لم يتم العثور على الموقع: ${websiteName}`,
                    ephemeral: true
                });
            }

            // تحديث حالة الموقع في قاعدة البيانات
            const newStatus = !website.isActive;
            
            // إعداد معالج SFTP
            const sftp = new SFTPHandler();
            
            try {
                // تنفيذ العملية المناسبة (تفعيل أو حذف) باستخدام SFTP
                await sftp.connect();
                
                if (newStatus) {
                    // تفعيل الموقع
                    await sftp.enableWebsite(website.name);
                    
                    // تحديث قاعدة البيانات
                    website.isActive = true;
                    await website.save();
                    
                    // إنشاء رسالة التأكيد
                    const embed = new EmbedBuilder()
                        .setColor('#00FF00')
                        .setTitle('🟢 تم تفعيل الموقع')
                        .setDescription(`تم تفعيل الموقع **${website.name}** بنجاح.`)
                        .addFields(
                            { name: 'صاحب الموقع', value: `<@${website.ownerId}>`, inline: true },
                            { name: 'الحالة الجديدة', value: '🟢 نشط', inline: true }
                        )
                        .setTimestamp();

                    // إرسال التأكيد
                    await interaction.editReply({
                        embeds: [embed],
                        ephemeral: true
                    });
                } else {
                    // حذف الموقع بدلاً من تعطيله
                    const deleted = await sftp.deleteWebsite(website.name);
                    
                    if (!deleted) {
                        return await interaction.editReply({
                            content: `حدث خطأ أثناء حذف الموقع.`,
                            ephemeral: true
                        });
                    }
                    
                    // حذف الموقع من قاعدة البيانات
                    await Website.findByIdAndDelete(website._id);
                    
                    // إنشاء رسالة التأكيد
                    const embed = new EmbedBuilder()
                        .setColor('#FF0000')
                        .setTitle('✅ تم حذف الموقع')
                        .setDescription(`تم حذف الموقع **${website.name}** بنجاح.`)
                        .addFields(
                            { name: 'صاحب الموقع', value: `<@${website.ownerId}>`, inline: true }
                        )
                        .setTimestamp();

                    // إرسال التأكيد
                    await interaction.editReply({
                        embeds: [embed],
                        ephemeral: true
                    });
                }
                
                await sftp.disconnect();
                
                // محاولة إرسال إشعار لصاحب الموقع
                try {
                    const owner = await interaction.guild.members.fetch(website.ownerId);
                    if (owner) {
                        let notification;
                        
                        if (newStatus) {
                            notification = new EmbedBuilder()
                                .setColor('#00FF00')
                                .setTitle('🟢 تم تفعيل موقعك')
                                .setDescription(`تم تفعيل موقعك **${website.name}** بواسطة المشرف.`)
                                .setTimestamp();
                        } else {
                            notification = new EmbedBuilder()
                                .setColor('#FF0000')
                                .setTitle('❌ تم حذف موقعك')
                                .setDescription(`تم حذف موقعك **${website.name}** بواسطة المشرف.`)
                                .setTimestamp();
                        }
                            
                        await owner.send({ embeds: [notification] }).catch(() => {
                            // تجاهل إذا كان المستخدم لا يسمح بالرسائل الخاصة
                        });
                    }
                } catch (notifyError) {
                    console.error(`Error notifying owner of ${website.name}:`, notifyError);
                }
            } catch (sftpError) {
                console.error(`SFTP error processing website ${website.name}:`, sftpError);
                return await interaction.editReply({
                    content: `حدث خطأ أثناء ${newStatus ? 'تفعيل' : 'حذف'} الموقع. خطأ SFTP: ${sftpError.message}`,
                    ephemeral: true
                });
            }
            
        } catch (error) {
            console.error('Error in adminToggle button handler:', error);
            await interaction.editReply({
                content: 'حدث خطأ أثناء تنفيذ الأمر. يرجى المحاولة مرة أخرى.',
                ephemeral: true
            }).catch(() => {});
        }
    }
}; 