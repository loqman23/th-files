const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Website = require('../../models/Website');

module.exports = {
    name: 'viewWebsite',
    async execute(interaction) {
        try {
            console.log(`View Website button clicked by ${interaction.user.tag}`);
            
            // Extract the website name from the customId
            // Format: view_website_websitename
            const websiteName = interaction.customId.replace('view_website_', '');
            
            if (!websiteName) {
                await interaction.reply({
                    content: '❌ Invalid website name.',
                    ephemeral: true
                }).catch(() => {});
                return;
            }
            
            // Get website info
            const website = await Website.findOne({ name: websiteName }).catch(err => {
                console.error(`Error finding website ${websiteName}:`, err);
                return null;
            });
            
            if (!website) {
                await interaction.reply({
                    content: `❌ Website "${websiteName}" not found.`,
                    ephemeral: true
                }).catch(() => {});
                return;
            }
            
            // Check if user is owner
            const isOwner = website.ownerId === interaction.user.id;
            
            if (!isOwner) {
                await interaction.reply({
                    content: '❌ You can only view your own websites.',
                    ephemeral: true
                }).catch(() => {});
                return;
            }
            
            // Create embed
            const embed = new EmbedBuilder()
                .setTitle(`🌐 ${website.name}`)
                .setColor('#0099ff')
                .setDescription(`Your website is hosted at: https://${process.env.BASE_DOMAIN}/${website.name}`)
                .addFields(
                    { name: 'Status', value: website.isActive ? '🟢 Active' : '🔴 Inactive', inline: true },
                    { name: 'Views', value: `${website.views}`, inline: true },
                    { name: 'Unique Visitors', value: `${website.uniqueVisitors}`, inline: true },
                    { name: 'Top Country', value: website.topCountry || 'None', inline: true },
                    { name: 'Created', value: `<t:${Math.floor(website.createdAt.getTime() / 1000)}:R>`, inline: true },
                    { name: 'Last Updated', value: `<t:${Math.floor(website.lastUpdated.getTime() / 1000)}:R>`, inline: true }
                );
            
            // Create action buttons
            const actionRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('🔄 Update Website')
                        .setCustomId(`update_website_${website.name}`)
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setLabel('🗑️ Delete Website')
                        .setCustomId(`delete_website_${website.name}`)
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setLabel('⬅️ Back to My Websites')
                        .setCustomId('myWebsites')
                        .setStyle(ButtonStyle.Secondary)
                );
                
            // Send response
            await interaction.reply({
                embeds: [embed],
                components: [actionRow],
                ephemeral: true
            }).catch(err => {
                console.error('Error sending website details:', err);
            });
        } catch (error) {
            console.error('Error in view website button handler:', error);
            
            try {
                if (!interaction.replied) {
                    await interaction.reply({
                        content: 'There was an error fetching the website details. Please try again.',
                        ephemeral: true
                    }).catch(() => {});
                }
            } catch (replyError) {
                console.error('Error sending error message:', replyError);
            }
        }
    }
}; 