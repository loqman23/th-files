const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const { updateUserRole } = require('../../config/roles');

module.exports = {
    name: 'addWebsite',
    async execute(interaction) {
        try {
            console.log(`Add Website button clicked by ${interaction.user.tag}`);
            
            // تحديث رتبة المستخدم أولاً
            await updateUserRole(interaction.member);
            
            // Check user's website quota
            const User = require('../../models/User');
            let user = await User.findOne({ userId: interaction.user.id }).catch(() => null);
            
            if (!user) {
                try {
                    user = new User({
                        userId: interaction.user.id,
                        role: 'Free'
                    });
                    await user.save();
                    console.log(`Created new user: ${interaction.user.id}`);
                } catch (error) {
                    console.error('Error creating user:', error);
                    await interaction.reply({
                        content: 'There was an error processing your request. Please try again.',
                        ephemeral: true
                    }).catch(() => {});
                    return;
                }
            }
            
            if (user.websiteCount >= user.maxWebsites) {
                const quotaEmbed = new EmbedBuilder()
                    .setTitle('❌ حد المواقع')
                    .setDescription(`لقد وصلت إلى الحد الأقصى للمواقع (${user.maxWebsites}).\n\nالمواقع الحالية: ${user.websiteCount} موقع\n\nفكر في ترقية حسابك للحصول على المزيد من المواقع!`)
                    .setColor('#FF0000')
                    .setImage('https://i.imgur.com/8Km9tLL.png'); // صورة توضيحية للحد الأقصى

                await interaction.reply({
                    embeds: [quotaEmbed],
                    ephemeral: true
                }).catch(err => {
                    console.error('Error sending quota message:', err);
                });
                return;
            }

            // Create the modal
            const modal = new ModalBuilder()
                .setCustomId('addWebsiteModal')
                .setTitle('Add New Website');

            // Add components to modal
            const websiteNameInput = new TextInputBuilder()
                .setCustomId('website_name')
                .setLabel("Enter a website name")
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('الاسم')
                .setMinLength(3)
                .setMaxLength(30)
                .setRequired(true);

            const firstActionRow = new ActionRowBuilder().addComponents(websiteNameInput);
            modal.addComponents(firstActionRow);

            // Show the modal to the user
            console.log(`Showing add website modal to ${interaction.user.id}`);
            await interaction.showModal(modal).catch(err => {
                console.error('Error showing modal:', err);
                if (!interaction.replied) {
                    interaction.reply({
                        content: 'There was an error displaying the form. Please try again.',
                        ephemeral: true
                    }).catch(() => {});
                }
            });
        } catch (error) {
            console.error('Error in add website button handler:', error);
            try {
                // Try to respond if we haven't already
                if (!interaction.replied) {
                    await interaction.reply({ 
                        content: 'There was an error processing your request. Please try again later.',
                        ephemeral: true 
                    }).catch(() => {});
                }
            } catch (replyError) {
                console.error('Error sending error message:', replyError);
            }
        }
    }
}; 