const { EmbedBuilder } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    name: 'upgrade',
    async execute(interaction) {
        try {
            // دائماً ابدأ بـ deferReply لمنع أخطاء timeout
            await interaction.deferReply({ ephemeral: true });
            
            // الحصول على معلومات المستخدم
            let user = await User.findOne({ userId: interaction.user.id }).catch(() => null);
            if (!user) {
                user = {
                    role: 'Free',
                    maxWebsites: 2,
                    websiteCount: 0
                };
            }
            
            try {
                // إنشاء رسالة خاصة للمستخدم بدلاً من تذكرة
                const embed = new EmbedBuilder()
                    .setColor('#2B65EC')
                    .setTitle('🌟 ترقية الحساب')
                    .setDescription(`مرحباً ${interaction.user},\n\nشكراً لاهتمامك بترقية حسابك. فيما يلي معلومات عن الخطط المتاحة.`)
                    .addFields(
                        {
                            name: '🆓 خطتك الحالية',
                            value: `**${user.role}**\n` +
                                `الحد الأقصى للمواقع: **${user.maxWebsites}**\n` +
                                `المواقع الحالية: **${user.websiteCount || 0}**`
                        },
                        {
                            name: '💎 خطة Premium',
                            value: '• الحد الأقصى للمواقع: **50** موقع\n'
                        },
                        {
                            name: '👑 خطة Ultimate',
                            value: '• الحد الأقصى للمواقع: **100** موقع\n'
                         
                        },
                        {
                            name: '💳 طرق الدفع المتاحة',
                            value: '• كريديت'
                        },
                        {
                            name: '📞 كيفية الترقية',
                            value: 'للترقية، يرجى التواصل مع الإدارة عبر:\n• منشن للإدارة في قناة الدعم\n• أو إرسال رسالة خاصة لمشرف السيرفر'
                        }
                    )
                    .setFooter({ text: 'شكراً لاستخدامك خدمات الاستضافة' })
                    .setTimestamp();
                
                // إرسال رد للمستخدم
                await interaction.editReply({
                    content: '✅ تم إرسال معلومات ترقية الحساب في رسالة خاصة!',
                    ephemeral: true
                });
                
                // إرسال رسالة خاصة للمستخدم
                await interaction.user.send({ embeds: [embed] });
                
            } catch (dmError) {
                console.error('Error sending DM:', dmError);
                
                // إذا فشل إرسال رسالة خاصة (مثلاً: المستخدم مغلق للرسائل الخاصة)
                await interaction.editReply({
                    content: '✅ معلومات ترقية الحساب:\n\n' +
                        `• خطتك الحالية: **${user.role}**\n` +
                        `• لترقية حسابك، يرجى التواصل مع إدارة السيرفر.\n` +
                        `• الحزم المتاحة: Premium ($10/شهرياً) - Ultimate ($25/شهرياً)`,
                    ephemeral: true
                });
            }
            
        } catch (error) {
            console.error('Error in upgrade button handler:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ. يرجى التواصل مع الإدارة للمساعدة.',
                ephemeral: true
            }).catch(() => {});
        }
    }
}; 