const { EmbedBuilder } = require('discord.js');
const Website = require('../../models/Website');
const User = require('../../models/User');
const sftpHandler = require('../../utils/sftpHandler');

module.exports = {
    name: 'addWebsiteModal',
    async execute(interaction) {
        try {
            const websiteName = interaction.fields.getTextInputValue('website_name');
            console.log(`Received website name: ${websiteName}`);
            
            // Validate website name
            if (!/^[a-zA-Z0-9-]+$/.test(websiteName)) {
                console.log(`Invalid website name: ${websiteName}`);
                return interaction.reply({
                    content: '❌ Website name can only contain letters, numbers, and hyphens.',
                    ephemeral: true
                });
            }

            // Check if website name is too short or too long
            if (websiteName.length < 3 || websiteName.length > 30) {
                console.log(`Website name length issue: ${websiteName.length} characters`);
                return interaction.reply({
                    content: '❌ Website name must be between 3 and 30 characters.',
                    ephemeral: true
                });
            }

            // Check if website name is already taken
            const existingWebsite = await Website.findOne({ name: websiteName });
            if (existingWebsite) {
                console.log(`Website name already taken: ${websiteName}`);
                return interaction.reply({
                    content: '❌ This website name is already taken. Please choose another one.',
                    ephemeral: true
                });
            }

            // Get or create user
            let user = await User.findOne({ userId: interaction.user.id });
            if (!user) {
                console.log(`Creating new user record for ID: ${interaction.user.id}`);
                user = await User.create({
                    userId: interaction.user.id,
                    role: 'Free'
                });
            }

            // Check website quota
            if (user.websiteCount >= user.maxWebsites) {
                console.log(`User ${interaction.user.id} has reached quota: ${user.websiteCount}/${user.maxWebsites}`);
                return interaction.reply({
                    content: `❌ You have reached your maximum limit of ${user.maxWebsites} websites. Please delete an existing website or upgrade your plan.`,
                    ephemeral: true
                });
            }

            // Check if this is the user's first website
            const isFirstWebsite = user.websiteCount === 0;
            console.log(`Is first website: ${isFirstWebsite}`);

            // Create website record
            console.log(`Creating website record for: ${websiteName}`);
            const website = await Website.create({
                name: websiteName,
                ownerId: interaction.user.id,
                path: websiteName
            });

            // Update user's website count
            console.log(`Updating website count for user: ${interaction.user.id}`);
            await User.findOneAndUpdate(
                { userId: interaction.user.id },
                { $inc: { websiteCount: 1 } }
            );

            // Send instructions for file upload
            const embed = new EmbedBuilder()
                .setTitle('📤 رفع ملفات موقعك')
                .setDescription(`يرجى إرسال ملف .zip يحتوي على ملفات موقعك (HTML, CSS, JS).\n\nسيكون موقعك متاحًا على: https://${process.env.BASE_DOMAIN}/${websiteName}`)
                .setColor('#0099ff')
                .setImage('https://i.imgur.com/8Km9tLL.png') // صورة توضيحية للرفع
                .addFields(
                    { 
                        name: 'نصائح مهمة', 
                        value: '- يجب أن يحتوي ملف .zip على ملف index.html\n- الحد الأقصى للحجم هو 10MB\n- تأكد من تضمين جميع الملفات الضرورية (الصور، CSS، JS)' 
                    }
                );

            await interaction.reply({
                content: '✅ تم إنشاء الموقع! يرجى التحقق من الرسائل الخاصة للحصول على تعليمات الرفع.',
                ephemeral: true
            });

            // Send DM with instructions
            try {
                const dmChannel = await interaction.user.createDM();
                await dmChannel.send({ embeds: [embed] });
                
                // Send welcome message if this is their first website
                if (isFirstWebsite) {
                    const welcomeEmbed = new EmbedBuilder()
                        .setTitle('🎉 Welcome to Web Hosting!')
                        .setDescription(`Congratulations on creating your first website!\n\nHere are some tips to get started:\n• Upload a .zip file containing an index.html file\n• Make sure all your assets (images, CSS, JS) are included\n• Keep your files organized in folders\n\nNeed help? Feel free to ask in the server!`)
                        .setColor('#00ff99')
                        .setFooter({ text: 'Thank you for using our hosting service!' });
                        
                    await dmChannel.send({ embeds: [welcomeEmbed] });
                }
                
                console.log(`Sent DM instructions to user: ${interaction.user.id}`);
            } catch (error) {
                console.error('Failed to send DM:', error);
                await interaction.followUp({
                    content: '❌ I couldn\'t send you a DM. Please make sure your DMs are open and try again.',
                    ephemeral: true
                });
            }
        } catch (error) {
            console.error('Error in add website modal:', error);
            await interaction.reply({
                content: '❌ There was an error creating your website. Please try again later.',
                ephemeral: true
            }).catch(console.error);
        }
    }
}; 