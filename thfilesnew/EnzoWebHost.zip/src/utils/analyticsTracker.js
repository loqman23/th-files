const Website = require('../models/Website');

/**
 * Analytics Tracker - Simulates website analytics
 * In a real-world implementation, this would be integrated with actual analytics APIs
 * or a tracking script embedded in the hosted websites
 */
class AnalyticsTracker {
    constructor() {
        this.countries = [
            'United States', 'United Kingdom', 'Canada', 'Germany', 
            'France', 'Japan', 'Australia', 'Brazil', 'India', 'Russia'
        ];
    }

    // Start simulation of random traffic
    startSimulation(interval = 300000) { // Default 5 minutes
        console.log('Starting analytics simulation');
        
        // Generate some initial data
        this.generateRandomTraffic();
        
        // Set interval for ongoing simulation
        this.simulationInterval = setInterval(() => {
            this.generateRandomTraffic();
        }, interval);
        
        return this;
    }
    
    // Stop simulation
    stopSimulation() {
        if (this.simulationInterval) {
            clearInterval(this.simulationInterval);
            console.log('Stopped analytics simulation');
        }
    }
    
    // Generate random traffic for websites
    async generateRandomTraffic() {
        try {
            // Get all active websites
            const websites = await Website.find({ isActive: true });
            
            if (websites.length === 0) {
                return;
            }
            
            console.log(`Generating random traffic for ${websites.length} websites`);
            
            // Generate random traffic for each website
            for (const website of websites) {
                // Random number of views (0-5)
                const viewCount = Math.floor(Math.random() * 6);
                
                if (viewCount === 0) continue;
                
                // Random unique visitors (0-3, but never more than views)
                const uniqueVisitors = Math.min(Math.floor(Math.random() * 4), viewCount);
                
                // Update website stats
                website.views += viewCount;
                website.uniqueVisitors += uniqueVisitors;
                
                // Random countries for the views
                for (let i = 0; i < viewCount; i++) {
                    const country = this.getRandomCountry();
                    const currentViews = website.countries.get(country) || 0;
                    website.countries.set(country, currentViews + 1);
                }
                
                // Calculate top country
                let maxViews = 0;
                let topCountry = 'None';
                
                website.countries.forEach((views, country) => {
                    if (views > maxViews) {
                        maxViews = views;
                        topCountry = country;
                    }
                });
                
                website.topCountry = topCountry;
                
                // Save the updated stats
                await website.save();
                
                console.log(`Added ${viewCount} views and ${uniqueVisitors} unique visitors to ${website.name}`);
            }
        } catch (error) {
            console.error('Error generating random traffic:', error);
        }
    }
    
    // Get a random country
    getRandomCountry() {
        const index = Math.floor(Math.random() * this.countries.length);
        return this.countries[index];
    }
    
    // Track a view (would be called by actual tracking endpoint)
    async trackView(websiteName, country) {
        try {
            const website = await Website.findOne({ name: websiteName });
            if (!website || !website.isActive) return false;
            
            await website.addView(country || this.getRandomCountry());
            return true;
        } catch (error) {
            console.error('Error tracking view:', error);
            return false;
        }
    }
}

module.exports = new AnalyticsTracker(); 