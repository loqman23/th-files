const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const Website = require('../models/Website');

module.exports = (client) => {
    // Initialize the dashboard channels set if it doesn't exist
    if (!client.dashboardChannels) {
        client.dashboardChannels = new Set();
    }

    // Function to register a channel for dashboard updates
    client.registerDashboardChannel = (channelId) => {
        client.dashboardChannels.add(channelId);
        console.log(`Registered channel ${channelId} for dashboard updates`);
    };

    const updateStats = async () => {
        try {
            // Default values in case stats can't be fetched
            let totalWebsites = 0;
            let totalViews = 0;
            let totalUniqueVisitors = 0;
            let topCountryDisplay = 'None yet';
            let uniqueUserCount = 0;
            
            // Try to get stats with error handling for each step
            try {
                totalWebsites = await Website.countDocuments().catch(() => 0);
                
                const viewsResult = await Website.aggregate([
                    { $group: { _id: null, total: { $sum: '$views' } } }
                ]).catch(() => [{ total: 0 }]);
                totalViews = viewsResult[0]?.total || 0;
                
                const visitorsResult = await Website.aggregate([
                    { $group: { _id: null, total: { $sum: '$uniqueVisitors' } } }
                ]).catch(() => [{ total: 0 }]);
                totalUniqueVisitors = visitorsResult[0]?.total || 0;
                
                try {
                    const topCountryInfo = await Website.getTopCountry();
                    topCountryDisplay = topCountryInfo.country !== 'None' 
                        ? `${topCountryInfo.country} (${topCountryInfo.views} views)` 
                        : 'None yet';
                } catch (err) {
                    console.warn('Error getting top country:', err.message);
                }
                
                const usersResult = await Website.aggregate([
                    { $group: { _id: '$ownerId' } },
                    { $count: 'total' }
                ]).catch(() => [{ total: 0 }]);
                uniqueUserCount = usersResult[0]?.total || 0;
            } catch (statsError) {
                console.error('Error getting stats for update:', statsError);
                // Continue with default values
            }

            // Get current time for the footer
            const lastUpdated = `Last Updated: ${new Date().toLocaleString()}`;

            // Update stats in all stored dashboard channels
            for (const channelId of client.dashboardChannels) {
                try {
                    // Try to fetch the channel, skip if it can't be found
                    const channel = await client.channels.fetch(channelId).catch(() => null);
                    if (!channel) {
                        console.log(`Channel ${channelId} no longer accessible, skipping update`);
                        continue;
                    }

                    // Check permissions
                    if (!channel.permissionsFor(client.user.id).has([
                        PermissionsBitField.Flags.ViewChannel,
                        PermissionsBitField.Flags.SendMessages,
                        PermissionsBitField.Flags.ReadMessageHistory
                    ])) {
                        console.log(`Insufficient permissions in channel ${channelId}, skipping update`);
                        continue;
                    }

                    // Get recent messages to find dashboard
                    const messages = await channel.messages.fetch({ limit: 10 }).catch(() => null);
                    if (!messages) {
                        console.log(`Could not fetch messages from channel ${channelId}, skipping update`);
                        continue;
                    }

                    // Find the most recent dashboard message from the bot
                    const dashboardMessage = messages.find(msg => 
                        msg.author.id === client.user.id && 
                        msg.embeds.length > 0 &&
                        msg.embeds[0]?.title === '📊 Web Hosting Dashboard'
                    );

                    if (dashboardMessage) {
                        // Get the existing embed
                        const currentEmbed = dashboardMessage.embeds[0];
                        
                        // Create a new embed based on the existing one but with updated values
                        const updatedEmbed = EmbedBuilder.from(currentEmbed)
                            .setTimestamp()
                            .setFooter({ text: lastUpdated });
                        
                        // Update the field values without changing the structure
                        const fields = [
                            { name: currentEmbed.fields[0].name, value: totalWebsites.toString(), inline: currentEmbed.fields[0].inline },
                            { name: currentEmbed.fields[1].name, value: totalViews.toString(), inline: currentEmbed.fields[1].inline },
                            { name: currentEmbed.fields[2].name, value: totalUniqueVisitors.toString(), inline: currentEmbed.fields[2].inline },
                            { name: currentEmbed.fields[3].name, value: topCountryDisplay, inline: currentEmbed.fields[3].inline },
                            { name: currentEmbed.fields[4].name, value: uniqueUserCount.toString(), inline: currentEmbed.fields[4].inline }
                        ];
                        
                        // Clear existing fields and add updated ones
                        updatedEmbed.setFields(fields);
                        
                        // Update the message with the modified embed
                        await dashboardMessage.edit({ 
                            embeds: [updatedEmbed],
                            components: dashboardMessage.components // Keep the existing buttons
                        }).catch(error => {
                            console.warn(`Could not update dashboard in channel ${channelId}:`, error.message);
                        });
                    } else {
                        // If no dashboard exists yet, create a new one with default formatting
                        const statsEmbed = new EmbedBuilder()
                            .setTitle('📊 Web Hosting Dashboard')
                            .setColor('#0099ff')
                            .addFields(
                                { name: '🌐 Total Websites', value: totalWebsites.toString(), inline: true },
                                { name: '👁️ Total Views', value: totalViews.toString(), inline: true },
                                { name: '👥 Unique Visitors', value: totalUniqueVisitors.toString(), inline: true },
                                { name: '🌍 Top Country', value: topCountryDisplay, inline: true },
                                { name: '👤 Unique Users', value: uniqueUserCount.toString(), inline: true }
                            )
                            .setFooter({ text: lastUpdated })
                            .setTimestamp();

                        // Add action buttons
                        const row = {
                            type: 1,
                            components: [
                                {
                                    type: 2,
                                    style: 1,
                                    label: '➕ Add Website',
                                    custom_id: 'add_website'
                                },
                                {
                                    type: 2,
                                    style: 1,
                                    label: '🌐 My Websites',
                                    custom_id: 'my_websites'
                                },
                                {
                                    type: 2,
                                    style: 1,
                                    label: '⚙️ Settings',
                                    custom_id: 'settings'
                                }
                            ]
                        };
                        
                        // Send new dashboard
                        await channel.send({ 
                            embeds: [statsEmbed], 
                            components: [row] 
                        }).catch(error => {
                            console.warn(`Could not send new dashboard to channel ${channelId}:`, error.message);
                        });
                    }
                } catch (channelError) {
                    // Just log the error and continue to the next channel
                    console.error(`Error updating stats in channel ${channelId}:`, channelError.message);
                }
            }
        } catch (error) {
            console.error('Stats Update Error:', error);
        }
    };

    // Update stats at a longer interval (every 2 minutes) to avoid rate limits
    console.log('Stats updater initialized');
    setInterval(updateStats, 120000); // 2 minutes
    
    // Run an initial update after 10 seconds to allow the bot to settle
    setTimeout(updateStats, 10000);
}; 