const { ChannelType, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const User = require('../models/User');

/**
 * إنشاء تذكرة جديدة للترقية
 * @param {Guild} guild - السيرفر
 * @param {GuildMember} member - العضو
 * @returns {Promise<TextChannel>} قناة التذكرة
 */
async function createTicket(guild, member) {
    try {
        console.log('Creating ticket for', member.user.tag);
        
        // التحقق من وجود المتغيرات المطلوبة
        const categoryId = process.env.TICKET_CATEGORY_ID;
        const supportRoleId = process.env.SUPPORT_ROLE_ID;
        
        if (!categoryId) {
            console.error('Missing TICKET_CATEGORY_ID in .env');
            throw new Error('TICKET_CATEGORY_ID غير موجود في ملف .env');
        }
        
        if (!supportRoleId) {
            console.error('Missing SUPPORT_ROLE_ID in .env');
            throw new Error('SUPPORT_ROLE_ID غير موجود في ملف .env');
        }
        
        // التحقق من صلاحيات البوت على السيرفر (منهج أبسط)
        const botMember = guild.members.me;
        
        // البحث عن معلومات المستخدم
        let user = await User.findOne({ userId: member.id }).catch(() => null);
        if (!user) {
            user = new User({
                userId: member.id,
                role: 'Free'
            });
            await user.save().catch(() => {});
        }
        
        // إنشاء اسم للتذكرة
        const ticketNumber = Date.now().toString().slice(-4);
        const ticketName = `ticket-${ticketNumber}`;
        
        // إنشاء القناة بدون محاولة وضعها في تصنيف في البداية
        const channel = await guild.channels.create({
            name: ticketName,
            type: ChannelType.GuildText,
            // لا نضيف parent في البداية
            permissionOverwrites: [
                {
                    id: guild.id, // @everyone
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: member.id, // العضو الذي فتح التذكرة
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
                {
                    id: supportRoleId, // رتبة الدعم
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                },
                {
                    id: botMember.id, // البوت نفسه
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                }
            ]
        });
        
        console.log('Ticket channel created:', channel.name);
        
        // محاولة نقل القناة إلى التصنيف بعد إنشائها
        try {
            await channel.setParent(categoryId, { 
                lockPermissions: false // مهم: لا تقم بإعادة تعيين الصلاحيات
            });
            console.log('Channel moved to category successfully');
        } catch (categoryError) {
            console.error('Error setting category for channel:', categoryError);
            // نستمر حتى لو فشل نقل القناة إلى التصنيف
        }
        
        // إنشاء رسالة الترحيب مع معلومات الترقية
        const embed = new EmbedBuilder()
            .setColor('#2B65EC')
            .setTitle('🎫 تذكرة ترقية الحساب')
            .setDescription(`مرحباً ${member.toString()},\n\nتم إنشاء تذكرة لترقية حسابك. يرجى اختيار الخطة التي ترغب بالترقية إليها وطريقة الدفع المفضلة لديك.`)
            .addFields(
                {
                    name: '🆓 خطتك الحالية',
                    value: `**${user.role}**\n` +
                          `الحد الأقصى للمواقع: **${user.maxWebsites}**\n` +
                          `المواقع الحالية: **${user.websiteCount || 0}**`
                },
                {
                    name: '💎 خطة Premium',
                    value: '• الحد الأقصى للمواقع: **50** موقع\n' +
                          '• دعم فني متميز\n' + 
                          '• تحميل ملفات بحجم أكبر\n' +
                          '• السعر: **$10/شهرياً**'
                },
                {
                    name: '👑 خطة Ultimate',
                    value: '• الحد الأقصى للمواقع: **100** موقع\n' +
                          '• دعم فني على مدار الساعة\n' + 
                          '• تحميل ملفات بحجم غير محدود\n' +
                          '• مجال فرعي مخصص\n' +
                          '• السعر: **$25/شهرياً**'
                },
                {
                    name: '💳 طرق الدفع المتاحة',
                    value: '• PayPal\n• بطاقة الائتمان\n• تحويل بنكي'
                }
            )
            .setFooter({ text: 'يرجى الرد في هذه التذكرة لتحديد اختيارك والمتابعة مع فريق الدعم' })
            .setTimestamp();
        
        // إرسال الرسالة وعمل منشن للعضو وفريق الدعم
        await channel.send({
            content: `${member} <@&${supportRoleId}>`,
            embeds: [embed]
        });
        
        console.log('Ticket created successfully for', member.user.tag);
        return channel;
    } catch (error) {
        console.error('Error creating ticket channel:', error);
        throw error;
    }
}

module.exports = { createTicket }; 