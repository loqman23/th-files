const SftpClient = require('ssh2-sftp-client');
const FtpClient = require('ftp');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const readdir = promisify(fs.readdir);
const stat = promisify(fs.stat);
const AdmZip = require('adm-zip');

/**
 * FTP/SFTP Handler for managing file transfers
 */
class SFTPHandler {
    constructor() {
        this.client = null;
        this.connected = false;
        this.maxRetries = 3;
        this.retryDelay = 2000; // 2 seconds
        
        // Get paths from env or use defaults
        this.basePath = process.env.SFTP_BASE_PATH || '/htdocs';
        this.disabledPath = process.env.SFTP_DISABLED_PATH || '/disabled_sites';
        
        // Determine if we should use FTP or SFTP based on port
        this.useFtp = process.env.SFTP_PORT === '21';
        
        console.log(`${this.useFtp ? 'FTP' : 'SFTP'} Base Path: ${this.basePath}`);
        console.log(`${this.useFtp ? 'FTP' : 'SFTP'} Disabled Path: ${this.disabledPath}`);
    }

    /**
     * Connect to the FTP/SFTP server
     * @param {number} retryCount - Current retry attempt count (internal use)
     * @returns {Promise<boolean>} - Whether the connection was successful
     */
    async connect(retryCount = 0) {
        // Don't try to connect if already connected
        if (this.connected && this.client) {
            return true;
        }

        // Create a new client based on protocol
        if (!this.client) {
            if (this.useFtp) {
                this.client = new FtpClient();
            } else {
                this.client = new SftpClient();
            }
        }

        try {
            const protocol = this.useFtp ? 'FTP' : 'SFTP';
            console.log(`Connecting to ${protocol}: ${process.env.SFTP_HOST}:${process.env.SFTP_PORT} as ${process.env.SFTP_USER}`);
            
            if (this.useFtp) {
                // FTP connection
                await new Promise((resolve, reject) => {
                    this.client.once('ready', () => {
                        console.log('FTP connection established');
                        resolve();
                    });
                    
                    this.client.once('error', (err) => {
                        reject(err);
                    });
                    
                    this.client.connect({
                        host: process.env.SFTP_HOST,
                        port: parseInt(process.env.SFTP_PORT || '21'),
                        user: process.env.SFTP_USER,
                        password: process.env.SFTP_PASS,
                        secure: false, // Use false for regular FTP, true for FTPS
                        connTimeout: 10000, // 10 seconds timeout
                        pasvTimeout: 10000,
                        keepalive: 10000
                    });
                });
            } else {
                // SFTP connection
                await this.client.connect({
                    host: process.env.SFTP_HOST,
                    port: parseInt(process.env.SFTP_PORT || '22'),
                    username: process.env.SFTP_USER,
                    password: process.env.SFTP_PASS,
                    timeout: 10000 // 10 seconds timeout
                });
            }
            
            this.connected = true;
            return true;
        } catch (error) {
            // If we haven't exceeded max retries, try again
            if (retryCount < this.maxRetries) {
                console.warn(`Connection failed (attempt ${retryCount + 1}/${this.maxRetries + 1}). Retrying in ${this.retryDelay / 1000} seconds...`);
                await new Promise(resolve => setTimeout(resolve, this.retryDelay));
                return this.connect(retryCount + 1);
            }
            
            // If we've exhausted all retries, throw the error
            throw error;
        }
    }

    /**
     * Disconnect from the server
     */
    async disconnect() {
        if (this.client && this.connected) {
            try {
                if (this.useFtp) {
                    this.client.end();
                } else {
                    await this.client.end();
                }
            } catch (error) {
                console.error('Error disconnecting:', error);
            } finally {
                this.connected = false;
                this.client = null;
            }
        }
    }

    /**
     * List files in a directory
     * @param {string} remotePath - Remote path to list
     * @returns {Promise<Array>} - List of files and directories
     */
    async listFiles(remotePath) {
        await this.ensureConnected();
        
        if (this.useFtp) {
            return new Promise((resolve, reject) => {
                this.client.list(remotePath, (err, list) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(list);
                });
            });
        } else {
            return this.client.list(remotePath);
        }
    }

    /**
     * Upload a file to the server
     * @param {string} localPath - Local file path
     * @param {string} remotePath - Remote file path
     * @returns {Promise<string>} - The path of the uploaded file
     */
    async uploadFile(localPath, remotePath) {
        await this.ensureConnected();
        
        try {
            // Make sure the remote directory exists
            const remoteDir = path.dirname(remotePath);
            await this.ensureDirectoryExists(remoteDir);
            
            // Upload the file
            if (this.useFtp) {
                await new Promise((resolve, reject) => {
                    this.client.put(fs.createReadStream(localPath), remotePath, (err) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve();
                    });
                });
            } else {
                await this.client.put(localPath, remotePath);
            }
            
            return remotePath;
        } catch (error) {
            console.error(`Error uploading file ${localPath} to ${remotePath}:`, error);
            throw error;
        }
    }

    /**
     * Upload a directory recursively to the SFTP server
     * @param {string} localDir - Local directory path
     * @param {string} remoteDir - Remote directory path
     * @returns {Promise<Array>} - Array of uploaded file paths
     */
    async uploadDirectory(localDir, remoteDir) {
        await this.ensureConnected();
        
        try {
            // Make sure the remote directory exists
            await this.ensureDirectoryExists(remoteDir);
            
            // Get all files in the local directory
            const files = await this.getFilesRecursive(localDir);
            
            // Upload each file
            const uploadPromises = files.map(async (file) => {
                const relativePath = path.relative(localDir, file);
                const remotePath = path.join(remoteDir, relativePath).replace(/\\/g, '/');
                
                // Make sure the remote directory exists
                const remoteFileDir = path.dirname(remotePath);
                await this.ensureDirectoryExists(remoteFileDir);
                
                // Upload the file
                await this.client.put(file, remotePath);
                return remotePath;
            });
            
            return Promise.all(uploadPromises);
        } catch (error) {
            console.error(`Error uploading directory ${localDir} to ${remoteDir}:`, error);
            throw error;
        }
    }

    /**
     * Check if a file or directory exists on the server
     * @param {string} remotePath - Path to check
     * @returns {Promise<boolean>} - Whether the path exists
     */
    async exists(remotePath) {
        await this.ensureConnected();
        
        try {
            if (this.useFtp) {
                // For FTP, try to list the directory or parent directory
                const parentDir = path.dirname(remotePath);
                const basename = path.basename(remotePath);
                
                const listing = await this.client.list(parentDir);
                return listing.some(item => item.name === basename);
            } else {
                // For SFTP, use the built-in exists method
                return await this.client.exists(remotePath);
            }
        } catch (error) {
            // If we get an error (like "no such file"), the path doesn't exist
            console.debug(`Path ${remotePath} does not exist:`, error.message);
            return false;
        }
    }

    /**
     * Ensure a directory exists on the server
     * @param {string} remotePath - Directory path to ensure exists
     * @returns {Promise<boolean>} - Whether the directory exists or was created
     */
    async ensureDirectoryExists(remotePath) {
        await this.ensureConnected();
        
        try {
            // Check if the directory already exists
            let exists;
            
            if (this.useFtp) {
                exists = await this.exists(remotePath);
            } else {
                exists = await this.client.exists(remotePath);
            }
            
            if (exists) {
                return true;
            }
            
            // Create the directory recursively
            console.log(`Creating directory: ${remotePath}`);
            
            if (this.useFtp) {
                await new Promise((resolve, reject) => {
                    this.client.mkdir(remotePath, true, (err) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve();
                    });
                });
            } else {
                await this.client.mkdir(remotePath, true);
            }
            
            return true;
        } catch (error) {
            console.error(`Error ensuring directory exists: ${remotePath}`, error);
            throw error;
        }
    }

    /**
     * Delete a file or directory from the SFTP server
     * @param {string} remotePath - Remote path to delete
     * @param {boolean} recursive - Whether to delete recursively
     */
    async delete(remotePath, recursive = false) {
        await this.ensureConnected();
        
        try {
            const stat = await this.client.stat(remotePath);
            
            if (stat.isDirectory) {
                if (recursive) {
                    // Delete the directory and its contents
                    await this.client.rmdir(remotePath, true);
                } else {
                    // Delete the directory if it's empty
                    await this.client.rmdir(remotePath);
                }
            } else {
                // Delete the file
                await this.client.delete(remotePath);
            }
        } catch (error) {
            console.error(`Error deleting ${remotePath}:`, error);
            throw error;
        }
    }

    /**
     * Ensure we have an active connection
     */
    async ensureConnected() {
        if (!this.connected) {
            await this.connect();
        }
    }

    /**
     * Get all files in a directory recursively
     * @param {string} dir - Local directory to scan
     * @returns {Promise<Array>} - Array of file paths
     */
    async getFilesRecursive(dir) {
        const files = [];
        const entries = await readdir(dir);
        
        for (const entry of entries) {
            const fullPath = path.join(dir, entry);
            const stats = await stat(fullPath);
            
            if (stats.isDirectory()) {
                const subFiles = await this.getFilesRecursive(fullPath);
                files.push(...subFiles);
            } else {
                files.push(fullPath);
            }
        }
        
        return files;
    }

    async uploadWebsite(zipBuffer, websiteName) {
        try {
            console.log(`Starting upload for website: ${websiteName}`);
            
            // Create temporary directory for extraction
            const tempDir = path.join(__dirname, '..', '..', 'temp', websiteName);
            console.log(`Temporary directory: ${tempDir}`);
            
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
                console.log(`Created temporary directory: ${tempDir}`);
            } else {
                console.log(`Using existing temporary directory: ${tempDir}`);
                // Clean it first
                this.cleanupTemp(tempDir);
                fs.mkdirSync(tempDir, { recursive: true });
            }

            // Extract zip file
            console.log(`Extracting zip file of size ${zipBuffer.length} bytes...`);
            const zip = new AdmZip(zipBuffer);
            const entries = zip.getEntries();
            console.log(`Zip contains ${entries.length} entries`);
            
            zip.extractAllTo(tempDir, true);
            console.log(`Extracted to: ${tempDir}`);
            
            // List files in temp dir for verification
            const extractedFiles = fs.readdirSync(tempDir);
            console.log(`Extracted files: ${extractedFiles.join(', ')}`);

            // Connect to SFTP/FTP
            console.log(`Connecting to ${this.useFtp ? 'FTP' : 'SFTP'} server...`);
            const connected = await this.connect();
            if (!connected) {
                throw new Error(`Failed to connect to ${this.useFtp ? 'FTP' : 'SFTP'} server`);
            }

            // Determine absolute paths
            const websitePath = `${this.basePath}/${websiteName}`.replace(/\/\//g, '/');
            console.log(`Target website path: ${websitePath}`);
            
            // Ensure base path exists
            try {
                await this.ensureDirectoryExists(this.basePath);
                console.log(`Ensured base path exists: ${this.basePath}`);
            } catch (mkdirError) {
                console.error(`Error creating base path ${this.basePath}:`, mkdirError);
                // Try to continue anyway
            }
            
            // Check if website directory already exists and clear it
            try {
                const exists = await this.exists(websitePath);
                if (exists) {
                    console.log(`Website directory exists, removing: ${websitePath}`);
                    
                    if (this.useFtp) {
                        // For FTP, we need to recursively delete files first
                        await this.deleteDirectoryRecursive(websitePath);
                    } else {
                        // For SFTP, we can use rmdir with recursive option
                        await this.client.rmdir(websitePath, true);
                    }
                }
            } catch (error) {
                console.log(`Error checking/clearing website directory: ${error.message}`);
                // This is normal for new websites or permission issues
            }
            
            // Create the website directory
            try {
                await this.ensureDirectoryExists(websitePath);
                console.log(`Created website directory: ${websitePath}`);
            } catch (mkdirError) {
                console.error(`Failed to create website directory ${websitePath}:`, mkdirError);
                throw mkdirError;
            }

            // Upload files
            console.log('Starting file upload process...');
            
            // Upload each file individually
            const uploadedFiles = await this.uploadFilesRecursively(tempDir, websitePath);
            console.log(`Successfully uploaded ${uploadedFiles} files`);

            // Clean up temporary files
            this.cleanupTemp(tempDir);

            await this.disconnect();
            return true;
        } catch (error) {
            console.error('Website Upload Error:', error);
            try {
                await this.disconnect();
            } catch (disconnectError) {
                console.error('Error during disconnect after upload failure:', disconnectError);
            }
            return false;
        }
    }
    
    /**
     * Recursively delete a directory on FTP server
     * @param {string} remotePath - Path to delete
     */
    async deleteDirectoryRecursive(remotePath) {
        if (this.useFtp) {
            console.log(`Recursively deleting FTP directory: ${remotePath}`);
            
            // List all files
            const files = await new Promise((resolve, reject) => {
                this.client.list(remotePath, (err, list) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(list || []);
                });
            });
            
            // Delete all files and subdirectories
            for (const file of files) {
                const fullPath = `${remotePath}/${file.name}`;
                
                if (file.type === 'd') {
                    // It's a directory, delete recursively
                    await this.deleteDirectoryRecursive(fullPath);
                } else {
                    // It's a file, delete it
                    await new Promise((resolve, reject) => {
                        this.client.delete(fullPath, (err) => {
                            if (err) {
                                console.error(`Error deleting file ${fullPath}:`, err);
                                // Try to continue with other files
                                resolve();
                                return;
                            }
                            console.log(`Deleted file: ${fullPath}`);
                            resolve();
                        });
                    });
                }
            }
            
            // Now delete the directory itself
            await new Promise((resolve, reject) => {
                this.client.rmdir(remotePath, (err) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    console.log(`Deleted directory: ${remotePath}`);
                    resolve();
                });
            });
        } else {
            // For SFTP, just use the built-in recursive rmdir
            await this.client.rmdir(remotePath, true);
        }
    }

    /**
     * Delete a website from the SFTP server
     * @param {string} websiteName - Name of the website to delete
     * @returns {Promise<boolean>} - Whether the deletion was successful
     */
    async deleteWebsite(websiteName) {
        await this.ensureConnected();
        
        try {
            // Get the full path to the website
            const websitePath = path.join(this.basePath, websiteName).replace(/\\/g, '/');
            
            // Check if the website exists
            let websiteExists = false;
            
            if (this.useFtp) {
                websiteExists = await this.exists(websitePath);
            } else {
                websiteExists = await this.client.exists(websitePath);
            }
            
            if (!websiteExists) {
                console.warn(`Website ${websiteName} does not exist at ${websitePath}`);
                return true; // Already deleted
            }
            
            // Delete the website directory recursively
            if (this.useFtp) {
                // For FTP, use our recursive delete method
                await this.deleteDirectoryRecursive(websitePath);
            } else {
                // For SFTP, use the built-in rmdir method
                await this.client.rmdir(websitePath, true);
            }
            
            console.log(`Deleted website ${websiteName} from ${websitePath}`);
            return true;
        } catch (error) {
            console.error(`Error deleting website ${websiteName}:`, error);
            throw error;
        }
    }

    /**
     * Disable a website by moving it to the disabled directory
     * @param {string} websiteName - Name of the website to disable
     * @returns {Promise<boolean>} - Whether the disabling was successful
     */
    async disableWebsite(websiteName) {
        await this.ensureConnected();
        
        try {
            const sourcePath = `${this.basePath}/${websiteName}`;
            const destPath = `${this.disabledPath}/${websiteName}`;
            
            console.log(`Disabling website: Moving ${sourcePath} to ${destPath}`);
            
            // التحقق من وجود المجلد المصدر
            let sourceExists = false;
            
            if (this.useFtp) {
                sourceExists = await this.exists(sourcePath);
            } else {
                sourceExists = await this.client.exists(sourcePath);
            }
            
            if (!sourceExists) {
                console.error(`Source directory ${sourcePath} does not exist`);
                return false;
            }
            
            // التأكد من أن مجلد المواقع المعطلة موجود
            await this.ensureDirectoryExists(this.disabledPath);
            
            // تنفيذ عملية النقل حسب نوع الاتصال
            if (this.useFtp) {
                // للـ FTP، ننسخ المحتويات ثم نحذف المصدر
                // (FTP لا يدعم النقل المباشر)
                await this.copyDirectory(sourcePath, destPath);
                await this.deleteDirectoryRecursive(sourcePath);
            } else {
                // للـ SFTP، نستخدم mkdir -p لإنشاء المجلد الهدف إذا لم يكن موجوداً
                await this.client.mkdir(path.dirname(destPath), true);
                
                // ثم ننقل المجلد
                await this.client.rename(sourcePath, destPath);
            }
            
            console.log(`Website ${websiteName} disabled successfully`);
            return true;
        } catch (error) {
            console.error(`Error disabling website ${websiteName}:`, error);
            throw error;
        }
    }

    /**
     * Enable a disabled website by moving it back to the main directory
     * @param {string} websiteName - Name of the website to enable
     * @returns {Promise<boolean>} - Whether the enabling was successful
     */
    async enableWebsite(websiteName) {
        await this.ensureConnected();
        
        try {
            const sourcePath = `${this.disabledPath}/${websiteName}`;
            const destPath = `${this.basePath}/${websiteName}`;
            
            console.log(`Enabling website: Moving ${sourcePath} to ${destPath}`);
            
            // التحقق من وجود المجلد المصدر
            let sourceExists = false;
            
            if (this.useFtp) {
                sourceExists = await this.exists(sourcePath);
            } else {
                sourceExists = await this.client.exists(sourcePath);
            }
            
            if (!sourceExists) {
                console.error(`Source directory ${sourcePath} does not exist`);
                return false;
            }
            
            // التأكد من أن المجلد الهدف موجود
            await this.ensureDirectoryExists(path.dirname(destPath));
            
            // تنفيذ عملية النقل حسب نوع الاتصال
            if (this.useFtp) {
                // للـ FTP، ننسخ المحتويات ثم نحذف المصدر
                await this.copyDirectory(sourcePath, destPath);
                await this.deleteDirectoryRecursive(sourcePath);
            } else {
                // للـ SFTP، ننقل المجلد مباشرةً
                await this.client.rename(sourcePath, destPath);
            }
            
            console.log(`Website ${websiteName} enabled successfully`);
            return true;
        } catch (error) {
            console.error(`Error enabling website ${websiteName}:`, error);
            throw error;
        }
    }

    /**
     * Upload a zip file as a website
     * @param {string} zipFilePath - Path to the zip file
     * @param {string} websiteName - Name of the website
     * @returns {Promise<boolean>} - Whether the upload was successful
     */
    async uploadZipAsWebsite(zipFilePath, websiteName) {
        await this.ensureConnected();
        
        try {
            // Create a temp directory to extract the zip
            const tempDir = path.join(process.cwd(), 'temp', websiteName);
            
            // Create the temp directory if it doesn't exist
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            } else {
                // Clean the temp directory
                fs.readdirSync(tempDir).forEach(file => {
                    const filePath = path.join(tempDir, file);
                    if (fs.lstatSync(filePath).isDirectory()) {
                        fs.rmSync(filePath, { recursive: true, force: true });
                    } else {
                        fs.unlinkSync(filePath);
                    }
                });
            }
            
            // Extract the zip file
            console.log(`Extracting ${zipFilePath} to ${tempDir}`);
            const zip = new AdmZip(zipFilePath);
            zip.extractAllTo(tempDir, true);
            
            // Get the remote path
            const remotePath = path.join(this.basePath, websiteName).replace(/\\/g, '/');
            
            // Delete the existing website if it exists
            const exists = await this.client.exists(remotePath);
            if (exists) {
                console.log(`Deleting existing website at ${remotePath}`);
                await this.client.rmdir(remotePath, true);
            }
            
            // Create the website directory
            await this.ensureDirectoryExists(remotePath);
            
            // Upload the website files
            console.log(`Uploading website files to ${remotePath}`);
            await this.uploadDirectory(tempDir, remotePath);
            
            // Clean up the temp directory
            fs.rmSync(tempDir, { recursive: true, force: true });
            
            console.log(`Successfully uploaded website ${websiteName}`);
            return true;
        } catch (error) {
            console.error(`Error uploading zip as website ${websiteName}:`, error);
            throw error;
        }
    }

    cleanupTemp(tempDir) {
        try {
            console.log(`Cleaning up temporary directory: ${tempDir}`);
            if (fs.existsSync(tempDir)) {
                fs.rmSync(tempDir, { recursive: true, force: true });
            }
        } catch (error) {
            console.error('Temp Cleanup Error:', error);
        }
    }

    async uploadFilesRecursively(localDir, remoteDir) {
        try {
            console.log(`Uploading directory recursively from ${localDir} to ${remoteDir}`);
            
            // Ensure remote directory exists
            try {
                if (this.useFtp) {
                    // For FTP, use mkdir method
                    await new Promise((resolve, reject) => {
                        this.client.mkdir(remoteDir, true, (err) => {
                            if (err) {
                                // Ignore "directory already exists" errors
                                if (err.code === 550) {
                                    console.log(`Remote directory already exists: ${remoteDir}`);
                                    resolve();
                                } else {
                                    reject(err);
                                }
                                return;
                            }
                            console.log(`Created remote directory: ${remoteDir}`);
                            resolve();
                        });
                    });
                } else {
                    // For SFTP, use the existing method
                    await this.client.mkdir(remoteDir, true);
                    console.log(`Created remote directory: ${remoteDir}`);
                }
            } catch (error) {
                console.error(`Error creating remote directory ${remoteDir}:`, error);
                throw error;
            }
            
            let fileCount = 0;
            const files = fs.readdirSync(localDir);
            console.log(`Found ${files.length} items in ${localDir}`);
            
            for (const file of files) {
                const localPath = path.join(localDir, file);
                const remotePath = `${remoteDir}/${file}`;
                
                const stats = fs.statSync(localPath);
                
                if (stats.isDirectory()) {
                    // Create remote directory and recurse
                    console.log(`Processing subdirectory: ${file}`);
                    fileCount += await this.uploadFilesRecursively(localPath, remotePath);
                } else {
                    // Upload file
                    console.log(`Uploading file: ${file} (${stats.size} bytes)`);
                    try {
                        if (this.useFtp) {
                            // For FTP, use put method with callback
                            await new Promise((resolve, reject) => {
                                this.client.put(fs.createReadStream(localPath), remotePath, (err) => {
                                    if (err) {
                                        reject(err);
                                        return;
                                    }
                                    console.log(`Successfully uploaded to FTP: ${remotePath}`);
                                    resolve();
                                });
                            });
                        } else {
                            // For SFTP, use the existing method
                            await this.client.put(localPath, remotePath);
                            console.log(`Successfully uploaded to SFTP: ${remotePath}`);
                        }
                        fileCount++;
                    } catch (error) {
                        console.error(`Error uploading file ${localPath} to ${remotePath}:`, error);
                        throw error;
                    }
                }
            }
            
            return fileCount;
        } catch (error) {
            console.error(`Error in uploadFilesRecursively (${localDir} -> ${remoteDir}):`, error);
            throw error;
        }
    }
}

// Export the SFTPHandler class
module.exports = SFTPHandler; 