// Get the handler
const SFTPHandler = require('./sftpHandler');
let handler;

/**
 * Tests the connection using the current environment settings
 * @returns {Promise<boolean>} True if the connection was successful, false otherwise
 */
async function testSFTPConnection() {
    // Create a new handler instance
    handler = new SFTPHandler();
    
    const protocol = handler.useFtp ? 'FTP' : 'SFTP';
    
    console.log('==========================================');
    console.log(`TESTING ${protocol} CONNECTION`);
    console.log('==========================================');
    console.log(`Host: ${process.env.SFTP_HOST}`);
    console.log(`Port: ${process.env.SFTP_PORT || (handler.useFtp ? '21' : '22')}`);
    console.log(`User: ${process.env.SFTP_USER}`);
    console.log(`Base Path: ${process.env.SFTP_BASE_PATH}`);
    console.log('Attempting to connect...');
    
    try {
        await handler.connect();
        console.log(`✅ ${protocol} Connection successful`);
        
        // Try listing files
        try {
            // Test listing the root directory
            const entries = await handler.listFiles('/');
            console.log(`✅ Successfully listed root directory (${entries.length} entries)`);
        } catch (listError) {
            console.error(`⚠️ Could not list root directory: ${listError.message}`);
            console.log('This could be a permission issue. Trying to list the base path...');
            
            try {
                // Try listing the base path instead
                const entries = await handler.listFiles(handler.basePath);
                console.log(`✅ Successfully listed base path directory (${entries.length} entries)`);
            } catch (basePathError) {
                console.error(`❌ Could not list base path: ${basePathError.message}`);
                console.log('This indicates a potential permission or configuration issue.');
                throw new Error('Cannot access required directories');
            }
        }
        
        // If we reach here, the connection was successful
        console.log('==========================================');
        console.log(`✅ ${protocol} connection test PASSED`);
        console.log('==========================================');
        
        // Close the connection
        await handler.disconnect();
        
        return true;
    } catch (error) {
        console.error(`${protocol} Connection Error:`, error);
        console.log('==========================================');
        console.log(`❌ ${protocol} connection test FAILED`);
        console.log('WARNING: Website uploads may not work correctly!');
        console.log('This is a non-fatal error. The application will continue running.');
        console.log(`Please check your ${protocol} credentials and connection settings in the .env file.`);
        console.log('==========================================');
        
        // Make sure we're disconnected
        try {
            await handler.disconnect();
        } catch (disconnectError) {
            // Ignore disconnect errors
        }
        
        return false;
    }
}

// If this file is run directly, test the connection and log the result
if (require.main === module) {
    // Running as standalone script
    require('dotenv').config();
    
    // Display the disabled path (required for some functionality)
    console.log(`Disabled Path: ${process.env.SFTP_DISABLED_PATH}`);
    
    testSFTPConnection()
        .catch(err => {
            console.error('Error running connection test:', err);
            process.exit(1);
        });
}

module.exports = testSFTPConnection; 