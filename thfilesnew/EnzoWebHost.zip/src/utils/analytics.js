const Website = require('../models/Website');
const { getCountryFromIP } = require('./ipLookup');

class Analytics {
    /**
     * تسجيل زيارة جديدة للموقع
     * @param {string} websiteId - معرف الموقع
     * @param {string} ip - عنوان IP للزائر
     * @param {string} userAgent - معلومات المتصفح
     */
    static async recordVisit(websiteId, ip, userAgent) {
        try {
            const website = await Website.findById(websiteId);
            if (!website) return;

            // تحديث إحصائيات المشاهدات
            website.views += 1;

            // التحقق من الزائر الفريد
            const isUnique = !website.visitors.some(v => v.ip === ip);
            if (isUnique) {
                website.uniqueVisitors += 1;
                
                // تحديد الدولة
                const country = await getCountryFromIP(ip);
                if (country) {
                    const countryIndex = website.visitorsByCountry.findIndex(c => c.country === country);
                    if (countryIndex >= 0) {
                        website.visitorsByCountry[countryIndex].count += 1;
                    } else {
                        website.visitorsByCountry.push({ country, count: 1 });
                    }
                }
            }

            // إضافة الزائر إلى سجل الزوار
            website.visitors.push({
                ip,
                userAgent,
                timestamp: new Date()
            });

            // حفظ التحديثات
            await website.save();
        } catch (error) {
            console.error('Error recording visit:', error);
        }
    }

    /**
     * الحصول على إحصائيات الموقع
     * @param {string} websiteId - معرف الموقع
     * @returns {Object} إحصائيات الموقع
     */
    static async getStats(websiteId) {
        try {
            const website = await Website.findById(websiteId);
            if (!website) return null;

            return {
                views: website.views,
                uniqueVisitors: website.uniqueVisitors,
                visitorsByCountry: website.visitorsByCountry,
                lastUpdated: website.updatedAt
            };
        } catch (error) {
            console.error('Error getting stats:', error);
            return null;
        }
    }
}

module.exports = Analytics; 