require("dotenv").config();
const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const mongoose = require("mongoose");


const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

const fs = require("fs");
const path = require("path");

client.interactions = new Map();

// تحميل كل الإنترأكشنات من المجلد
const interactionsPath = path.join(__dirname, "interactions");
fs.readdirSync(interactionsPath).forEach(file => {
    const interactions = require(path.join(interactionsPath, file));
    interactions.forEach(interaction => {
        client.interactions.set(interaction.customId, interaction);
    });
});

// التعامل مع ضغط الأزرار
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;

    const handler = client.interactions.get(interaction.customId);
    if (handler) {
        await handler.execute(interaction);
    }
});


const userSchema = new mongoose.Schema({
  userId: { type: String, unique: true },
  balance: { type: Number, default: 0 },
  lastDaily: { type: Date, default: null },
});
const User = mongoose.model("User", userSchema);


const PREFIX = process.env.PREFIX || "+";

  
async function ensureUser(userId) {
  let user = await User.findOne({ userId });
  if (!user) {
    user = new User({ userId });
    await user.save();
  }
  return user;
}
// help

client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === "help" || command === "مساعدة") {
        const embed = new EmbedBuilder()
            .setTitle("📖 قائمة المساعدة")
            .setDescription("اضغط الزر تحت لاختيار اللغة")
            .setColor("Gold")
            .setFooter({ text: "سيتم حذف هذه الرسالة بعد 5 دقائق ⏳" });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("help_ar")
                .setLabel("🇸🇦 الأوامر بالعربي")
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId("help_en")
                .setLabel("🇬🇧 Commands in English")
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId("help_admin")
                .setLabel("⚙️ أوامر الإدارة")
                .setStyle(ButtonStyle.Danger)
        );

        const helpMsg = await message.reply({ embeds: [embed], components: [row] });

        
        setTimeout(() => {
            helpMsg.delete().catch(() => {});
        }, 300000); 
        //  دقيقة  = 60000 
        //  ثلاث دقايق  = 180000 
        //  خمس دقايق  = 300000 
        //  عشر دقايق = 600000 
        //  خمسة عشر دقيقة = 900000 
    }
});

// اوامر عامة
client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // أمر التوب بالعربي
    if (command === "توب") {
        try {
            const users = await User.find().sort({ balance: -1 }).limit(10);

            if (users.length === 0) {
                return message.reply("🚫 ما فيه أحد عنده رصيد للحين!");
            }

            const embed = new EmbedBuilder()
                .setTitle("🏆 أغنى 10 أعضاء")
                .setColor("Gold")
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `طلب بواسطة ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

            let desc = "";
            for (let i = 0; i < users.length; i++) {
                const user = await message.client.users.fetch(users[i].userId).catch(() => null);
                desc += `**${i + 1}.** ${user ? user.username : "مستخدم غير معروف"} - 💰 ${users[i].balance}\n`;
            }

            embed.setDescription(desc);

            message.reply({ embeds: [embed] });
        } catch (err) {
            console.error(err);
            message.reply("❌ صار خطأ، حاول مرة ثانية.");
        }
    }

    // أمر التوب بالإنجليزي
    if (command === "top") {
        try {
            const users = await User.find().sort({ balance: -1 }).limit(10);

            if (users.length === 0) {
                return message.reply("🚫 No users with balance yet!");
            }

            const embed = new EmbedBuilder()
                .setTitle("🏆 Top 10 Richest Users")
                .setColor("Gold")
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

            let desc = "";
            for (let i = 0; i < users.length; i++) {
                const user = await message.client.users.fetch(users[i].userId).catch(() => null);
                desc += `**${i + 1}.** ${user ? user.username : "Unknown User"} - 💰 ${users[i].balance}\n`;
            }

            embed.setDescription(desc);

            message.reply({ embeds: [embed] });
        } catch (err) {
            console.error(err);
            message.reply("❌ Something went wrong, try again later.");
        }
    }
});




client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = args.shift().toLowerCase();

  if (cmd === "رصيدي" || cmd === "bal") {
    const target = message.mentions.users.first() || message.author;
    const user = await ensureUser(target.id);

    const embed = new EmbedBuilder()
      .setColor("Gold")
      .setTitle(`💰 رصيد ${target.username}`)
      .setDescription(`رصيدك الحالي هو: **${user.balance}** عملة`)
      .setThumbnail(target.displayAvatarURL())
      .setFooter({ text: "by 7d.5" })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }

  else if (cmd === "daily" || cmd === "يومية") {
    const user = await ensureUser(message.author.id);
    const now = new Date();
    const DAY = 24 * 60 * 60 * 1000;

    if (user.lastDaily && now - user.lastDaily < DAY) {
      const left = DAY - (now - user.lastDaily);
      const hours = Math.floor(left / 3600000);
      const minutes = Math.floor((left % 3600000) / 60000);
      return message.reply(`⌛ لازم تنتظر ${hours} ساعة و ${minutes} دقيقة قبل ما تاخذ المكافأة اليومية مرة ثانية.`);
    }

    const reward = Math.floor(Math.random() * (2000 - 500 + 1)) + 500;
    user.balance += reward;
    user.lastDaily = now;
    await user.save();

    const embed = new EmbedBuilder()
      .setColor("Green")
      .setTitle("🎁 المكافأة اليومية")
      .setDescription(`مبروك! استلمت **${reward}** عملة 🎉\nرصيدك الجديد: **${user.balance}**`)
      .setThumbnail(message.author.displayAvatarURL())
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
});

client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // أمر التحويل
    if (command === "تحويل" || command === "transfer") {
        const target = message.mentions.users.first();
        const amount = parseInt(args[1]);

        if (!target) {
            return message.reply("❌ منشن الشخص اللي تبي تحول له.");
        }

        if (target.id === message.author.id) {
            return message.reply("❌ ما تقدر تحول لنفسك.");
        }

        if (isNaN(amount) || amount <= 0) {
            return message.reply("❌ اكتب مبلغ صحيح.");
        }

        
        let sender = await User.findOne({ userId: message.author.id });
        if (!sender || sender.balance < amount) {
            return message.reply("❌ ما عندك رصيد كافي.");
        }

        
        let receiver = await User.findOne({ userId: target.id });
        if (!receiver) {
            receiver = new User({ userId: target.id, balance: 0 });
        }

        
        sender.balance -= amount;
        receiver.balance += amount;

        await sender.save();
        await receiver.save();

        return message.reply(`✅ تم تحويل **${amount}** رصيد إلى ${target.username}.`);
    }
});
// الالعاب
client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === "coinflip" || command === "قرعة") {
        const bet = parseInt(args[0]);
        const choice = args[1]?.toLowerCase(); // heads or tails

        if (isNaN(bet) || bet <= 0) {
            return message.reply("❌ اكتب مبلغ صحيح للرهان.");
        }

        if (!choice || !["heads", "tails", "وجه", "كتابة"].includes(choice)) {
            return message.reply("🪙 اختر: `heads / tails` أو `وجه / كتابة`.");
        }

        const user = await User.findOne({ userId: message.author.id });
        if (!user || user.balance < bet) {
            return message.reply("💸 رصيدك غير كافي للرهان.");
        }

        // اختيار عشوائي
        const outcomes = ["heads", "tails"];
        const result = outcomes[Math.floor(Math.random() * outcomes.length)];

        let resultMsg = `🪙 العملة طلعت: **${result === "heads" ? "وجه" : "كتابة"}**\n\n`;
        let embedColor = "Red";
        let thumbnail = "https://i.imgur.com/7r3zCqc.png"; // خسارة

        if (
            (choice === "heads" && result === "heads") ||
            (choice === "tails" && result === "tails") ||
            (choice === "وجه" && result === "heads") ||
            (choice === "كتابة" && result === "tails")
        ) {
            const winAmount = bet * 2;
            user.balance += winAmount;
            resultMsg += `🏆 ربحت **${winAmount}** 💰`;
            embedColor = "Green";
            thumbnail = "https://i.imgur.com/2pOZ9zC.png"; // فوز
        } else {
            user.balance -= bet;
            resultMsg += `💀 خسرت **${bet}** 💸`;
        }

        await user.save();

        const embed = new EmbedBuilder()
            .setTitle("🪙 لعبة القرعة | Coinflip")
            .setDescription(resultMsg + `\n\n💳 رصيدك الآن: **${user.balance}**`)
            .setColor(embedColor)
            .setThumbnail(thumbnail)
            .setFooter({ text: message.author.username, iconURL: message.author.displayAvatarURL() });

        return message.reply({ embeds: [embed] });
    }
});



client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return; 

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // 🎰 أمر المقامرة
    if (command === "مقامرة" || command === "gamble") {
        const amount = parseInt(args[0]);

        if (!amount || isNaN(amount) || amount <= 0) {
            return message.reply("❌ اكتب مبلغ صحيح للمقامرة.");
        }

        let user = await User.findOne({ userId: message.author.id });
        if (!user || user.balance < amount) {
            return message.reply("❌ ما عندك رصيد كافي.");
        }

        // احتمالات المقامرة
        const roll = Math.random();
        let multiplier = 0;

        if (roll < 0.55) {
            multiplier = 0; // خسارة
        } else if (roll < 0.80) {
            multiplier = 2; // ×2
        } else if (roll < 0.92) {
            multiplier = 3; // ×3
        } else if (roll < 0.98) {
            multiplier = 5; // ×5
        } else {
            multiplier = 10; // ×10
        }

        // الخسارة
        if (multiplier === 0) {
            user.balance -= amount;
            await user.save();

            const embed = new EmbedBuilder()
                .setTitle("💀 خسرت المقامرة!")
                .setDescription(`رهنت **${amount}** وخسرتها كلها...\n💸 رصيدك الآن: **${user.balance}**`)
                .setColor("Red")
                .setThumbnail("https://cdn-icons-png.flaticon.com/512/495/495733.png") // غير الصورة الى اي شي تبيه
                .setFooter({ text: message.author.username, iconURL: message.author.displayAvatarURL() });

            return message.reply({ embeds: [embed] });
        }

        // الربح
        const winnings = amount * multiplier;
        user.balance += winnings;
        await user.save();

        const embed = new EmbedBuilder()
            .setTitle("🎉 فوز كبير!")
            .setDescription(
                `رهنت **${amount}** وربحت ×${multiplier} 🔥\n` +
                `💰 مكسبك: **${winnings}**\n` +
                `💸 رصيدك الآن: **${user.balance}**`
            )
            .setColor("Green")
            .setThumbnail("https://cdn-icons-png.flaticon.com/512/477/477406.png") // غير الصورة الى اي شي تبيه
            .setFooter({ text: message.author.username, iconURL: message.author.displayAvatarURL() });

        return message.reply({ embeds: [embed] });
    }
});

client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === "slots" || command === "سلوت") {
        const bet = parseInt(args[0]);

        if (isNaN(bet) || bet <= 0) {
            return message.reply("❌ اكتب مبلغ صحيح للعب.");
        }

        const user = await User.findOne({ userId: message.author.id });
        if (!user || user.balance < bet) {
            return message.reply("💸 ما عندك رصيد كافي.");
        }

        const symbols = ["🍎", "🍒", "🍋", "🍉", "⭐", "💎"];

        // اختيار 3 رموز عشوائية
        const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
        const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
        const slot3 = symbols[Math.floor(Math.random() * symbols.length)];

        let resultMsg = `🎰 | ${slot1} | ${slot2} | ${slot3} | 🎰\n\n`;

        if (slot1 === slot2 && slot2 === slot3) {
            const winAmount = bet * 3;
            user.balance += winAmount;
            resultMsg += `🏆 فزت بالجائزة الكبرى! ربحت **${winAmount}** 💰`;
        } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
            const winAmount = bet * 2;
            user.balance += winAmount;
            resultMsg += `✨ حظ حلو! ربحت **${winAmount}** 💰`;
        } else {
            user.balance -= bet;
            resultMsg += `💀 خسرت ${bet} من رصيدك.`;
        }

        await user.save();

        const embed = new EmbedBuilder()
            .setTitle("🎰 لعبة السلوت")
            .setDescription(resultMsg + `\n\n💳 رصيدك الآن: **${user.balance}**`)
            .setColor("Purple")
            .setThumbnail("https://cdn-icons-png.flaticon.com/512/1041/1041883.png")
            .setFooter({ text: `${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        return message.reply({ embeds: [embed] });
    }
});




// اوامر الادارة



client.on("messageCreate", async (message) => {
    if (message.author.bot) return;  
    if (!message.content.startsWith(PREFIX)) return; 

    const args = message.content.slice(1).trim().split(/ +/);
    const cmd = args[0].toLowerCase();

    
    const hasAdminRole = message.member.roles.cache.has(process.env.ADMIN_ROLE);
    if (!hasAdminRole && (cmd === "اضافة" || cmd === "add" || cmd === "ازالة" || cmd === "remove" || cmd === "تصفير" || cmd === "reset")) {
        return message.reply("❌ ما عندك صلاحية تستخدم أوامر الإدارة.");
    }

    
    if (cmd === "اضافة" || cmd === "add") {
        const target = message.mentions.users.first();
        const amount = parseInt(args[1]);

        if (!target || isNaN(amount)) {
            return message.reply("📌 الاستخدام: +اضافة @مستخدم 100");
        }

        const user = await ensureUser(target.id);
        user.balance += amount;
        await user.save();

        return message.channel.send(`✅ تمت إضافة ${amount} لرصيد ${target.username}`);
    }

    
    if (cmd === "ازالة" || cmd === "remove") {
        const target = message.mentions.users.first();
        const amount = parseInt(args[1]);

        if (!target || isNaN(amount)) {
            return message.reply("📌 الاستخدام: +ازالة @مستخدم 100");
        }

        const user = await ensureUser(target.id);
        user.balance = Math.max(0, user.balance - amount);
        await user.save();

        return message.channel.send(`✅ تم خصم ${amount} من رصيد ${target.username}`);
    }

     
    if (cmd === "تصفير" || cmd === "reset") {
        const target = message.mentions.users.first();
        if (!target) {
            return message.reply("📌 الاستخدام: +تصفير @مستخدم");
        }

        const user = await ensureUser(target.id);
        user.balance = 0;
        await user.save();

        return message.channel.send(`✅ تم تصفير رصيد ${target.username}`);
    }
});




client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);

  client.user.setPresence({
    activities: [
      {
        name: "programmed by 7d.5 , اكتب +مساعدة لعرض الاوامر , type +help to show all the commands", 
        type: 3, // 0 = Playing, 2 = Listening, 3 = Watching, 5 = Competing
      },
    ],
    status: "dnd", // online | idle | dnd | invisible
  });
});


mongoose.connect(process.env.MONGO_URI).then(() => {
  console.log("📦 MongoDB connected");
  client.login(process.env.DISCORD_TOKEN);
});
