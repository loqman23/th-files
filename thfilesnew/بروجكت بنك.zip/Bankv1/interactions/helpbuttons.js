const { EmbedBuilder } = require("discord.js");

module.exports = [
    {
        customId: "help_ar",
        async execute(interaction) {
            const embed = new EmbedBuilder()
                .setTitle("📖 الأوامر (عربي)")
                .setDescription(
                    "`+رصيدي` - يطلع لك رصيدك\n" +
                "`+يومية` - تاخذ مكافأة يومية\n" +
             "`+تحويل` - تحويل فلوس لشخص ثاني\n" +
                    "`+مقامرة` - تقامر برصيدك\n" +
                "`+سلوت` - تلعب لعبة السلوت\n" +
        "`+قرعة` - لعبة اقلب القرش (وجه أو كتابة)\n" +
          "`+توب` - يطلع أغنى 10 أشخاص بالسيرفر"
                )
                .setColor("Green");

            await interaction.reply({ embeds: [embed], ephemeral: true });
        },
    },
    {
        customId: "help_en",
        async execute(interaction) {
            const embed = new EmbedBuilder()
                .setTitle("📖 Commands (English)")
                .setDescription(
                    "`+bal` - Show your balance\n" +
                   "`+daily` - Get daily reward\n" +
                  "`+transfer` - Transfer money\n" +
                 "`+gamble` - Gamble your money\n" +
                         "`+slots` - Play slots\n" +
    "`+coinflip` - Flip a coin (heads or tails)\n" +
    "`+top` - Show the 10 richest people in the server"
                )
                .setColor("Blue");

            await interaction.reply({ embeds: [embed], ephemeral: true });
        },
    },
    {
        customId: "help_admin",
        async execute(interaction) {
            const embed = new EmbedBuilder()
                .setTitle("⚙️ أوامر الإدارة / Admin Commands")
                .setDescription(
                    "__**بالعربي**__\n" +
                    "**+تصفير <@منشن>** - تصفير رصيد العضو\n" +
                    "**+ازالة <@منشن> <المبلغ>** - خصم مبلغ من العضو\n" +
                    "**+اضافة <@منشن> <المبلغ>** - اضافة مبلغ للعضو\n\n" +
                    "__**English**__\n" +
                    "**+reset <@user>** - Reset user balance\n" +
                    "**+remove <@user> <amount>** - Remove money from user\n" +
                    "**+add <@user> <amount>** - Add money to user"
                )
                .setColor("Red");
            await interaction.reply({ embeds: [embed], ephemeral: true });
        },
    },
];
