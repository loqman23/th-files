import discord
from discord import app_commands
import json
import g4f

# === إعداد وتحميل ملف config ===
def load_config():
    with open('config.json', 'r') as f:
        return json.load(f)

def save_config(config):
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=4)

config = load_config()

# === إعداد Intents ===
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.guilds = True
intents.dm_messages = True  # مهم لدعم الرسائل في الخاص

bot = discord.Client(intents=intents)
tree = app_commands.CommandTree(bot)

# === دالة FreeGPT ===
def ask_freegpt(prompt):
    try:
        response = g4f.ChatCompletion.create(
            model=g4f.models.default,
            messages=[
                {"role": "system", "content": "You are a helpful assistant bot. Your name is Orbix AI. You are made by Orbix Team. You are a developer. You are an auto bot. You work for the Orbix Bot server."},
                {"role": "user", "content": prompt}
            ]
        )
        return response
    except Exception as e:
        print(f"[FreeGPT Error]: {e}")
        return "❌ حدث خطأ أثناء الاتصال بـ FreeGPT."

# === عند تشغيل البوت ===
@bot.event
async def on_ready():
    await tree.sync()
    print(f'✅ تم تسجيل الدخول كبوت: {bot.user}')

# === أمر /set-room ===
@tree.command(name="set-room", description="تحديد الروم الذي يستطيع البوت الرد فيه.")
@app_commands.describe(room="اختر الروم")
async def set_room(interaction: discord.Interaction, room: discord.TextChannel):
    if room.id not in config["roomsid"]:
        config["roomsid"].append(room.id)
        save_config(config)
        await interaction.response.send_message(f"✅ تم تسجيل الروم {room.mention}.", ephemeral=True)
    else:
        await interaction.response.send_message(f"⚠️ الروم {room.mention} مسجل مسبقًا.", ephemeral=True)

# === التعامل مع الرسائل ===
@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # دعم الرد في الخاص (DM)
    if isinstance(message.channel, discord.DMChannel):
        await message.channel.typing()
        reply = ask_freegpt(message.content)
        await message.reply(reply)
        return

    # الرد في الرومات المسجلة
    if message.channel.id in config["roomsid"]:
        await message.channel.typing()
        reply = ask_freegpt(message.content)
        await message.reply(reply)

# === تشغيل البوت ===
bot.run(config["bot-token"])