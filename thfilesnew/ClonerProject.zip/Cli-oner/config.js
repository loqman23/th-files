module.exports = {
  parentId: '1248655446777266279',
  probot_ids: ['282859044593598464', ''],
  recipientId: '1209484473104732203',
  price: 1,

};
