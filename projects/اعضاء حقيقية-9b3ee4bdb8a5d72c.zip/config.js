module.exports = {
  "bot": {
    "owners": [""],
    "botID": "",
    "GuildId": "",
    "ClientId": "",
    "serverinvte": "https://discord.gg/code",
    "clientSECRET": "",
    "callbackURL": "http://Adress Your Host/login",
    "inviteBotUrl": "Link_InviteBot",
    "TheLinkVerfy": "Link_Verfy",
    "prefix": "-",
    "ceatogry": "",
    "TOKEN": "",
    "TraId": "",
    "price": "",
    "channelId": "",
    "roleId": "",
    "LineIce": "",
    "taxchannels": "",
    "coinprice": ""
  },
  "Log": {
    "LogChannelOwners": ""
  },
  "website": {
    "PORT": "22069"
  }
};