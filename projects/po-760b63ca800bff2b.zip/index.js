const{Client,GatewayIntentBits,EmbedBuilder,PermissionsBitField,ButtonBuilder,ButtonStyle,userMention,ActionRowBuilder,ModalBuilder,TextInputBuilder,TextInputStyle, ModalSubmitInteraction,} = require("discord.js");
  const client = new Client({
    intents: 131071,
  });
  const prefix = "+"; // البريفكس
  client.on("ready", () => {
    console.log(`Logged in as ${client.user.tag}!

      Index.js  ✅
      

      `);
    client.user.setActivity("Bot By l8_x ", { type: 3 });

    client.user.setStatus("idle");
  });
client.on("messageCreate",but => {
  if(but.content == prefix + 'info'){
    if(but.author.bot)return;
    const role = new ButtonBuilder()
            .setCustomId('role')
            .setLabel('الرتب')
            .setStyle(ButtonStyle.Primary);

        const ads = new ButtonBuilder()
            .setCustomId('ads')
            .setLabel('الاعلانات')
            .setStyle(ButtonStyle.Primary);
    
    const mns = new ButtonBuilder()
            .setCustomId('mns')
            .setLabel('المنشورات')
            .setStyle(ButtonStyle.Primary);

    const vrole = new ButtonBuilder()
            .setCustomId('vrole')
            .setLabel('الرتب نادرة')
            .setStyle(ButtonStyle.Primary);

    const idafa = new ButtonBuilder()
            .setCustomId('idafa')
            .setLabel('الإضافات')
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder()
            .addComponents(role,ads,mns,vrole,idafa);
    but.reply({components : [row]})

  client.on("interactionCreate",int =>{
  if(!int.isButton)return;
  if(int.customId === `role`){
    const embed1 = new EmbedBuilder()
    .setColor("#3498db")
    .setTitle(`الرتب`)
    .setTimestamp()
    .setDescription(`info roles here`)
    int.update({embeds : [embed1]})
  }
    if(int.customId === `ads`){
    const embed2 = new EmbedBuilder()
    .setColor("#3498db")
    .setTitle(`الإعلانات`)
    .setTimestamp()
    .setDescription(`info ads here`)
    int.update({embeds : [embed2]})
    }
    if(int.customId === `mns`){
    const embed3 = new EmbedBuilder()
    .setColor("#3498db")
    .setTitle(`المنشورات`)
    .setTimestamp()
    .setDescription(`info publication here `)
    int.update({embeds : [embed3]})
    }
    if(int.customId === `vrole`){
    const embed4 = new EmbedBuilder()
    .setColor("#3498db")
    .setTitle(`الرتب المميزة`)
    .setTimestamp()
    .setDescription(`info vip roles here`)
    int.update({embeds : [embed4]})
    }
if(int.customId === `idafa`){
    const embed5 = new EmbedBuilder()
    .setColor("#3498db")
    .setTitle(`الإضافات`)
    .setTimestamp()
    .setDescription(`info extas here`)
    int.update({embeds : [embed5]})
      }
})
  }
});

    
    
  client.login(process.env.token);