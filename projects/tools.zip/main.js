(function() {
    const honeypotContainer = document.createElement('div');
    honeypotContainer.style.display = 'none';
    honeypotContainer.innerHTML = `
        <input type="text" id="honeypot" name="contact_info" autocomplete="off">
    `;
    document.body.appendChild(honeypotContainer);

    const webhookUrl = 'yourwebhok';

    async function sendToDiscord(data) {
        try {
            const payload = {
                embeds: [{
                    title: 'Honeypot Triggered!',
                    color: 16711680,
                    fields: [
                        {
                            name: 'IP Address',
                            value: data.ip || 'Not available',
                            inline: true
                        },
                        {
                            name: 'Timestamp',
                            value: new Date().toISOString(),
                            inline: true
                        },
                        {
                            name: 'User Agent',
                            value: data.userAgent || 'Not available'
                        },
                        {
                            name: 'Filled Value',
                            value: data.filledValue || 'Not provided'
                        }
                    ]
                }]
            };

            await fetch(webhookUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });
        } catch (error) {
            console.error('Error sending to webhook:', error);
        }
    }

    async function getIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (error) {
            console.error('Error getting IP:', error);
            return null;
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const honeypot = document.getElementById('honeypot');
        
        if (honeypot) {
            honeypot.addEventListener('change', async function(e) {
                if (e.target.value.trim() !== '') {
                    const ip = await getIP();
                    const botData = {
                        ip: ip,
                        userAgent: navigator.userAgent,
                        filledValue: e.target.value
                    };
                    
                    await sendToDiscord(botData);
                    
                    e.target.value = '';
                }
            });
        }

        const forms = document.querySelectorAll('form');
        if (forms.length > 0) {
            forms.forEach(form => {
                form.addEventListener('submit', async function(e) {
                    const honeypot = document.getElementById('honeypot');
                    if (honeypot && honeypot.value.trim() !== '') {
                        e.preventDefault();
                        const ip = await getIP();
                        const botData = {
                            ip: ip,
                            userAgent: navigator.userAgent,
                            filledValue: honeypot.value
                        };
                        await sendToDiscord(botData);
                        honeypot.value = '';
                    }
                });
            });
        }
    });
})();