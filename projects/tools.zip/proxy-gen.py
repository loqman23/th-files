import requests
import re
import threading
import queue
from bs4 import BeautifulSoup
import time
import random

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

proxy_sources = [
    "https://www.sslproxies.org/",
    "https://free-proxy-list.net/",
    "https://www.us-proxy.org/",
    "https://www.proxy-list.download/HTTP"
]

proxy_queue = queue.Queue()
working_proxies = []
lock = threading.Lock() 

def scrape_proxies():
    threads = []
    for url in proxy_sources:
        t = threading.Thread(target=scrape_source, args=(url,))
        t.start()
        threads.append(t)
    
    for t in threads:
        t.join()

def scrape_source(url):
    try:
        response = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(response.text, "html.parser")
        proxy_pattern = re.compile(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})")
        proxies = proxy_pattern.findall(str(soup))
        for ip, port in proxies:
            proxy_queue.put(f"{ip}:{port}")
        print(f"Added {len(proxies)} proxies from {url}")
    except Exception as e:
        print(f"Error with {url}: {e}")

def test_proxy(proxy):
    proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
    try:
        start_time = time.time()
        response = requests.get("https://www.google.com", proxies=proxies, headers=headers, timeout=2)
        if response.status_code == 200:
            elapsed = round((time.time() - start_time) * 1000, 2)
            with lock:
                working_proxies.append((proxy, elapsed))
                print(f"Found working proxy: {proxy} - {elapsed}ms")
    except:
        pass

def proxy_worker():
    while True:
        try:
            proxy = proxy_queue.get(block=False)
            test_proxy(proxy)
        except queue.Empty:
            break
        finally:
            proxy_queue.task_done()

def generate_proxies():
    print("Starting proxy search...")
    start_time = time.time()
    
    scrape_proxies()
    
    total = proxy_queue.qsize()
    print(f"Testing {total} proxies...")
    
    threads = []
    num_threads = min(50, total)
    for _ in range(num_threads):
        t = threading.Thread(target=proxy_worker)
        t.daemon = True
        t.start()
        threads.append(t)
    
    timeout_seconds = 30
    timeout = time.time() + timeout_seconds
    while not proxy_queue.empty() and time.time() < timeout:
        time.sleep(0.5)
    
    working_proxies.sort(key=lambda x: x[1])
    with open("proxy.txt", "w") as f:
        for proxy, speed in working_proxies:
            f.write(f"{proxy} - {speed}ms\n")
    
    elapsed = round(time.time() - start_time, 2)
    print(f"\nCompleted in {elapsed} seconds. Found {len(working_proxies)} working proxies.")

if __name__ == "__main__":
    generate_proxies()