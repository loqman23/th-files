require('dotenv').config();
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const { Strategy } = require('passport-discord');
const bodyParser = require('body-parser');
const path = require('path');
const flash = require('connect-flash');
const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');

const app = express();
const PORT = process.env.PORT || 3000;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildPresences
  ]
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: 'broadcast-bot-secret',
  resave: false,
  saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((obj, done) => {
  done(null, obj);
});

passport.use(new Strategy({
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: process.env.CALLBACK_URL,
  scope: ['identify']
}, (accessToken, refreshToken, profile, done) => {
  process.nextTick(() => {
    return done(null, profile);
  });
}));

function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/');
}

function isOwner(req, res, next) {
  if (req.isAuthenticated() && req.user.id === process.env.OWNER_ID) {
    return next();
  }
  res.redirect('/unauthorized');
}

app.get('/', (req, res) => {
  res.render('index', { 
    user: req.user,
    botStatus: client.isReady(),
    guilds: client.guilds.cache.size,
    members: client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)
  });
});

app.get('/login', passport.authenticate('discord'));

app.get('/callback', 
  passport.authenticate('discord', { 
    failureRedirect: '/' 
  }), 
  (req, res) => {
    res.redirect('/dashboard');
  }
);

app.get('/logout', (req, res) => {
  req.logout(function(err) {
    if (err) { return next(err); }
    res.redirect('/');
  });
});

app.get('/dashboard', isOwner, (req, res) => {
  const guilds = client.guilds.cache.map(guild => ({
    id: guild.id,
    name: guild.name,
    memberCount: guild.memberCount,
    icon: guild.iconURL({ dynamic: true })
  }));
  
  res.render('dashboard', { 
    user: req.user,
    botStatus: client.isReady(),
    guilds: guilds,
    success: req.flash('success'),
    error: req.flash('error')
  });
});

app.get('/unauthorized', isAuthenticated, (req, res) => {
  res.render('unauthorized', { user: req.user });
});

app.post('/broadcast', isOwner, async (req, res) => {
  const { message, type, guildId } = req.body;
  
  if (!message) {
    req.flash('error', 'الرجاء إدخال رسالة');
    return res.redirect('/dashboard');
  }
  
  try {
    let targetMembers = [];
    let targetGuild = null;
    
    if (guildId && guildId !== 'all') {
      targetGuild = client.guilds.cache.get(guildId);
      if (!targetGuild) {
        req.flash('error', 'لم يتم العثور على السيرفر');
        return res.redirect('/dashboard');
      }
      
      await targetGuild.members.fetch();
      targetMembers = Array.from(targetGuild.members.cache.values());
    } else {
      for (const guild of client.guilds.cache.values()) {
        await guild.members.fetch();
        targetMembers = [...targetMembers, ...Array.from(guild.members.cache.values())];
      }
    }
    
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('رسالة برود كاست')
      .setDescription(message)
      .setTimestamp()
      .setFooter({ text: 'نظام البرودكاست' });
    
    let sentCount = 0;
    let failedCount = 0;
    
    for (const member of targetMembers) {
      if (member.user.bot) continue;
      
      if (type === 'online' && member.presence?.status !== 'online') continue;
      if (type === 'offline' && member.presence?.status === 'online') continue;
      
      try {
        await member.send({ embeds: [embed] });
        sentCount++;
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        failedCount++;
      }
    }
    
    req.flash('success', `تم إرسال الرسالة بنجاح إلى ${sentCount} عضو. فشل الإرسال إلى ${failedCount} عضو.`);
    res.redirect('/dashboard');
  } catch (error) {
    console.error('Broadcast error:', error);
    req.flash('error', 'حدث خطأ أثناء إرسال البرودكاست');
    res.redirect('/dashboard');
  }
});

client.on('ready', () => {
  console.log(`Bot logged in as ${client.user.tag}`);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  client.login(process.env.BOT_TOKEN);
});