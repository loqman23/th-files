const { Client, Collection, MessageEmbed, MessageSelectMenu, MessageActionRow } = require("discord.js");
let moment = require('moment')
const Discord = require("discord.js");
const client = new Discord.Client();

const db = require('pro.db');
const express = require("express");
const app = express();
app.listen(() => console.log("ThailandCodes"));

let role1 = "" // ايدي رول متسابق
let line = ""// رابط خط سيرفرك
var prefix = "$"; // البرفكس

client.on("ready", () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

function attachIsImage(msgAttach) {
  var url = msgAttach.url;
  return (
    url.indexOf("png", url.length - "png".length) !== -1 ||
    url.indexOf("jpg", url.length - "jpg".length) !== -1 ||
    url.indexOf("gif", url.length - "gif".length) !== -1 ||
    url.indexOf("jpeg", url.length - "jpeg".length) !== -1
  );
}



client.on("message", async (message) => {
    if (message.content.startsWith(prefix + "apply")) {
      if (message.channel.id != "") return //روم استقبال الامر
      if (message.attachments.size == 0)
        return message.channel.send(            `> **:x: برجاء كتابه الامر ومن ثم رفع الصوره**`);
      if (message.attachments.size > 1)
        return message.channel.send(
          `> **:x: برجاء عدم ارسال اكثر من صوره واحده ! **`
        );
    
      if (message.attachments.size == 1) {
        if (!message.attachments.every(attachIsImage))
          return message.channel.send(
            `> **:x: برجاء كتابه الامر ومن ثم رفع الصورة**`
          );
        if (message.attachments.every(attachIsImage)) {
        }
  
      }
      
  const room1 = message.guild.channels.cache.find(c => c.id === "" )// ايدي الروم الي يرسل فيها الصورة والخط واسم ورقم المتسابق
  if(!room1) return message.reply('> ماقدرت القا روم')
                     db.add(`Vote_${message.guild.id}`,1)
            let po = db.fetch(`Vote_${message.guild.id}`)
            if(!po || po === null) po = 1;
      await room1.send(`> **المتسابق** : ${message.author} 
> ** رقم : __#${po}__ **`)
    await  room1.send(new Discord.MessageAttachment(message.attachments.first().url)).then(msg => {
          msg.react('✅') // الإيموجي الي يتحط عالصورة
      })
      
   {message.member.roles.add(role1);}
      
           await message.channel.send(`> **تم ارسال الصوره , وتم وضع الرياكشن بالتوفيق لك ولجميع المتسابقين !**`)
      await  room1.send(line)
    }
  });

client.login(process.env.GIV_TOKEN);
