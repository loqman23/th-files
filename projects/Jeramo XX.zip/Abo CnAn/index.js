import {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} from "discord.js";
import "dotenv/config";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const games = new Map();

class TicTacToeGame {
  constructor() {
    this.players = [];
    this.board = Array(9).fill(null);
    this.currentPlayer = 0;
    this.symbols = ["❌", "⭕"];
    this.joinTimeout = null;
    this.currentGameMessage = null;
    this.turnMessage = null;
  }

  addPlayer(player) {
    if (this.players.length < 15) {
      this.players.push(player);
      return true;
    }
    return false;
  }

  removePlayer(player) {
    const index = this.players.indexOf(player);
    if (index > -1) {
      this.players.splice(index, 1);
    }
  }

  checkWin(board, symbol) {
    const winConditions = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8], // Rows
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8], // Columns
      [0, 4, 8],
      [2, 4, 6], // Diagonals
    ];

    return winConditions.some((condition) =>
      condition.every((index) => board[index] === symbol)
    );
  }

  isBoardFull() {
    return !this.board.includes(null);
  }

  makeMove(position) {
    if (this.board[position] === null) {
      this.board[position] = this.symbols[this.currentPlayer % 2];
      return true;
    }
    return false;
  }
}

client.on("ready", () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on("messageCreate", async (message) => {
  if (message.content === "+start" && !message.author.bot) {
    const game = new TicTacToeGame();
    games.set(message.channelId, game);

    const joinButton = new ButtonBuilder()
      .setCustomId("join")
      .setLabel("🎮 انضم للعبة")
      .setStyle(ButtonStyle.Success);

    const leaveButton = new ButtonBuilder()
      .setCustomId("leave")
      .setLabel("❌ اترك اللعبة")
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(joinButton, leaveButton);

    let timeLeft = 30;
    const embed = new EmbedBuilder()
      .setTitle('🎮 بطولة اكس أو | XO Tournament')
      .setDescription('**انضم إلى البطولة! اللعبة ستبدأ قريبًا**\n\n📝 **قوانين اللعبة:**\n✅ الحد الأدنى للاعبين: 2\n✅ الحد الأقصى للاعبين: 15\n🔄 يتناوب اللاعبون على لعب ❌ و ⭕\n🚫 يتم إقصاء الخاسرين بعد كل جولة\n👑 آخر لاعب متبقي هو الفائز النهائي!\n\n🎮 **هل أنت مستعد للتحدي؟ انضم الآن!**')
      .setColor('#00ff00')
      .setImage('https://media-hosting.imagekit.io/351ac00865fb4285/ChatGPT%20Image%20Apr%2011,%202025,%2002_33_57%20PM.png?Expires=1838979264&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=TtWBb9YfVRYhVi2hU7CgyJ7yEdzxlkLrz0saUQe4dCX015MsNDQDosTbmRhT1VqfYwn4Wn9H7u8ByWwQC2uqoN~uuJOZ3apJ4LoNZhepzunxmMuz1sVDmZ1Mn93aFVx2JgrCX0G1EY9sCg~hx9R7s4BPwdONXzOmw2BnGj~quZ2cg5MmP-wJfqgj~T8kRfgLCS442xa-hHjihUcYTyGPpbO6DrrFuT589dHaRpd7g3P2y8zkIXNLCcg32Vq63ezFDXpQ8fiVovu79c2toGLwOVPUHOSd6EcezJYJXIb1HgGip~-3m6vjTpYTOsifjG~HDyjfwLW9X~Vb1jrtJcHAbw__')
      .addFields(
        { name: '👥 اللاعبين المنضمين', value: '**لا يوجد لاعبين حاليًا**', inline: true },
        { name: '⏳ الوقت المتبقي', value: `**${timeLeft} ثانية**`, inline: true },
        { name: '🎯 طريقة اللعب', value: 'استعد للعب واستراتيجية الفوز!' }
      )
      .setFooter({ text: '🎮 استخدم الأزرار أدناه للانضمام أو المغادرة' });

    const gameMessage = await message.channel.send({
      embeds: [embed],
      components: [row],
    });

    // Update timer every 5 seconds
    const timerInterval = setInterval(async () => {
      timeLeft -= 5;
      if (timeLeft >= 0) {
        const updatedEmbed = EmbedBuilder.from(gameMessage.embeds[0]).setFields(
          {
            name: "👥 اللاعبين المنضمين",
            value:
              game.players.length > 0
                ? game.players.map((id) => `<@${id}>`).join("\n")
                : "**لا يوجد لاعبين**",
          },
          { name: "⏰ الوقت المتبقي", value: `**${timeLeft} ثانية**` }
        );
        await gameMessage.edit({ embeds: [updatedEmbed] });
      }
    }, 5000);

    game.joinTimeout = setTimeout(async () => {
      clearInterval(timerInterval);
      if (game.players.length < 2) {
        games.delete(message.channelId);
        await gameMessage.edit({
          embeds: [
            embed
              .setDescription(
                "**❌ لم ينضم عدد كافٍ من اللاعبين. تم إلغاء اللعبة**"
              )
              .setColor("#ff0000"),
          ],
          components: [],
        });
        return;
      }

      await gameMessage.edit({
        embeds: [
          embed
            .setDescription(
              `**✅ بدأت اللعبة بـ ${game.players.length} لاعبين!**`
            )
            .setColor("#0000ff"),
        ],
        components: [],
      });

      await message.channel.send("**جار تجهيز الأدوار | 🎮**");
      startTournament(message.channel, game);
    }, 30000);
  }
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;

  const game = games.get(interaction.channelId);
  if (!game) return;

  if (interaction.customId === "join") {
    if (game.players.includes(interaction.user.id)) {
      await interaction.reply({
        content: "**❌ أنت منضم للعبة بالفعل!**",
        ephemeral: true,
      });
      return;
    }

    if (game.addPlayer(interaction.user.id)) {
      const embed = EmbedBuilder.from(interaction.message.embeds[0]).setFields(
        {
          name: "👥 اللاعبين المنضمين",
          value: game.players.map((id) => `<@${id}>`).join("\n"),
        },
        {
          name: "⏰ الوقت المتبقي",
          value: interaction.message.embeds[0].fields[1].value,
        }
      );

      await interaction.message.edit({ embeds: [embed] });
      await interaction.reply({
        content: "**✅ لقد انضممت للعبة!**",
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: "**❌ اللعبة ممتلئة!**",
        ephemeral: true,
      });
    }
  }

  if (interaction.customId === "leave") {
    if (!game.players.includes(interaction.user.id)) {
      await interaction.reply({
        content: "**❌ أنت لست في اللعبة!**",
        ephemeral: true,
      });
      return;
    }

    game.removePlayer(interaction.user.id);
    const embed = EmbedBuilder.from(interaction.message.embeds[0]).setFields(
      {
        name: "👥 اللاعبين المنضمين",
        value:
          game.players.length > 0
            ? game.players.map((id) => `<@${id}>`).join("\n")
            : "**لا يوجد لاعبين**",
      },
      {
        name: "⏰ الوقت المتبقي",
        value: interaction.message.embeds[0].fields[1].value,
      }
    );

    await interaction.message.edit({ embeds: [embed] });
    await interaction.reply({
      content: "**✅ لقد غادرت اللعبة!**",
      ephemeral: true,
    });
  }

  if (interaction.customId.startsWith("move_")) {
    const position = parseInt(interaction.customId.split("_")[1]);
    if (game.players[game.currentPlayer % 2] !== interaction.user.id) {
      await interaction.reply({ content: "**❌ ليس دورك!**", ephemeral: true });
      return;
    }

    if (game.makeMove(position)) {
      const winner = game.checkWin(
        game.board,
        game.symbols[game.currentPlayer % 2]
      );
      const draw = !winner && game.isBoardFull();

      if (winner || draw) {
        if (winner) {
          const winnerIndex = game.currentPlayer % 2;
          const loserIndex = winnerIndex === 0 ? 1 : 0;
          const loserPlayer = game.players[loserIndex];
          game.players.splice(loserIndex, 1);
          await interaction.message.channel.send(
            `**🏆 الفائز: <@${game.players[winnerIndex]}>!\n❌ خرج من اللعبة: <@${loserPlayer}>**`
          );
        } else {
          await interaction.message.channel.send(
            "**📍 تعادل! تم إقصاء كلا اللاعبين**"
          );
          game.players.splice(0, 2);
        }

        if (game.players.length <= 1) {
          if (game.players.length === 1) {
            await interaction.message.channel.send(
              `**👑 الفائز بالبطولة: <@${game.players[0]}>! مبروك! 🎉**`
            );
          }
          games.delete(interaction.channelId);
        } else {
          game.board = Array(9).fill(null);
          game.currentPlayer = 0;
          await interaction.message.channel.send("**جار تجهيز الأدوار | 🎮**");
          startMatch(interaction.message.channel, game);
        }
      } else {
        game.currentPlayer++;
        updateGameBoard(interaction.message, game);
      }
      await interaction.deferUpdate();
    }
  }
});

async function startTournament(channel, game) {
  shuffleArray(game.players);
  startMatch(channel, game);
}

async function startMatch(channel, game) {
  const buttons = [];
  for (let i = 0; i < 9; i++) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`move_${i}`)
        .setLabel("⬛")
        .setStyle(ButtonStyle.Secondary)
    );
  }

  const rows = [];
  for (let i = 0; i < 3; i++) {
    rows.push(
      new ActionRowBuilder().addComponents(buttons.slice(i * 3, (i + 1) * 3))
    );
  }

  const embed = new EmbedBuilder()
    .setTitle("🎮 مباراة اكس او")
    .setDescription(
      `**المباراة الحالية:**\n<@${game.players[0]}> (❌) ضد <@${game.players[1]}> (⭕)\n\n**دور اللاعب:** <@${game.players[0]}> ❌`
    )
    .setColor("#0000ff")
    .setFooter({ text: "🎮 اضغط على المربع الذي تريد اللعب فيه" });

  game.currentGameMessage = await channel.send({
    embeds: [embed],
    components: rows,
  });
}

function updateGameBoard(message, game) {
  const currentPlayerIndex = game.currentPlayer % 2;
  const embed = EmbedBuilder.from(message.embeds[0]).setDescription(
    `**المباراة الحالية:**\n<@${game.players[0]}> (❌) ضد <@${game.players[1]}> (⭕)\n\n**دور اللاعب:** <@${game.players[currentPlayerIndex]}> ${game.symbols[currentPlayerIndex]}`
  );

  const components = message.components.map((row) => {
    return new ActionRowBuilder().addComponents(
      row.components.map((button) => {
        const position = parseInt(button.customId.split("_")[1]);
        return ButtonBuilder.from(button).setLabel(
          game.board[position] || "⬛"
        );
      })
    );
  });

  message.edit({ embeds: [embed], components: components });
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

client.login(process.env.DISCORD_TOKEN);
