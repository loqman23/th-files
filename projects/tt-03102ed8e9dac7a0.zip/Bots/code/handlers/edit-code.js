const { SlashCommandBuilder,Events,StringSelectMenuBuilder ,Client, ActivityType,ModalBuilder,TextInputStyle, EmbedBuilder , PermissionsBitField,ButtonStyle, TextInputBuilder, ActionRowBuilder,ButtonBuilder,MessageComponentCollector } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/codeDB.json")
module.exports = (client99) => {
  client99.on(Events.InteractionCreate , async(interaction) =>{
    if (!interaction.isModalSubmit()) return;
  
    if (interaction.customId === 'updatecode') {
    
      const oldName = interaction.fields.getTextInputValue('oldName');
      const newName = interaction.fields.getTextInputValue('newName');
      const newPrice = interaction.fields.getTextInputValue('newPrice');
      const newLink = interaction.fields.getTextInputValue('newLink');
  
      const foundcodes = await db.get(`codes_${interaction.guild.id}`, { codesName: oldName });
  
      let thecodeName;
      if (Array.isArray(foundcodes) && foundcodes.length > 0) {
            
        const selectedcode = foundcodes.find(code => code.codeName === oldName);
        if (selectedcode) {
          thecodeName = selectedcode.codeName;
        } else {
          return interaction.reply({ content: `** قم بإدخال إسم منتج صحيح**`, ephemeral: true });
        }
      }
  
      if(isNaN(newPrice)) return interaction.reply({ content: `**قم إدخال سعر المنتج بطريقة صحيحة.**`, ephemeral:true });
  
      const checkData = await db.get(`codes_${interaction.guild.id}`);
      const removingcode = checkData.filter(re => re.codeName !== thecodeName);
      await db.set(`codes_${interaction.guild.id}`, removingcode);
  
      await db.push(`codes_${interaction.guild.id}`, {
        codeName: newName,
        codePrice: newPrice,
        codeLink: newLink
      });
  
      interaction.reply({ content: `** تم تعديل المنتج بنجاح**` });
  
    }
  })};