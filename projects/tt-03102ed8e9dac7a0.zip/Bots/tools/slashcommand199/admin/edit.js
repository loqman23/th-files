const { SlashCommandBuilder, EmbedBuilder,TextInputBuilder,ModalBuilder , PermissionsBitField,TextInputStyle, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/toolsDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('edit')
    .setDescription('تعديل ادات'),
  
  async execute(interaction) {
    const modal = new ModalBuilder()
		  .setCustomId('updatetools')
		  .setTitle('تعديل ادات');

    const oldtoolsName = new TextInputBuilder()
		  .setCustomId('oldName') .setLabel('قم بإدخال الإسم القديم للكود') .setRequired(true) .setStyle(TextInputStyle.Short);

	  const newtoolsName = new TextInputBuilder()
		  .setCustomId('newName') .setLabel('قم بإدخال الإسم الجديد للكود') .setRequired(true) .setStyle(TextInputStyle.Short);

    const newtoolsPrice = new TextInputBuilder()
		  .setCustomId('newPrice') .setLabel('قم بإدخال السعر الجديد للبروجكت') .setRequired(true) .setStyle(TextInputStyle.Short);

    const newtoolsLink = new TextInputBuilder()
		  .setCustomId('newLink') .setLabel('قم بإدخال الرابط الجديد للبروجكت') .setRequired(true) .setStyle(TextInputStyle.Short);

    const oldName = new ActionRowBuilder().addComponents(oldtoolsName);
    const newName = new ActionRowBuilder().addComponents(newtoolsName);
    const newPrice = new ActionRowBuilder().addComponents(newtoolsPrice);
    const newLink = new ActionRowBuilder().addComponents(newtoolsLink);

	  modal.addComponents(oldName, newName, newPrice, newLink);
	  await interaction.showModal(modal);
    
  }
}