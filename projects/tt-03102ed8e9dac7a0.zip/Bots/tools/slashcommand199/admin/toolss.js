const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/toolsDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('toolss')
    .setDescription('لعرض جميع ادوات الموجودة'),
  async execute(interaction) {
    const tools = await db.get(`toolss_${interaction.guild.id}`);
    if (!tools || codes.length === 0) {
      return interaction.reply({ content: `**لا توجد بيانات متاحة حالياً.**`, ephemeral: true });
    } else {
      let response = '**ادوات متاحة:**\n';
      codes.forEach(tools => {
        response += `- **الاسم :${tools.codeName}** \n- **السعر :${tools.codePrice}** \n- **الرابط :**${tools.codeLink}\n------------------\n`;
      });
      return interaction.reply({ content: response, ephemeral: true });
    }
  }
}