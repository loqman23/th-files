const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/toolsDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('اعطاء ادات')
  .addUserOption(Option => Option
    .setName(`user`)
    .setDescription(`الشخص`)
    .setRequired(true))
.addStringOption(text => text
    .setName(`tools-name`)
    .setDescription(`اسم ادات`)
    .setRequired(true))
,
  
  async execute(interaction) {
    const recipient = interaction.options.getUser('user');
    const selectedtools = interaction.options.getString('tools-name');
    
    const toolss = await db.get(`toolss_${interaction.guild.id}`);
    const toolsData = toolss.find(code => tools.toolsName === selectedtools);

    if (!toolsData) {
      return interaction.reply({ content: '**لا يمكن العثور على اسم ادات المحدد.**', ephemeral: true });
    }

    const toolsLink = toolsData.toolsLink;

    await recipient.send(`**تم منحك رابط ادات: ${toolsLink}**`);
    await interaction.reply({ content: `**✅ تم إرسال الرابط بنجاح لـ ${recipient}**` });
  }
};

async function getProjectChoices() {
  const toolss = await db.get(`toolss_${interaction.guild.id}`) || [];
  const choices = [];

  for (const tools of toolss) {
    choices.push({
      name: tools.toolsName,
      value: tools.toolsName
    });
  }

  return choices;
}
