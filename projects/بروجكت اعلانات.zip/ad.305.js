const client = require("./index.js");
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  PermissionsBitField,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
//==============عدل بس الي تحت لا تمسك شي ثاني=======//
const channelad = "ايدي روم الي يرسل في اعلانات";
const idbank = "ايدي البنك الي تتحول له الكردت";
const idprobot = "ايدي برو بوت";
const line = "رابط الخط";

// عشان تضيف باقة جديده سو كذا
// "اسم الباقة": { price: السعر, mention: "@here او @everyone"}
//شف تحت وان شاء الله تفهم
const panelad = {
  "everyone": {
    price: 100,
    mention: "@everyone"
  },
  "here": {
    price: 10,
    mention: "@here"
  }
};
//=============عدل بس الي فوق لا تمسك شي ثاني========//
const userAds = new Map();
const activeTickets = new Set();

function paneladf() {
  return new StringSelectMenuBuilder()
    .setCustomId("menu")
    .setPlaceholder("اختر مانوع الاعلان !")
    .addOptions(
      Object.entries(panelad).map(([key]) => ({
        label: key,
        value: key
      }))
    );
}

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

  if (message.content.toLowerCase() === "!spa") {
    const menuad = paneladf();
    const row = new ActionRowBuilder().addComponents(menuad);
    message.channel.send({ components: [row] });
    await message.delete();
  }
});

client.on("interactionCreate", async (interaction) => {
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId !== "menu") return;

    if (activeTickets.has(interaction.user.id)) {
      return interaction.reply({
        content: `**عندك تذكرة مفتوحة بالفعل!**`,
        ephemeral: true
      });
    }

    const sKey = interaction.values[0];
    const sData = panelad[sKey];
    const sPrice = sData.price;
    const sMention = sData.mention;

    userAds.set(interaction.user.id, { sKey, sPrice, sMention });

    await interaction.deferReply({ ephemeral: true });

    const ticketbuy = await interaction.guild.channels.create({
      name: `${sKey}-${interaction.user.username}`,
      type: 0,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: ['ViewChannel']
        },
        {
          id: interaction.user.id,
          allow: ['ViewChannel', 'SendMessages']
        }
      ]
    });

    activeTickets.add(interaction.user.id);

    const msgticket = new EmbedBuilder()
      .setTitle(`اهلًا <@${interaction.user.id}>`)
      .setDescription(`**لقد قمت باختيار الباقة ${sKey}\n\nحتى تكمل الشراء الرجاء ضغط الزر الاخضر\nحتى تتوقف عن الشراء الرجاء ضغط الزر الاحمر**`)
      .setColor("White");

    const acceptbutton = new ButtonBuilder()
      .setCustomId('accept')
      .setLabel("اكمال الشراء")
      .setStyle(ButtonStyle.Success);

    const cancelbutton = new ButtonBuilder()
      .setCustomId('cancel')
      .setLabel('الغاء الشراء')
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(acceptbutton, cancelbutton);

    await ticketbuy.send({ content: `<@${interaction.user.id}>` });
    await ticketbuy.send({ embeds: [msgticket], components: [row] });
    await ticketbuy.send(line);

    await interaction.editReply({ content: `**تم انشاء التذكرة : <#${ticketbuy.id}>**` });
  }

  if (interaction.isButton()) {
    const userData = userAds.get(interaction.user.id);
    if (!userData) return interaction.reply({ content: "حدث خطأ، حاول مرة ثانية.", ephemeral: true });

    const { sKey, sPrice, sMention } = userData;

    if (interaction.customId === "cancel") {
      await interaction.deferReply({ ephemeral: false });
      await interaction.editReply("**تم الغاء عملية الشراء\n سيتم حذف التذكرة خلال 5 ثواني**");

      await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
        SendMessages: false,
        ViewChannel: true
      });

      setTimeout(() => {
        activeTickets.delete(interaction.user.id);
        interaction.channel.delete().catch(() => {});
      }, 5000);
    }

    if (interaction.customId === "accept") {
      const tax = Math.floor(sPrice * (20 / 19) + 1);

      const embedbuy = new EmbedBuilder()
        .setTitle("قم بتحويل المبلغ")
        .setDescription(`\`#credit ${idbank} ${tax}\``)
        .setColor("White");

      const copybtn = new ButtonBuilder()
        .setCustomId("copybtn")
        .setLabel("نسخ")
        .setStyle(ButtonStyle.Primary);

      const row = new ActionRowBuilder().addComponents(copybtn);

      await interaction.deferReply({ ephemeral: false });
      await interaction.editReply({ embeds: [embedbuy], components: [row] });

      const filter = (msg) =>
        msg.author.id === idprobot &&
        msg.content.includes(`$${sPrice}`) &&
        msg.content.includes(`<@!${idbank}>`);

      const collector = interaction.channel.createMessageCollector({ filter, time: 60000 });

      collector.on("collect", async () => {
        await interaction.channel.send("**تم استلام المبلغ، الرجاء ارسال وصف إعلانك ( بدون منشن أو روابط )**");

        const msgFilter = (msg) => msg.author.id === interaction.user.id;
        const msgCollector = interaction.channel.createMessageCollector({ filter: msgFilter, max: 1, time: 60000 });

        msgCollector.on("collect", async (msg) => {
          let adDescription = msg.content
            .replace(/https?:\/\/[^\s]+/g, '')
            .replace(/<@!?[0-9]+>/g, '')
            .replace(/@everyone/g, '')
            .replace(/@here/g, '');

          await interaction.channel.send("**ارسل الآن رابط السيرفر**");

          const linkCollector = interaction.channel.createMessageCollector({ filter: msgFilter, max: 1, time: 60000 });

          linkCollector.on("collect", async (linkMsg) => {
            const adChannel = interaction.guild.channels.cache.get(channelad);

            if (!adChannel) return interaction.channel.send("ما لقيت روم الإعلانات!");

            await adChannel.send(`**${adDescription.trim()}**\n\n${linkMsg.content}\n${sMention}`);
            await adChannel.send(line)

            await interaction.channel.send("**تم نشر الإعلان بنجاح سيتم حذف التذكرة خلال 5 ثواني**");
            setTimeout(() => {
              activeTickets.delete(interaction.user.id);
              interaction.channel.delete().catch(() => {});
            }, 5000);
          });

          linkCollector.on("end", (collected) => {
            if (collected.size === 0) {
              interaction.channel.send("**انتهى الوقت ولم يتم إرسال الرابط**");
            }
          });
        });

        msgCollector.on("end", (collected) => {
          if (collected.size === 0) {
            interaction.channel.send("**انتهى الوقت ولم يتم إرسال الوصف**");
          }
        });

        userAds.delete(interaction.user.id);
        collector.stop();
      });

      collector.on("end", async (collected) => {
        if (collected.size === 0) {
          await interaction.channel.send({ content: `**لم يتم تحويل المبلغ في الوقت المحدد**` });
        }
      });
    }

    if (interaction.customId === "copybtn") {
      const { sPrice } = userAds.get(interaction.user.id);
      const tax = Math.floor(sPrice * (20 / 19) + 1);
      await interaction.reply({ content: `#credit ${idbank} ${tax}`, ephemeral: true });
    }
  }
});