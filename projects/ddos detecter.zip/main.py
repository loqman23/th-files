#!/usr/bin/env python3
import requests
import time
import random
import argparse
import sys
from datetime import datetime

def check_website(url, proxy=None, timeout=5):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    try:
        start_time = time.time()
        response = requests.get(url, proxies=proxy, timeout=timeout, headers=headers)
        response_time = time.time() - start_time
        return response.status_code, response_time
    except requests.exceptions.RequestException as e:
        print(f"Request error: {e}")
        return None, None

def log_event(message, alert=False):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if alert:
        print(f"\n[!] {timestamp} - ALERT: {message}\n")
    else:
        print(f"[+] {timestamp} - {message}")

def main():
    parser = argparse.ArgumentParser(description="DDoS Detection Tool")
    parser.add_argument("url", help="Target website URL")
    parser.add_argument("--interval", type=int, default=10, help="Interval between checks in seconds")
    parser.add_argument("--timeout", type=int, default=5, help="Request timeout in seconds")
    parser.add_argument("--failures", type=int, default=3, help="Consecutive failures to trigger alert ")
    parser.add_argument("--proxies", nargs="*", help="List of proxy URLs")
    parser.add_argument("--output", type=str, help="Output file to save logs")
    args = parser.parse_args()

    if not args.url.startswith(('http://', 'https://')):
        args.url = 'http://' + args.url
        print(f"URL protocol not specified, using: {args.url}")

    target_url = args.url
    check_interval = max(1, args.interval)
    timeout = max(1, args.timeout)
    consecutive_failures_threshold = max(1, args.failures)
    
    proxies = []
    if args.proxies:
        for p in args.proxies:
            if '://' not in p:
                p = 'http://' + p
            proxies.append({"http": p, "https": p})
    
    if not proxies:
        proxies = [None]

    output_file = None
    if args.output:
        try:
            output_file = open(args.output, 'a')
            output_file.write(f"\n--- DDoS Detection Tool Started at {datetime.now()} ---\n")
            output_file.write(f"Target: {target_url}\n")
        except IOError as e:
            print(f"Error opening output file: {e}")
            output_file = None

    print("\n" + "="*60)
    print(" DDoS Detection Tool")
    print("="*60)
    print(f" Target URL: {target_url}")
    print(f" Check Interval: {check_interval} seconds")
    print(f" Request Timeout: {timeout} seconds")
    print(f" Alert Threshold: {consecutive_failures_threshold} consecutive failures")
    print(f" Proxies: {'Yes' if len(proxies) > 1 or proxies[0] is not None else 'No'}")
    print("="*60 + "\n")

    failure_count = 0
    total_checks = 0
    successful_checks = 0
    baseline_response_time = None

    try:
        print("Performing initial check to establish baseline...")
        status, response_time = check_website(target_url, None, timeout)
        if status and 200 <= status < 400 and response_time:
            baseline_response_time = response_time
            print(f"Baseline response time: {baseline_response_time:.4f} seconds")
        else:
            print("Warning: Could not establish baseline. Target may be unavailable.")

        while True:
            proxy = random.choice(proxies)
            proxy_info = list(proxy.values())[0] if proxy else "direct connection"
            
            print(f"\nChecking {target_url} via {proxy_info}...")
            status, response_time = check_website(target_url, proxy, timeout)
            total_checks += 1
            
            if status is None:
                message = f"Connection failed - no response"
                failure_count += 1
            elif status >= 500:
                message = f"Server error - HTTP {status}, response time: {response_time:.4f}s"
                failure_count += 1
            elif response_time and response_time > timeout:
                message = f"Slow response - HTTP {status}, response time: {response_time:.4f}s (exceeds {timeout}s timeout)"
                failure_count += 1
            else:
                successful_checks += 1
                message = f"Success - HTTP {status}, response time: {response_time:.4f}s"
                if baseline_response_time and response_time > (baseline_response_time * 3):
                    message += f" (warning: {response_time/baseline_response_time:.1f}x slower than baseline)"
                    failure_count += 1
                else:
                    failure_count = 0
            
            log_event(message)
            
            if output_file:
                output_file.write(f"{datetime.now()} - {message}\n")
                output_file.flush()
            
            if failure_count >= consecutive_failures_threshold:
                alert_msg = f"Possible DDoS attack detected! {failure_count} consecutive failures"
                log_event(alert_msg, alert=True)
                if output_file:
                    output_file.write(f"{datetime.now()} - ALERT: {alert_msg}\n")
                    output_file.flush()
                failure_count = 0
            
            success_rate = (successful_checks / total_checks) * 100 if total_checks > 0 else 0
            print(f"Stats: {successful_checks}/{total_checks} successful checks ({success_rate:.1f}%)")
            time.sleep(check_interval)

    except KeyboardInterrupt:
        print("\nMonitoring stopped by user.")
    finally:
        if output_file:
            output_file.write(f"\n--- DDoS Detection Tool Stopped at {datetime.now()} ---\n")
            output_file.close()
        print("\nMonitoring ended.")

if __name__ == "__main__":
    main()