const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const express = require('express');
const fs = require('fs');
const config = require('./config.js');
const app = express();
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates
  ]
});

app.use(express.static('public'));
app.use(express.json());

const statsFile = 'memberStats.json';
const warnsFile = 'warns.json';
let memberStats = new Map();
let warnCount = new Map();
let copyrightWarnings = 0;

if (fs.existsSync(statsFile)) {
  const data = fs.readFileSync(statsFile);
  const parsed = JSON.parse(data);
  for (const [key, value] of Object.entries(parsed)) {
    memberStats.set(key, value);
  }
} else {
  fs.writeFileSync(statsFile, JSON.stringify({}));
}

if (fs.existsSync(warnsFile)) {
  const data = fs.readFileSync(warnsFile);
  const parsed = JSON.parse(data);
  for (const [key, value] of Object.entries(parsed)) {
    warnCount.set(key, value);
  }
} else {
  fs.writeFileSync(warnsFile, JSON.stringify({}));
}

client.once('ready', async () => {
  console.log('البوت جاهز!');
  console.log('السيرفرات التي يتواجد فيها البوت:');
  client.guilds.cache.forEach(guild => {
    console.log(`- ${guild.name} (ID: ${guild.id})`);
  });

  let guild = client.guilds.cache.get(config.guildId);
  if (!guild) {
    console.log(`السيرفر بـ ID ${config.guildId} غير موجود في الـ cache، جاري المحاولة لجلبه...`);
    try {
      guild = await client.guilds.fetch(config.guildId);
      console.log(`تم جلب السيرفر: ${guild.name}`);
    } catch (error) {
      console.error('فشل في جلب السيرفر، تأكد من الـ Guild ID أو التوكن:', error);
      return;
    }
  }

  const supportRole = guild.roles.cache.get(config.supportRoleId);
  if (!supportRole) console.error('رتبة دعم فني غير موجودة، تأكد من الـ Support Role ID');
  else console.log(`رتبة دعم فني موجودة: ${supportRole.name}`);
});

client.on('messageCreate', message => {
  if (message.author.bot || !message.guild) return;
  const memberId = message.author.id;
  const wordCount = message.content.split(' ').length;
  const stats = memberStats.get(memberId) || { messages: 0, words: 0, voiceTime: 0, invitedToVoice: 0, lastReset: null, joinedAt: null };
  stats.messages += 1;
  stats.words += wordCount;
  if (!stats.joinedAt) stats.joinedAt = message.member.joinedTimestamp;
  memberStats.set(memberId, stats);
  saveStats();
});

client.on('voiceStateUpdate', (oldState, newState) => {
  const memberId = newState.member?.id;
  if (!memberId || newState.member.user.bot) return;
  const stats = memberStats.get(memberId) || { messages: 0, words: 0, voiceTime: 0, invitedToVoice: 0, lastReset: null, joinedAt: null };
  
  if (!oldState.channel && newState.channel) {
    stats.voiceStart = Date.now();
    if (newState.channel.members.size > 1) stats.invitedToVoice += newState.channel.members.size - 1;
  } else if (oldState.channel && !newState.channel) {
    const timeSpent = (Date.now() - stats.voiceStart) / 60000;
    stats.voiceTime += timeSpent;
    delete stats.voiceStart;
  }
  if (!stats.joinedAt) stats.joinedAt = newState.member.joinedTimestamp;
  memberStats.set(memberId, stats);
  saveStats();
});

function saveStats() {
  const data = Object.fromEntries(memberStats);
  fs.writeFileSync(statsFile, JSON.stringify(data, null, 2));
}

function saveWarns() {
  const data = Object.fromEntries(warnCount);
  fs.writeFileSync(warnsFile, JSON.stringify(data, null, 2));
}

app.get('/api/members', async (req, res) => {
  let guild = client.guilds.cache.get(config.guildId);
  if (!guild) {
    try {
      guild = await client.guilds.fetch(config.guildId);
    } catch (error) {
      return res.status(500).json({ error: 'السيرفر غير موجود، تأكد من الـ Guild ID' });
    }
  }

  const supportRole = guild.roles.cache.get(config.supportRoleId);
  if (!supportRole) return res.status(500).json({ error: 'رتبة دعم فني غير موجودة' });

  const members = guild.members.cache
    .filter(m => !m.user.bot && m.roles.cache.has(supportRole.id))
    .map(m => ({
      id: m.id,
      username: m.user.username,
      avatar: m.user.displayAvatarURL(),
      stats: memberStats.get(m.id) || { messages: 0, words: 0, voiceTime: 0, invitedToVoice: 0, lastReset: null, joinedAt: m.joinedTimestamp }
    }));
  res.json(members);
});

app.get('/api/member/:id', async (req, res) => {
  let guild = client.guilds.cache.get(config.guildId);
  if (!guild) {
    try {
      guild = await client.guilds.fetch(config.guildId);
    } catch (error) {
      return res.status(500).json({ error: 'السيرفر غير موجود' });
    }
  }

  const member = guild.members.cache.get(req.params.id);
  if (!member || member.user.bot) return res.status(404).json({ error: 'العضو غير موجود أو بوت' });

  const stats = memberStats.get(member.id) || { messages: 0, words: 0, voiceTime: 0, invitedToVoice: 0, lastReset: null, joinedAt: member.joinedTimestamp };
  res.json({
    id: member.id,
    username: member.user.username,
    messages: stats.messages,
    words: stats.words,
    voiceTime: stats.voiceTime.toFixed(2),
    invitedToVoice: stats.invitedToVoice,
    lastReset: stats.lastReset,
    joinedAt: stats.joinedAt,
    roles: member.roles.cache.map(r => r.name),
    allRoles: guild.roles.cache.map(r => r.name),
    warns: warnCount.get(member.id) || 0
  });
});

// API للترقية
app.post('/api/promote', async (req, res) => {
  const { memberId, roleToAdd, roleToRemove, reason } = req.body;
  const guild = client.guilds.cache.get(config.guildId) || await client.guilds.fetch(config.guildId);
  if (!guild) return res.status(500).json({ error: 'السيرفر غير موجود' });

  const member = guild.members.cache.get(memberId);
  if (!member) return res.status(404).json({ error: 'العضو غير موجود' });

  const addRole = guild.roles.cache.find(r => r.name === roleToAdd);
  const removeRole = guild.roles.cache.find(r => r.name === roleToRemove);
  if (!addRole || !removeRole) return res.status(400).json({ error: 'الرتبة غير موجودة' });

  await member.roles.remove(removeRole);
  await member.roles.add(addRole);
  const time = new Date().toLocaleTimeString('ar-EG');
  const embed = new EmbedBuilder()
    .setColor('#00ccff')
    .setTitle('ترقية')
    .setDescription(`تم ترقيتك من رتبة **${removeRole.name}** إلى رتبة **${addRole.name}**`)
    .addFields(
      { name: 'السبب', value: reason || 'غير محدد', inline: true },
      { name: 'الوقت', value: time, inline: true }
    )
    .setTimestamp();
  member.user.send({ embeds: [embed] })
    .catch(err => console.log(`لا يمكن إرسال رسالة لـ ${member.user.tag}`));
  res.json({ success: true, log: `ترقية ${member.user.username} إلى ${roleToAdd} - ${time}` });
});

// API للتنزيل
app.post('/api/demote', async (req, res) => {
  const { memberId, roleToAdd, roleToRemove, reason } = req.body;
  if (!reason) return res.status(400).json({ error: 'السبب إجباري للتنزيل' });

  const guild = client.guilds.cache.get(config.guildId) || await client.guilds.fetch(config.guildId);
  if (!guild) return res.status(500).json({ error: 'السيرفر غير موجود' });

  const member = guild.members.cache.get(memberId);
  if (!member) return res.status(404).json({ error: 'العضو غير موجود' });

  const addRole = guild.roles.cache.find(r => r.name === roleToAdd);
  const removeRole = guild.roles.cache.find(r => r.name === roleToRemove);
  if (!addRole || !removeRole) return res.status(400).json({ error: 'الرتبة غير موجودة' });

  await member.roles.remove(removeRole);
  await member.roles.add(addRole);
  const time = new Date().toLocaleTimeString('ar-EG');
  const embed = new EmbedBuilder()
    .setColor('#ff4444')
    .setTitle('تنزيل')
    .setDescription(`تم تنزيلك من رتبة **${removeRole.name}** إلى رتبة **${addRole.name}**`)
    .addFields(
      { name: 'السبب', value: reason, inline: true },
      { name: 'الوقت', value: time, inline: true }
    )
    .setTimestamp();
  member.user.send({ embeds: [embed] })
    .catch(err => console.log(`لا يمكن إرسال رسالة لـ ${member.user.tag}`));
  res.json({ success: true, log: `تنزيل ${member.user.username} إلى ${roleToAdd} - السبب: ${reason} - ${time}` });
});

app.post('/api/warn', async (req, res) => {
  const { memberId, reason } = req.body;
  if (!reason) return res.status(400).json({ error: 'السبب إجباري للتحذير' });

  const member = client.users.cache.get(memberId);
  if (!member) return res.status(404).json({ error: 'العضو غير موجود' });

  const warns = (warnCount.get(memberId) || 0) + 1;
  warnCount.set(memberId, warns);
  saveWarns();

  const time = new Date().toLocaleTimeString('ar-EG');
  const embed = new EmbedBuilder()
    .setColor('#ffaa00')
    .setTitle('تحذير')
    .setDescription(`لقد تلقيت تحذيرًا من الإدارة`)
    .addFields(
      { name: 'السبب', value: reason, inline: true },
      { name: 'عدد التحذيرات', value: `${warns}`, inline: true },
      { name: 'الوقت', value: time, inline: true }
    )
    .setTimestamp();
  await member.send({ embeds: [embed] })
    .catch(err => console.log(`لا يمكن إرسال رسالة لـ ${member.tag}`));
  res.json({ success: true, log: `تحذير ${member.username} - السبب: ${reason} - ${time}` });
});

// API لإعادة التهيئة (ريستارت)
app.post('/api/restart', async (req, res) => {
  const guild = client.guilds.cache.get(config.guildId) || await client.guilds.fetch(config.guildId);
  if (!guild) return res.status(500).json({ error: 'السيرفر غير موجود' });

  const supportRole = guild.roles.cache.get(config.supportRoleId);
  if (!supportRole) return res.status(500).json({ error: 'رتبة دعم فني غير موجودة' });

  guild.members.cache
    .filter(m => !m.user.bot && m.roles.cache.has(supportRole.id))
    .forEach(m => {
      const stats = memberStats.get(m.id) || { messages: 0, words: 0, voiceTime: 0, invitedToVoice: 0, lastReset: null, joinedAt: m.joinedTimestamp };
      stats.messages = 0;
      stats.words = 0;
      stats.voiceTime = 0;
      stats.invitedToVoice = 0;
      stats.lastReset = Date.now();
      memberStats.set(m.id, stats);
    });
  saveStats();
  const time = new Date().toLocaleTimeString('ar-EG');
  res.json({ success: true, log: `تم إعادة تهيئة بيانات دعم فني - ${time}` });
});

app.get('/api/check-copyright', async (req, res) => {
  res.json({ copyright: 'h_4s' });
});

// معالجة تغيير الحقوق
async function handleCopyrightViolation() {
  const guild = client.guilds.cache.get(config.guildId) || await client.guilds.fetch(config.guildId);
  if (!guild) return;

  const owner = await client.users.fetch(config.ownerId);
  const hiddenChannel = guild.channels.cache.find(ch => ch.type === 'GUILD_TEXT' && !ch.permissionsFor(guild.roles.everyone).has('VIEW_CHANNEL'));

  const embed = new EmbedBuilder()
    .setColor('#ff0000')
    .setTitle('تحذير: تغيير الحقوق')
    .setDescription(`<@${config.ownerId}>، لقد تم تغيير حقوق "h_4s" في الواجهة! هذا تحذير، لو وصلت لـ 5، هيرجع الحقوق تلقائيًا أو هيتوقف البوت.`)
    .setTimestamp();

  if (hiddenChannel) {
    for (let i = 0; i < 5; i++) {
      await hiddenChannel.send({ content: `<@${config.ownerId}>`, embeds: [embed] }).catch(() => {});
      await new Promise(resolve => setTimeout(resolve, 1000)); // تأخير 1 ثانية بين كل منشن
    }
  } else {
    for (let i = 0; i < 5; i++) {
      await owner.send({ content: `<@${config.ownerId}>`, embeds: [embed] }).catch(() => {});
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  copyrightWarnings++;
  if (copyrightWarnings >= 5) {
    console.log('تم الوصول لـ 5 تحذيرات، جاري إرجاع الحقوق...');
  
  }
}

app.post('/api/copyright-violation', (req, res) => {
  handleCopyrightViolation();
  res.json({ status: 'violation detected', warnings: copyrightWarnings });
});

// API للحصول على جميع أعضاء السيرفر
app.get('/api/all-members', async (req, res) => {
  let guild = client.guilds.cache.get(config.guildId);
  if (!guild) {
    try {
      guild = await client.guilds.fetch(config.guildId);
    } catch (error) {
      return res.status(500).json({ error: 'السيرفر غير موجود، تأكد من الـ Guild ID' });
    }
  }

  try {
    await guild.members.fetch();
    const members = guild.members.cache
      .filter(m => !m.user.bot)
      .map(m => ({
        id: m.id,
        username: m.user.username,
        avatar: m.user.displayAvatarURL(),
        joinedAt: m.joinedTimestamp,
        roles: m.roles.cache.map(r => r.name).filter(name => name !== '@everyone')
      }));
    res.json(members);
  } catch (error) {
    console.error('Error fetching members:', error);
    res.status(500).json({ error: 'حدث خطأ في جلب الأعضاء' });
  }
});

// API لحظر عضو
app.post('/api/ban', async (req, res) => {
  const { memberId, reason } = req.body;
  if (!reason) return res.status(400).json({ error: 'السبب إجباري للحظر' });

  let guild = client.guilds.cache.get(config.guildId);
  if (!guild) {
    try {
      guild = await client.guilds.fetch(config.guildId);
    } catch (error) {
      return res.status(500).json({ error: 'السيرفر غير موجود' });
    }
  }

  const member = guild.members.cache.get(memberId);
  if (!member) return res.status(404).json({ error: 'العضو غير موجود' });

  try {
    await member.ban({ reason });
    const time = new Date().toLocaleTimeString('ar-EG');
    const embed = new EmbedBuilder()
      .setColor('#000000')
      .setTitle('حظر من السيرفر')
      .setDescription(`تم حظرك من السيرفر`)
      .addFields(
        { name: 'السبب', value: reason, inline: true },
        { name: 'الوقت', value: time, inline: true }
      )
      .setTimestamp();
    
    // محاولة إرسال رسالة للعضو قبل الحظر (قد لا تنجح دائمًا)
    try {
      await member.user.send({ embeds: [embed] });
    } catch (err) {
      console.log(`لا يمكن إرسال رسالة لـ ${member.user.tag}`);
    }
    
    res.json({ success: true, message: `تم حظر العضو ${member.user.username} بنجاح` });
  } catch (error) {
    console.error('Error banning member:', error);
    res.status(500).json({ error: 'حدث خطأ في حظر العضو. تأكد من صلاحياتك.' });
  }
});

app.listen(config.port, () => {
  console.log(`الداشبورد شغال على http://localhost:${config.port}`);
});

client.login(config.token);