module.exports = {
  token: 'MTM1Nzg4NzM3ODI3NDEyMzg0Nw.G9PgTv.Fh60xX8CSPY0oV6RYm7b2feKiizKHZzc9qK4qQ', // ضع توكن البوت هنا
  port: 3000, // البورت اللي هيشتغل عليه الداشبورد
  guildId: '1352932662599487559', // ضع معرف السيرفر (Guild ID) هنا
  supportRoleId: '1352982284445417513', // ضع معرف رتبة "دعم فني" هنا
  ownerId: '1268617577387786281' // معرف صاحب البوت (كليك يمين على حسابك في ديسكورد -> نسخ المعرف)
};