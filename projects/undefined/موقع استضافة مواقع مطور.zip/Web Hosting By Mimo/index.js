const express = require('express');

const fs = require('fs');

const path = require('path');

const app = express();

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

const SITES_DIR = path.join(__dirname, 'sites');

if (!fs.existsSync(SITES_DIR)) {

    fs.mkdirSync(SITES_DIR);

}

app.post('/save-site', (req, res) => {

    const { id, name, customUrl, html, user } = req.body;

    

    if (customUrl && !/^[a-zA-Z0-9-]+$/.test(customUrl)) {

        return res.status(400).json({ 

            success: false, 

            message: 'يمكن استخدام الأحرف الإنجليزية والأرقام والشرطة فقط في الرابط المخصص'

        });

    }

    if (customUrl) {

        const customUrlPath = path.join(SITES_DIR, `${customUrl}.html`);

        if (fs.existsSync(customUrlPath)) {

            return res.status(400).json({ 

                success: false, 

                message: 'هذا الرابط مستخدم بالفعل'

            });

        }

    }

    const siteData = {

        id,

        name,

        customUrl,

        html,

        user,

        createdAt: new Date().toISOString()

    };

    const sitePath = path.join(SITES_DIR, `${id}.json`);

    fs.writeFileSync(sitePath, JSON.stringify(siteData, null, 2));

    const htmlPath = path.join(SITES_DIR, `${id}.html`);

    fs.writeFileSync(htmlPath, html);

    if (customUrl) {

        const customHtmlPath = path.join(SITES_DIR, `${customUrl}.html`);

        fs.writeFileSync(customHtmlPath, html);

    }

    res.json({ 

        success: true, 

        siteId: id,

        message: 'تم حفظ الموقع بنجاح'

    });

});

app.get('/get-sites', (req, res) => {

    const user = req.query.user;

    const sites = [];

    if (!fs.existsSync(SITES_DIR)) {

        return res.json([]);

    }

    fs.readdirSync(SITES_DIR).forEach(file => {

        if (file.endsWith('.json')) {

            try {

                const siteData = JSON.parse(fs.readFileSync(path.join(SITES_DIR, file)));

                if (siteData.user === user) {

                    sites.push(siteData);

                }

            } catch (error) {

                console.error('Error reading site file:', file, error);

            }

        }

    });

    sites.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    res.json(sites);

});

app.get('/get-site/:id', (req, res) => {

    const siteId = req.params.id;

    const sitePath = path.join(SITES_DIR, `${siteId}.json`);

    if (fs.existsSync(sitePath)) {

        const siteData = JSON.parse(fs.readFileSync(sitePath));

        res.json(siteData);

    } else {

        res.status(404).json({ 

            error: 'الموقع غير موجود'

        });

    }

});

app.get('/site/:id', (req, res) => {

    const id = req.params.id;

    let filePath = path.join(SITES_DIR, `${id}.html`);

    if (!fs.existsSync(filePath)) {

        filePath = path.join(SITES_DIR, `${id}.html`);

    }

    if (fs.existsSync(filePath)) {

        res.sendFile(filePath);

    } else {

        res.status(404).send(`

            <!DOCTYPE html>

            <html>

            <head>

                <title>الموقع غير موجود</title>

                <style>

                    body { 

                        font-family: Arial, sans-serif; 

                        text-align: center; 

                        padding: 50px; 

                        background: #f5f7fa;

                    }

                    h1 { color: #6C5CE7; }

                </style>

            </head>

            <body>

                <h1>الموقع غير موجود</h1>

                <p>قد يكون الرابط خاطئاً أو تم حذف الموقع</p>

            </body>

            </html>

        `);

    }

});

app.get('/site-preview/:id', (req, res) => {

    const id = req.params.id;

    const sitePath = path.join(SITES_DIR, `${id}.json`);

    if (fs.existsSync(sitePath)) {

        const siteData = JSON.parse(fs.readFileSync(sitePath));

        res.send(siteData.html);

    } else {

        res.status(404).send('الموقع غير موجود');

    }

});

app.delete('/delete-site/:id', (req, res) => {

    const siteId = req.params.id;

    const sitePath = path.join(SITES_DIR, `${siteId}.json`);

    const htmlPath = path.join(SITES_DIR, `${siteId}.html`);

    if (fs.existsSync(sitePath)) {

        try {

            const siteData = JSON.parse(fs.readFileSync(sitePath));

            

            fs.unlinkSync(sitePath);

            

            if (fs.existsSync(htmlPath)) {

                fs.unlinkSync(htmlPath);

            }

            if (siteData.customUrl) {

                const customHtmlPath = path.join(SITES_DIR, `${siteData.customUrl}.html`);

                if (fs.existsSync(customHtmlPath)) {

                    fs.unlinkSync(customHtmlPath);

                }

            }

            res.json({ 

                success: true,

                message: 'تم حذف الموقع بنجاح'

            });

        } catch (error) {

            res.status(500).json({ 

                success: false,

                error: 'حدث خطأ أثناء حذف الموقع'

            });

        }

    } else {

        res.status(404).json({ 

            success: false,

            error: 'الموقع غير موجود'

        });

    }

});

const PORT = process.env.PORT || 3000; // بورت هنا

app.listen(PORT, () => {

    console.log(`Server online`);

});