const { Intents, Collection, Client, GuildMember, MessageActionRow, WebhookClient,MessagePayload, GatewayIntentBits, MessageSelectMenu, Modal, MessageEmbed,MessageButton, MessageAttachment, Permissions, TextInputComponent} = require('discord.js');
const { client, db , settings} = require('../../index');
const { createEmbed  } = require('../../function/function/Embed');


client.on('messageCreate', async msg => {
  if (msg.author.bot) return
  if (msg.content == settings.prefix + `helpe`){
    if (!msg.member.roles.cache.has(settings.Admins.DiscordStaff)) return

    const embed = createEmbed({
       interaction : msg , 
       title : 'مساعد الادارة الذكي', 
       description : `ازيك ي ${msg.author} , ازاي اقدر اساعدك ؟`, 
    })

    const row = new MessageActionRow()
    .addComponents(
      new MessageSelectMenu()
      .setCustomId('Last_Helpe')
      .setPlaceholder(`${msg.author.displayName} محتاج مساعدة ؟`)
      .addOptions([
        {
        label: 'اضافه شخص للتذكرة',
        value: 'اضافه شخص للتذكرة',
        }, 
        {
        label: 'ازاله شخص من التذكرة',
        value: 'ازاله شخص من التذكرة',
        },
        {
         label: 'تغيير اسم التذكره',
         value: 'تغيير اسم التذكره',
        },
       

      ]),
    );
    const but = new MessageActionRow().addComponents(
      new MessageButton()
          .setCustomId('CancelButton')
          .setLabel('الغاء العملية ؟')
          .setStyle('DANGER')
  )
    await msg.reply({embeds : [embed], components : [row,but]})

  }
})
