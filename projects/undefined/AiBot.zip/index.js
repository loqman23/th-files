import { Client, GatewayIntentBits } from 'discord.js';
import OpenAI from 'openai';
import dotenv from 'dotenv';
dotenv.config();

// 1. الإعدادات الأساسية
const config = {
    targetChannelId: '1360534944434356304', // ضع أي دي القناة المطلوبة هنا
    botName: 'Enzo-Ai',
    commandPrefix: '!ai',
    maxResponseLength: 1900,
    thinkingMessage: '🔮 جاري المعالجة...',
    historyLimit: 5, // عدد الرسائل في المحادثة التي يجب حفظها
};

// 2. تهيئة عميل Discord
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.GuildMessageReactions
    ]
});

// 3. تهيئة OpenAI مع OpenRouter
const openai = new OpenAI({
    baseURL: "https://openrouter.ai/api/v1",
    apiKey: process.env.OPENROUTER_API_KEY,
    defaultHeaders: {
        "HTTP-Referer": "https://your-bot-domain.com", // أدخل رابط الموقع الخاص بك هنا
        "X-Title": config.botName,
        "Content-Type": "application/json"
    }
});

// 4. ذاكرة المحادثة
const conversationHistory = new Map();

// 5. أحداث البوت
client.on('ready', () => {
    console.log(`✅ ${client.user.tag} يعمل في القناة ${config.targetChannelId}`);
    client.user.setActivity(`اسألني أي شيء`);
});

client.on('messageCreate', async (message) => {
    // تجاهل إذا كان:
    // - الرسالة من بوت آخر
    // - ليست في القناة المحددة
    if (message.author.bot || message.channelId !== config.targetChannelId) return;

    // تحديد إذا كانت رسالة عادية أو رد
    const isReply = message.reference?.messageId;
    const isMentioned = message.mentions.has(client.user.id);
    const isCommand = message.content.startsWith(config.commandPrefix);

    // إذا لم تكن أي من الحالات المطلوبة
    if (!isReply && !isMentioned && !isCommand) return;

    try {
        // إرسال حالة "يكتب..."
        await message.channel.sendTyping();

        // جلب سياق المحادثة إذا كان رداً
        let context = [];
        if (isReply) {
            const repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
            if (repliedMessage.author.id === client.user.id) {
                context.push({
                    role: "assistant",
                    content: repliedMessage.content
                });
            }
        }

        // إعداد المحتوى
        let prompt = message.content;
        if (isCommand) prompt = message.content.slice(config.commandPrefix.length).trim();
        if (isMentioned) prompt = message.content.replace(`<@${client.user.id}>`, '').trim();

        if (!prompt) return message.reply("🚀 الرجاء إدخال سؤال أو استفسار");

        // تحديث تاريخ المحادثة
        if (!conversationHistory.has(message.author.id)) {
            conversationHistory.set(message.author.id, []);
        }
        const messages = conversationHistory.get(message.author.id);
        messages.push({ role: "user", content: prompt });

        // إرسال الطلب إلى OpenAI (OpenRouter) مع التكوين الجديد
        const completion = await openai.chat.completions.create({
            model: "deepseek/deepseek-chat:free", // استخدم الموديل المطلوب
            messages: [
                {
                    role: "system",
                    content: "انت Enzo-Ai + أنت مساعد عربي متخصص. أجب بدقة ووضوح + صانعك اينزو اسمه."
                },
                ...messages.slice(-config.historyLimit) // الحفاظ على المحادثة
            ],
            temperature: 0.7,
            max_tokens: 2000
        });

        // التحقق من الرد
        if (!completion.choices || completion.choices.length === 0) {
            return message.reply("⚠️ لم يتم الحصول على رد من OpenAI.");
        }

        // معالجة الرد
        const aiResponse = completion.choices[0].message.content;
        messages.push({ role: "assistant", content: aiResponse });

        // إرسال الرد مع التعامل مع الرسائل الطويلة
        if (aiResponse.length > config.maxResponseLength) {
            const chunks = [];
            for (let i = 0; i < aiResponse.length; i += config.maxResponseLength) {
                chunks.push(aiResponse.substring(i, i + config.maxResponseLength));
            }
            for (const chunk of chunks) {
                await message.reply(chunk);
                await new Promise(resolve => setTimeout(resolve, 500)); // تأخير بين الأجزاء
            }
        } else {
            await message.reply(aiResponse);
        }

    } catch (error) {
        console.error('❌ خطأ:', error);

        // تحسين التحقق من الأخطاء
        let errorMsg = "⚠️ حدث خطأ أثناء معالجة طلبك";
        if (error.response?.status === 429) {
            errorMsg += " (تم تجاوز الحد المسموح من الطلبات)";
        } else if (error.message.includes("authentication")) {
            errorMsg += " (مشكلة في مصادقة API)";
        } else if (error.message.includes("timeout")) {
            errorMsg += " (تجاوز وقت الاستجابة)";
        }
        
        await message.reply(errorMsg);
    }
});

// 6. تشغيل البوت
client.login(process.env.DISCORD_TOKEN)
    .then(() => console.log('🔗 متصل بـ Discord بنجاح'))
    .catch(err => console.error('❌ فشل الاتصال:', err));