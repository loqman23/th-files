const { getUserStreak, updateUserStreak, isBlacklisted } = require('./database');
const config = require('../config.json');

// Check if user can post (cooldown)
function canUserPost(userId) {
  const userData = getUserStreak(userId);
  
  if (isBlacklisted(userId)) {
    return { canPost: false, reason: 'blacklisted' };
  }
  
  if (!userData.lastUpdate) {
    return { canPost: true };
  }
  
  const now = Date.now();
  const lastUpdate = new Date(userData.lastUpdate).getTime();
  const hoursPassed = (now - lastUpdate) / (1000 * 60 * 60);
  
  // Check if cooldown hours have passed since last post
  if (hoursPassed < config.cooldownHours) {
    const remainingTime = Math.ceil((config.cooldownHours - hoursPassed) * 60);
    return { 
      canPost: false, 
      reason: 'cooldown', 
      remainingMinutes: remainingTime 
    };
  }
  
  // Check if user has reached daily limit
  const today = new Date().toDateString();
  const postsToday = userData.postsToday || 0;
  const lastPostDay = userData.lastPostDay || '';
  
  if (today === lastPostDay && postsToday >= config.dailyLimit) {
    return { canPost: false, reason: 'dailyLimit' };
  }
  
  return { canPost: true };
}

// Update user streak when they post
function handleUserPost(userId) {
  const userData = getUserStreak(userId);
  const now = new Date();
  const today = now.toDateString();
  
  // Reset posts count if it's a new day
  if (userData.lastPostDay !== today) {
    userData.postsToday = 1;
  } else {
    userData.postsToday = (userData.postsToday || 0) + 1;
  }
  
  userData.lastPostDay = today;
  userData.lastUpdate = now.toISOString();
  userData.totalPosts = (userData.totalPosts || 0) + 1;
  
  // Check if streak should be incremented
  const lastPostDate = userData.lastPostDate ? new Date(userData.lastPostDate) : null;
  
  if (!lastPostDate) {
    // First post ever
    userData.streak = 1;
  } else {
    const lastPostDay = lastPostDate.toDateString();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayString = yesterday.toDateString();
    
    if (today === lastPostDay) {
      // Already posted today, streak stays the same
    } else if (yesterdayString === lastPostDay) {
      // Posted yesterday, increment streak
      userData.streak += 1;
    } else {
      // Missed a day, reset streak
      userData.streak = 1;
    }
  }
  
  userData.lastPostDate = now.toISOString();
  
  return updateUserStreak(userId, userData);
}

module.exports = {
  canUserPost,
  handleUserPost
};