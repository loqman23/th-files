const fs = require('fs');
const path = require('path');
const dbDir = path.join(__dirname, '..', 'database');
const dbPath = path.join(dbDir, 'streaks.json');

// Make sure the database directory exists
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// Initialize database if it doesn't exist
if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, JSON.stringify({
    users: {},
    blacklist: []
  }));
}

// Load database
function loadDatabase() {
  try {
    const data = fs.readFileSync(dbPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error loading database:', error);
    return { users: {}, blacklist: [] };
  }
}

// Save database
function saveDatabase(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving database:', error);
    return false;
  }
}

// Get user streak data
function getUserStreak(userId) {
  const db = loadDatabase();
  return db.users[userId] || { streak: 0, lastUpdate: null, totalPosts: 0 };
}

// Update user streak
function updateUserStreak(userId, data) {
  const db = loadDatabase();
  db.users[userId] = { ...getUserStreak(userId), ...data };
  return saveDatabase(db);
}

// Reset user streak
function resetUserStreak(userId) {
  const db = loadDatabase();
  if (db.users[userId]) {
    db.users[userId].streak = 0;
    db.users[userId].lastUpdate = null;
  }
  return saveDatabase(db);
}

// Reset all streaks
function resetAllStreaks() {
  const db = loadDatabase();
  for (const userId in db.users) {
    db.users[userId].streak = 0;
    db.users[userId].lastUpdate = null;
  }
  return saveDatabase(db);
}

// Check if user is blacklisted
function isBlacklisted(userId) {
  const db = loadDatabase();
  return db.blacklist.includes(userId);
}

// Add user to blacklist
function addToBlacklist(userId) {
  const db = loadDatabase();
  if (!db.blacklist.includes(userId)) {
    db.blacklist.push(userId);
    saveDatabase(db);
    return true;
  }
  return false;
}

// Remove user from blacklist
function removeFromBlacklist(userId) {
  const db = loadDatabase();
  const index = db.blacklist.indexOf(userId);
  if (index !== -1) {
    db.blacklist.splice(index, 1);
    saveDatabase(db);
    return true;
  }
  return false;
}

// Get top streaks
function getTopStreaks(limit = 10) {
  const db = loadDatabase();
  const users = Object.entries(db.users)
    .map(([userId, data]) => ({ userId, ...data }))
    .sort((a, b) => b.streak - a.streak)
    .slice(0, limit);
  
  return users;
}

module.exports = {
  getUserStreak,
  updateUserStreak,
  resetUserStreak,
  resetAllStreaks,
  isBlacklisted,
  addToBlacklist,
  removeFromBlacklist,
  getTopStreaks
};