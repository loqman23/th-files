const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

// Function to send log to the log channel
function sendLog(client, options) {
  const logChannel = client.channels.cache.get(config.logChannelId);
  if (!logChannel) return;
  
  const embed = new EmbedBuilder()
    .setColor(options.color || config.embedColor)
    .setTitle(options.title || '📝 سجل الستريك')
    .setDescription(options.description)
    .setTimestamp();
  
  if (options.fields) {
    embed.addFields(options.fields);
  }
  
  if (options.author) {
    embed.setAuthor({
      name: options.author.username,
      iconURL: options.author.displayAvatarURL()
    });
  }
  
  if (options.footer) {
    embed.setFooter({ text: options.footer });
  }
  
  logChannel.send({ embeds: [embed] });
}

// Log successful streak post
function logStreakPost(client, user, channelId, streak) {
  sendLog(client, {
    color: '#00FF00',
    title: '🔥 تحديث ستريك',
    description: `قام **${user.tag}** بتحديث الستريك الخاص به إلى **${streak}**`,
    author: user,
    fields: [
      { name: 'القناة', value: `<#${channelId}>`, inline: true },
      { name: 'الوقت', value: new Date().toLocaleString('ar-SA'), inline: true },
      { name: 'الستريك الحالي', value: `${streak}`, inline: true }
    ]
  });
}

// Log failed streak attempt (cooldown)
function logCooldownAttempt(client, user, channelId, remainingMinutes) {
  sendLog(client, {
    color: '#FFA500',
    title: '⏱️ محاولة ستريك (وقت انتظار)',
    description: `حاول **${user.tag}** نشر ستريك ولكن لم يمر الوقت الكافي`,
    author: user,
    fields: [
      { name: 'القناة', value: `<#${channelId}>`, inline: true },
      { name: 'الوقت المتبقي', value: `${remainingMinutes} دقيقة`, inline: true }
    ],
    footer: 'محاولة فاشلة - وقت انتظار'
  });
}

// Log failed streak attempt (daily limit)
function logDailyLimitAttempt(client, user, channelId, limit) {
  sendLog(client, {
    color: '#FF0000',
    title: '🚫 محاولة ستريك (تجاوز الحد اليومي)',
    description: `حاول **${user.tag}** نشر ستريك ولكن تجاوز الحد اليومي`,
    author: user,
    fields: [
      { name: 'القناة', value: `<#${channelId}>`, inline: true },
      { name: 'الحد اليومي', value: `${limit} منشورات`, inline: true }
    ],
    footer: 'محاولة فاشلة - تجاوز الحد اليومي'
  });
}

// Log blacklisted user attempt
function logBlacklistedAttempt(client, user, channelId) {
  sendLog(client, {
    color: '#000000',
    title: '⛔ محاولة ستريك (مستخدم محظور)',
    description: `حاول **${user.tag}** نشر ستريك ولكنه في القائمة السوداء`,
    author: user,
    fields: [
      { name: 'القناة', value: `<#${channelId}>`, inline: true }
    ],
    footer: 'محاولة فاشلة - مستخدم محظور'
  });
}

// Log command usage
function logCommandUsage(client, user, command, args) {
  sendLog(client, {
    color: '#0099FF',
    title: '🔧 استخدام أمر',
    description: `استخدم **${user.tag}** الأمر \`${command}\``,
    author: user,
    fields: [
      { name: 'الأمر', value: `${command}`, inline: true },
      { name: 'المعلمات', value: args.length ? args.join(' ') : 'لا يوجد', inline: true }
    ],
    footer: 'استخدام أمر'
  });
}

module.exports = {
  logStreakPost,
  logCooldownAttempt,
  logDailyLimitAttempt,
  logBlacklistedAttempt,
  logCommandUsage
};