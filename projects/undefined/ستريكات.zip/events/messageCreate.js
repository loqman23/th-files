const { canUserPost, handleUserPost } = require('../utils/streakUtils');
const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');
const { 
  logStreakPost, 
  logCooldownAttempt, 
  logDailyLimitAttempt, 
  logBlacklistedAttempt,
  logCommandUsage
} = require('../utils/logUtils');

module.exports = {
  name: 'messageCreate',
  execute(message) {
    // Ignore bot messages
    if (message.author.bot) return;
    
    // Handle commands
    if (message.content.startsWith(config.prefix)) {
      const args = message.content.slice(config.prefix.length).trim().split(/ +/);
      const commandName = args.shift().toLowerCase();
      
      const command = message.client.commands.get(commandName);
      
      if (!command) return;
      
      try {
        // Log command usage
        logCommandUsage(message.client, message.author, commandName, args);
        
        command.execute(message, args);
      } catch (error) {
        console.error(error);
        message.reply('There was an error executing that command!');
      }
      
      return;
    }
    
    // Check if the message contains an attachment (image or video)
    if (message.attachments.size > 0 || message.content.includes('http')) {
      // Check if this is the streak channel
      if (message.channel.id !== config.streakChannelId) return;
      
      const { canPost, reason, remainingMinutes } = canUserPost(message.author.id);
      
      if (!canPost) {
        if (reason === 'blacklisted') {
          message.reply('أنت محظور من استخدام نظام الستريكات.');
          logBlacklistedAttempt(message.client, message.author, message.channel.id);
        } else if (reason === 'cooldown') {
          message.reply(`يجب الانتظار ${remainingMinutes} دقيقة أخرى قبل النشر مرة أخرى.`);
          logCooldownAttempt(message.client, message.author, message.channel.id, remainingMinutes);
        } else if (reason === 'dailyLimit') {
          message.reply(`لقد وصلت إلى الحد اليومي وهو ${config.dailyLimit} منشورات. حاول مرة أخرى غدًا!`);
          logDailyLimitAttempt(message.client, message.author, message.channel.id, config.dailyLimit);
        }
        return;
      }
      
      // Update user streak
      handleUserPost(message.author.id);
      
      // Get updated user data to show in the response
      const userData = require('../utils/database').getUserStreak(message.author.id);
      
      // Create a beautiful embed to show the streak update
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setAuthor({ 
          name: message.author.username, 
          iconURL: message.author.displayAvatarURL() 
        })
        .setTitle('🔥 تم تحديث الستريك!')
        .setDescription(`الستريك الحالي الخاص بك هو **${userData.streak}**!`)
        .addFields(
          { name: 'إجمالي المنشورات', value: `${userData.totalPosts}`, inline: true },
          { name: 'منشورات اليوم', value: `${userData.postsToday || 1}/${config.dailyLimit}`, inline: true }
        )
        .setFooter({ text: `استمر! يمكنك النشر مرة أخرى بعد ${config.cooldownHours} ساعات.` })
        .setTimestamp();
      
      message.reply({ embeds: [embed] }).then(() => {
        // Check if lineEmoji is a URL or an emoji
        if (config.lineEmoji.startsWith('http')) {
          // It's a URL, send as an image
          message.channel.send({ files: [config.lineEmoji] });
        } else {
          // It's an emoji, repeat it
          message.channel.send(config.lineEmoji.repeat(50));
        }
      });
      
      // Log successful streak post
      logStreakPost(message.client, message.author, message.channel.id, userData.streak);
    }
  },
};