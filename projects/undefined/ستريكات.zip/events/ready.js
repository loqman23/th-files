const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ ${client.user.tag} is online and ready!`);
    
    // Set bot status
    client.user.setPresence({
      activities: [{ 
        name: 'Streak Bot | -help', 
        type: ActivityType.Playing 
      }],
      status: 'online',
    });
    
    console.log(`Bot is serving ${client.guilds.cache.size} servers`);
  },
};