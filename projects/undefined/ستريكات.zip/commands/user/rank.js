const { EmbedBuilder } = require('discord.js');
const { getUserStreak, getTopStreaks } = require('../../utils/database');

module.exports = {
  data: {
    name: 'rank',
    description: 'Check your rank in the streak leaderboard'
  },
  execute(message) {
    const userId = message.mentions.users.first()?.id || message.author.id;
    const userData = getUserStreak(userId);
    const user = message.mentions.users.first() || message.author;
    
    // Get all users and sort by streak
    const topUsers = getTopStreaks();
    
    // Find user rank
    const userRank = topUsers.findIndex(u => u.userId === userId) + 1;
    
    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setAuthor({ 
        name: user.username, 
        iconURL: user.displayAvatarURL() 
      })
      .setTitle('🏆 Streak Rank')
      .setDescription(`**${user.username}** is ranked **#${userRank || 'N/A'}** on the streak leaderboard!`)
      .addFields(
        { name: 'Current Streak', value: `${userData.streak} days`, inline: true },
        { name: 'Total Posts', value: `${userData.totalPosts || 0}`, inline: true }
      )
      .setFooter({ text: 'Keep posting to climb the ranks!' })
      .setTimestamp();
    
    message.reply({ embeds: [embed] });
  }
};