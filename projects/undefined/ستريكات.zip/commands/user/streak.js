const { EmbedBuilder } = require('discord.js');
const { getUserStreak } = require('../../utils/database');

module.exports = {
  data: {
    name: 'streak',
    description: 'Check your current streak'
  },
  execute(message) {
    const userId = message.mentions.users.first()?.id || message.author.id;
    const userData = getUserStreak(userId);
    const user = message.mentions.users.first() || message.author;
    
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setAuthor({ 
        name: user.username, 
        iconURL: user.displayAvatarURL() 
      })
      .setTitle('🔥 Streak Information')
      .addFields(
        { name: 'Current Streak', value: `${userData.streak} days`, inline: true },
        { name: 'Total Posts', value: `${userData.totalPosts || 0}`, inline: true },
        { name: 'Posts Today', value: `${userData.postsToday || 0}/4`, inline: true }
      )
      .setFooter({ text: 'Keep your streak going by posting daily!' })
      .setTimestamp();
    
    message.reply({ embeds: [embed] });
  }
};