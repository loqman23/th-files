const { EmbedBuilder } = require('discord.js');
const { getTopStreaks } = require('../../utils/database');

module.exports = {
  data: {
    name: 'streaktop',
    description: 'View the top 10 users with highest streaks'
  },
  execute(message) {
    const topUsers = getTopStreaks(10);
    
    if (topUsers.length === 0) {
      return message.reply('No streak data available yet!');
    }
    
    let description = '';
    
    for (let i = 0; i < topUsers.length; i++) {
      const user = topUsers[i];
      try {
        const discordUser = message.client.users.cache.get(user.userId) || 
                           { username: 'Unknown User' };
        
        description += `**${i + 1}.** ${discordUser.username} - **${user.streak}** days streak\n`;
      } catch (error) {
        console.error(`Error getting user ${user.userId}:`, error);
        description += `**${i + 1}.** Unknown User - **${user.streak}** days streak\n`;
      }
    }
    
    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle('🏆 Top Streak Leaderboard')
      .setDescription(description)
      .setFooter({ text: 'Keep your streak going to reach the top!' })
      .setTimestamp();
    
    message.reply({ embeds: [embed] });
  }
};