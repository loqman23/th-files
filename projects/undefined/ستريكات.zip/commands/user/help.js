const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  data: {
    name: 'help',
    description: 'Shows all available commands'
  },
  async execute(message) {
    const prefix = config.prefix || '-';
    
    // Main help embed with welcome message
    const mainEmbed = new EmbedBuilder()
      .setColor(config.embedColor || '#0099ff')
      .setTitle('🌟 نظام الستريكات')
      .setDescription('**أهلا بك في أوامر نظام ستريكات!**\nنتمنى لك تجربة جميلة ورائعة مع نظام الستريكات الخاص بنا. استمتع بالمنافسة وحافظ على ستريك يومي للحصول على مكافآت مميزة!')
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .addFields(
        { name: '📊 كيف يعمل النظام؟', value: 'نظام الستريكات يكافئ النشاط اليومي المستمر. كلما حافظت على نشاطك، زاد ستريك الخاص بك وحصلت على مكافآت أفضل!' },
        { name: '🔍 استخدم الأزرار أدناه', value: 'اختر من الأزرار أدناه لعرض الأوامر المتاحة لك' }
      )
      .setFooter({ text: `استخدم ${prefix}streak للتحقق من ستريك الخاص بك • Streak Bot | Made with ❤️` })
      .setTimestamp();
    
    // Create buttons for user and admin commands
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('user_commands')
          .setLabel('🧑‍💻 أوامر المستخدمين')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('admin_commands')
          .setLabel('👑 أوامر الإدارة')
          .setStyle(ButtonStyle.Danger)
      );
    
    // Send the initial embed with buttons
    const response = await message.reply({
      embeds: [mainEmbed],
      components: [row]
    });
    
    // Create collector for button interactions
    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 300000 // 5 minutes
    });
    
    collector.on('collect', async interaction => {
      // Check if the user who clicked is the one who used the command
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({
          content: `هذه الأزرار ليست لك! استخدم الأمر \`${prefix}help\` للحصول على مساعدة خاصة بك.`,
          ephemeral: true
        });
      }
      
      let newEmbed;
      
      if (interaction.customId === 'user_commands') {
        // User commands embed
        newEmbed = new EmbedBuilder()
          .setColor('#3498db')
          .setTitle('🧑‍💻 أوامر المستخدمين')
          .setDescription('هذه الأوامر متاحة لجميع المستخدمين:')
          .addFields(
            { 
              name: `${prefix}streak`, 
              value: 'عرض الستريك الحالي الخاص بك والإحصائيات المتعلقة به' 
            },
            { 
              name: `${prefix}rank`, 
              value: 'التحقق من ترتيبك في قائمة المتصدرين وكم تبعد عن المركز الأعلى' 
            },
            { 
              name: `${prefix}streaktop`, 
              value: 'عرض أفضل 10 مستخدمين بأعلى ستريك في السيرفر' 
            },
            { 
              name: `${prefix}help`, 
              value: 'عرض هذه القائمة من الأوامر المتاحة' 
            }
          )
          .setFooter({ text: 'اضغط على زر أوامر الإدارة لرؤية الأوامر الإدارية' });
      } else {
        // Admin commands embed
        newEmbed = new EmbedBuilder()
          .setColor('#e74c3c')
          .setTitle('👑 أوامر الإدارة')
          .setDescription('هذه الأوامر متاحة فقط للمشرفين:')
          .addFields(
            { 
              name: `${prefix}resetstreak <user>`, 
              value: 'إعادة تعيين ستريك لمستخدم معين إلى الصفر' 
            },
            { 
              name: `${prefix}resetallstreaks`, 
              value: 'إعادة تعيين الستريك لجميع المستخدمين (استخدم بحذر!)' 
            },
            { 
              name: `${prefix}blacklist <user>`, 
              value: 'إضافة أو إزالة مستخدم من القائمة السوداء' 
            },
            { 
              name: `${prefix}remove-blacklist <user>`, 
              value: 'إزالة مستخدم من القائمة السوداء بشكل مباشر' 
            },
            { 
              name: `${prefix}streak-room [#channel]`, 
              value: 'تعيين قناة الستريك الرئيسية' 
            },
            { 
              name: `${prefix}streak-log-room [#channel]`, 
              value: 'تعيين قناة سجلات الستريك' 
            },
            { 
              name: `${prefix}streak-line <url>`, 
              value: 'تعيين صورة خط الستريك (رابط URL)' 
            },
            { 
              name: `${prefix}streak-info`, 
              value: 'إرسال لوحة معلومات نظام الستريك التفاعلية للمستخدمين' 
            }
          )
          .addFields({
            name: 'معلومات إضافية', 
            value: `• يمكن للمستخدمين إرسال منشور كل ${config.cooldownHours} ساعات\n` +
                  `• الحد اليومي هو ${config.dailyLimit} منشورات\n` +
                  `• قناة الستريك الحالية: <#${config.streakChannelId}>\n` +
                  `• للحفاظ على الستريك، يجب النشر يومياً`
          })
          .setFooter({ text: 'اضغط على زر أوامر المستخدمين للعودة' });
      }
      
      await interaction.update({ embeds: [newEmbed], components: [row] });
    });
    
    collector.on('end', () => {
      // Remove buttons after timeout
      const endEmbed = EmbedBuilder.from(response.embeds[0])
        .setFooter({ text: `انتهت صلاحية هذه اللوحة. استخدم \`${prefix}help\` مرة أخرى.` });
      
      response.edit({ embeds: [endEmbed], components: [] }).catch(console.error);
    });
  }
};