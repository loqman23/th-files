const { EmbedBuilder } = require('discord.js');
const { removeFromBlacklist, isBlacklisted } = require('../../utils/database');

module.exports = {
  data: {
    name: 'remove-blacklist',
    description: 'Remove a user from the blacklist'
  },
  execute(message, args) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('أنت لا تملك صلاحيات كافية لاستخدام هذا الأمر!');
    }
    
    if (!args.length) {
      return message.reply('الرجاء ذكر المستخدم الذي تريد إزالته من القائمة السوداء!');
    }
    
    const targetUser = message.mentions.users.first();
    
    if (!targetUser) {
      return message.reply('الرجاء ذكر مستخدم صالح!');
    }
    
    const isUserBlacklisted = isBlacklisted(targetUser.id);
    
    if (!isUserBlacklisted) {
      return message.reply(`**${targetUser.username}** ليس في القائمة السوداء!`);
    }
    
    // Remove from blacklist
    const result = removeFromBlacklist(targetUser.id);
    
    if (result) {
      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('✅ تم تحديث القائمة السوداء')
        .setDescription(`تمت إزالة **${targetUser.username}** من القائمة السوداء.`)
        .addFields(
          { name: 'المستخدم', value: `<@${targetUser.id}>`, inline: true },
          { name: 'بواسطة', value: `<@${message.author.id}>`, inline: true }
        )
        .setFooter({ text: `تم التنفيذ بواسطة ${message.author.username}` })
        .setTimestamp();
      
      message.reply({ embeds: [embed] });
      
      // Log the action if logUtils is available
      try {
        const { logCommandUsage } = require('../../utils/logUtils');
        logCommandUsage(message.client, message.author, 'remove-blacklist', [`<@${targetUser.id}>`]);
      } catch (error) {
        console.error('Could not log command usage:', error);
      }
    } else {
      message.reply('حدث خطأ أثناء تحديث القائمة السوداء.');
    }
  }
};