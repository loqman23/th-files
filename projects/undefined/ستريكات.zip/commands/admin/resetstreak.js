const { EmbedBuilder } = require('discord.js');
const { resetUserStreak } = require('../../utils/database');

module.exports = {
  data: {
    name: 'resetstreak',
    description: 'Reset streak for a specific user'
  },
  execute(message, args) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('You do not have permission to use this command!');
    }
    
    if (!args.length) {
      return message.reply('Please mention a user to reset their streak!');
    }
    
    const targetUser = message.mentions.users.first();
    
    if (!targetUser) {
      return message.reply('Please mention a valid user!');
    }
    
    resetUserStreak(targetUser.id);
    
    const embed = new EmbedBuilder()
      .setColor('#FF0000')
      .setTitle('🔄 Streak Reset')
      .setDescription(`Successfully reset streak for **${targetUser.username}**!`)
      .setFooter({ text: `Reset by ${message.author.username}` })
      .setTimestamp();
    
    message.reply({ embeds: [embed] });
  }
};