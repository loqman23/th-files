const { EmbedBuilder } = require('discord.js');
const { resetAllStreaks } = require('../../utils/database');

module.exports = {
  data: {
    name: 'resetallstreaks',
    description: 'Reset streaks for all users'
  },
  execute(message) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('You do not have permission to use this command!');
    }
    
    // Confirm action
    message.reply('Are you sure you want to reset ALL streaks? This action cannot be undone! Reply with `yes` to confirm or `no` to cancel.');
    
    const filter = m => m.author.id === message.author.id && (m.content.toLowerCase() === 'yes' || m.content.toLowerCase() === 'no');
    
    message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] })
      .then(collected => {
        const response = collected.first().content.toLowerCase();
        
        if (response === 'yes') {
          resetAllStreaks();
          
          const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔄 All Streaks Reset')
            .setDescription('Successfully reset streaks for all users!')
            .setFooter({ text: `Reset by ${message.author.username}` })
            .setTimestamp();
          
          message.reply({ embeds: [embed] });
        } else {
          message.reply('Action cancelled.');
        }
      })
      .catch(() => {
        message.reply('No response received, action cancelled.');
      });
  }
};