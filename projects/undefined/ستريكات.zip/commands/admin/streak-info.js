const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  data: {
    name: 'streak-info',
    description: 'Get information about the streak system'
  },
  async execute(message) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('أنت لا تملك صلاحيات كافية لاستخدام هذا الأمر! فقط المسؤولين يمكنهم إرسال لوحة المعلومات.');
    }
    
    // Create main embed with improved design
    const mainEmbed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(' نظام الستريكات المميز ')
      .setDescription('مرحباً بك في نظام الستريكات الخاص بنا! هنا يمكنك الحصول على جميع المعلومات التي تحتاجها للمشاركة والمنافسة.\n\nاختر أحد الخيارات أدناه للحصول على معلومات تفصيلية:')
      .addFields(
        { name: '📊 إحصائيات السيرفر', value: 'عدد المشاركين النشطين: يتم التحديث يومياً\nأعلى ستريك حالي: يتم تحديثه تلقائياً' },
        { name: '💡 نصيحة اليوم', value: 'حافظ على نشر محتوى يومي للحفاظ على ستريك قوي والحصول على مكافآت أفضل!' }
      )
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setFooter({ text: `استخدم ${config.prefix}streak للتحقق من ستريك الخاص بك • Streak Bot | Made with ❤️` });
    
    // Create buttons with improved labels
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('rules')
          .setLabel('📜 قوانين النظام')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('rewards')
          .setLabel('🎁 المكافآت والجوائز')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('top')
          .setLabel('🏆 قائمة المتصدرين')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('howto')
          .setLabel('❓ كيف اسوي ستريك')
          .setStyle(ButtonStyle.Danger)
      );
    
    try {
      const response = await message.reply({
        embeds: [mainEmbed],
        components: [row]
      });
      
      // Create collector for button interactions
      const collector = response.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 300000 // 5 minutes
      });
      
      collector.on('collect', async interaction => {
        try {
          // Check if the user who clicked is the one who used the command
          if (interaction.user.id !== message.author.id) {
            return await interaction.reply({
              content: `هذه الأزرار ليست لك! استخدم الأمر \`${config.prefix}streak-info\` للحصول على لوحة خاصة بك.`,
              ephemeral: true
            });
          }
          
          let newEmbed;
          
          switch (interaction.customId) {
            case 'rules':
              newEmbed = new EmbedBuilder()
                .setColor('#4B0082')
                .setTitle('📜 قوانين نظام الستريكات')
                .setDescription('يجب اتباع هذه القوانين للحفاظ على ستريك صالح والمشاركة بشكل فعال:')
                .addFields(
                  { name: '1. المحتوى المناسب ✅', value: 'يجب أن تكون الصور والفيديوهات مناسبة وتتبع قوانين السيرفر. أي محتوى مخالف سيؤدي إلى فقدان الستريك.' },
                  { name: '2. الالتزام بالوقت ⏱️', value: `يمكنك إرسال منشور كل ${config.cooldownHours} ساعات فقط. المنشورات المتكررة قبل انتهاء الوقت لن تحتسب.` },
                  { name: '3. الحد اليومي 📅', value: `يمكنك إرسال ${config.dailyLimit} منشورات كحد أقصى في اليوم. استغل هذه الفرص بحكمة!` },
                  { name: '4. الاستمرارية 🔄', value: 'يجب الحفاظ على النشر يومياً للحفاظ على الستريك. إذا فاتك يوم، سيتم إعادة ستريك الخاص بك إلى 0.' },
                  { name: '5. المنافسة الشريفة 🤝', value: 'احترم المشاركين الآخرين وتجنب أي محاولات للتحايل على النظام.' }
                )
                .setFooter({ text: 'تم التحديث: ' + new Date().toLocaleDateString('ar-SA') });
              
              // Send as a new message that only the user can see
              await interaction.reply({ embeds: [newEmbed], ephemeral: true });
              break;
              
            case 'rewards':
              newEmbed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle('🎁 جوائز ومكافآت الستريكات')
                .setDescription('كلما زاد ستريك الخاص بك، كلما حصلت على مكافآت أفضل! إليك ما يمكنك الحصول عليه:')
                .addFields(
                  { name: '🥉 7 أيام ستريك', value: '• رتبة مميزة في السيرفر\n• شارة خاصة بجانب اسمك\n• إمكانية استخدام قنوات خاصة' },
                  { name: '🥈 14 يوم ستريك', value: '• رموز تعبيرية خاصة\n• 1000 نقطة في نظام النقاط\n• إمكانية تغيير لون اسمك' },
                  { name: '🥇 30 يوم ستريك', value: '• قناة خاصة بك\n• 5000 نقطة في نظام النقاط\n• صلاحيات إضافية في السيرفر' },
                  { name: '👑 60 يوم ستريك', value: '• لقب مخصص\n• 10000 نقطة في نظام النقاط\n• ميزات حصرية في السيرفر' },
                  { name: '💎 100 يوم ستريك', value: '• جائزة كبرى (يتم الإعلان عنها)\n• مكانة خاصة في قاعة المشاهير\n• مفاجآت إضافية!' }
                )
                .setFooter({ text: 'استمر في الحفاظ على ستريك للحصول على هذه المكافآت الرائعة!' });
              
              // Send as a new message that only the user can see
              await interaction.reply({ embeds: [newEmbed], ephemeral: true });
              break;
              
            case 'top':
              try {
                const { getTopStreaks } = require('../../utils/database');
                const topUsers = getTopStreaks(5);
                
                let description = '🏆 **قائمة المتصدرين في الستريكات** 🏆\n\n';
                
                if (topUsers.length === 0) {
                  description = 'لا توجد بيانات ستريك متاحة بعد! كن أول من يبدأ ستريك وتصدر القائمة.';
                } else {
                  for (let i = 0; i < topUsers.length; i++) {
                    const user = topUsers[i];
                    try {
                      const discordUser = message.client.users.cache.get(user.userId);
                      const username = discordUser ? discordUser.username : 'مستخدم غير معروف';
                      
                      // Add emoji based on position
                      let positionEmoji = '';
                      if (i === 0) positionEmoji = '🥇';
                      else if (i === 1) positionEmoji = '🥈';
                      else if (i === 2) positionEmoji = '🥉';
                      else positionEmoji = `${i + 1}.`;
                      
                      description += `${positionEmoji} **${username}** - **${user.streak}** يوم ستريك\n`;
                    } catch (error) {
                      console.error(`Error getting user ${user.userId}:`, error);
                      description += `${i + 1}. مستخدم غير معروف - **${user.streak}** يوم ستريك\n`;
                    }
                  }
                  
                  // Add motivational message
                  description += '\n💪 هل يمكنك الوصول إلى القمة؟ حافظ على ستريك يومي للمنافسة!';
                }
                
                newEmbed = new EmbedBuilder()
                  .setColor('#9932CC')
                  .setTitle('🏆 قائمة المتصدرين في الستريكات')
                  .setDescription(description)
                  .setFooter({ text: 'يتم تحديث القائمة تلقائياً • استخدم ' + config.prefix + 'streak للتحقق من ترتيبك' });
                
                // Send as a new message that only the user can see
                await interaction.reply({ embeds: [newEmbed], ephemeral: true });
              } catch (error) {
                console.error('Error in top button:', error);
                newEmbed = new EmbedBuilder()
                  .setColor('#FF0000')
                  .setTitle('❌ خطأ')
                  .setDescription('حدث خطأ أثناء جلب بيانات المتصدرين. الرجاء المحاولة مرة أخرى.');
                
                await interaction.reply({ embeds: [newEmbed], ephemeral: true });
              }
              break;
              
            case 'howto':
              newEmbed = new EmbedBuilder()
                .setColor('#1E90FF')
                .setTitle('❓ كيفية المشاركة في نظام الستريكات')
                .setDescription('المشاركة سهلة وممتعة! اتبع هذه الخطوات البسيطة للبدء:')
                .addFields(
                  { name: '1️⃣ اذهب إلى القناة المخصصة للستريك', value: `توجه إلى القناة <#${config.streakChannelId}> المخصصة للستريكات. هذه هي القناة الوحيدة التي يتم احتساب المنشورات فيها.` },
                  { name: '2️⃣ أرسل صورة أو فيديو', value: 'قم بإرسال صورة أو فيديو أو أي محتوى مناسب. تأكد من أن المحتوى يتبع قوانين السيرفر.' },
                  { name: '3️⃣ التزم بالجدول الزمني', value: `يمكنك إرسال منشورات كل ${config.cooldownHours} ساعات (بحد أقصى ${config.dailyLimit} مرات في اليوم). خطط لوقتك بحكمة!` },
                  { name: '4️⃣ تحقق من ستريك', value: `استخدم الأمر \`${config.prefix}streak\` في أي وقت لمعرفة حالة الستريك الخاص بك والإحصائيات المتعلقة به.` },
                  { name: '5️⃣ استمر يومياً', value: 'للحفاظ على ستريك قوي، تأكد من النشر مرة واحدة على الأقل كل يوم. الاستمرارية هي المفتاح!' }
                )
                .setFooter({ text: 'سيتم تحديث الستريك لديك تلقائياً عند النشر • استمتع بالمشاركة!' });
              
              // Send as a new message that only the user can see
              await interaction.reply({ embeds: [newEmbed], ephemeral: true });
              break;
          }
        } catch (error) {
          console.error('Error handling button interaction:', error);
          try {
            await interaction.reply({ 
              content: 'حدث خطأ أثناء معالجة الزر. الرجاء المحاولة مرة أخرى.', 
              ephemeral: true 
            });
          } catch (replyError) {
            console.error('Error replying to interaction:', replyError);
          }
        }
      });
      
      collector.on('end', () => {
        try {
          // Remove buttons after timeout
          const endEmbed = EmbedBuilder.from(mainEmbed)
            .setFooter({ text: `انتهت صلاحية هذه اللوحة. استخدم \`${config.prefix}streak-info\` مرة أخرى.` });
          
          response.edit({ embeds: [endEmbed], components: [] }).catch(err => {
            console.error('Error editing message after collector end:', err);
          });
        } catch (error) {
          console.error('Error in collector end event:', error);
        }
      });
    } catch (error) {
      console.error('Error in streak-info command:', error);
      message.reply('حدث خطأ أثناء تنفيذ الأمر. الرجاء المحاولة مرة أخرى.').catch(console.error);
    }
  }
};