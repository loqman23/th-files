const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: {
    name: 'streak-line',
    description: 'Set the streak line image'
  },
  execute(message, args) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('أنت لا تملك صلاحيات كافية لاستخدام هذا الأمر!');
    }
    
    if (!args.length) {
      return message.reply('الرجاء إدخال رابط صورة الخط! مثال: `-streak-line https://example.com/line.png`');
    }
    
    const lineUrl = args[0];
    
    // Validate URL (basic check)
    if (!lineUrl.startsWith('http')) {
      return message.reply('الرجاء إدخال رابط صالح يبدأ بـ http:// أو https://');
    }
    
    // Update config file
    const configPath = path.join(__dirname, '../../config.json');
    let config;
    
    try {
      config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      config.lineEmoji = lineUrl;
      
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
      
      const embed = new EmbedBuilder()
        .setColor(config.embedColor || '#0099ff')
        .setTitle('✅ تم تحديث خط الستريك')
        .setDescription('تم تعيين صورة خط الستريك الجديدة بنجاح!')
        .setImage(lineUrl)
        .setFooter({ text: `تم التعديل بواسطة ${message.author.username}` })
        .setTimestamp();
      
      message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Error updating config:', error);
      message.reply('حدث خطأ أثناء تحديث الإعدادات. الرجاء المحاولة مرة أخرى.');
    }
  }
};