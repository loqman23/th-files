const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: {
    name: 'streak-log-room',
    description: 'Set the streak log channel'
  },
  execute(message, args) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('أنت لا تملك صلاحيات كافية لاستخدام هذا الأمر!');
    }
    
    // Get the mentioned channel or use the current channel
    const channel = message.mentions.channels.first() || message.channel;
    
    // Update config file
    const configPath = path.join(__dirname, '../../config.json');
    let config;
    
    try {
      config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      config.logChannelId = channel.id;
      
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
      
      const embed = new EmbedBuilder()
        .setColor(config.embedColor || '#0099ff')
        .setTitle('✅ تم تحديث إعدادات السجلات')
        .setDescription(`تم تعيين قناة سجلات الستريك إلى <#${channel.id}>`)
        .setFooter({ text: `تم التعديل بواسطة ${message.author.username}` })
        .setTimestamp();
      
      message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Error updating config:', error);
      message.reply('حدث خطأ أثناء تحديث الإعدادات. الرجاء المحاولة مرة أخرى.');
    }
  }
};