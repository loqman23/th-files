const { EmbedBuilder } = require('discord.js');
const { addToBlacklist, removeFromBlacklist, isBlacklisted } = require('../../utils/database');

module.exports = {
  data: {
    name: 'blacklist',
    description: 'Add/remove a user from the blacklist'
  },
  execute(message, args) {
    // Check if user has admin permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('You do not have permission to use this command!');
    }
    
    if (!args.length) {
      return message.reply('Please mention a user to add/remove from the blacklist!');
    }
    
    const targetUser = message.mentions.users.first();
    
    if (!targetUser) {
      return message.reply('Please mention a valid user!');
    }
    
    const isUserBlacklisted = isBlacklisted(targetUser.id);
    let result;
    
    if (isUserBlacklisted) {
      // Remove from blacklist
      result = removeFromBlacklist(targetUser.id);
      
      if (result) {
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Blacklist Updated')
          .setDescription(`**${targetUser.username}** has been removed from the blacklist.`)
          .setFooter({ text: `Action by ${message.author.username}` })
          .setTimestamp();
        
        message.reply({ embeds: [embed] });
      } else {
        message.reply('An error occurred while updating the blacklist.');
      }
    } else {
      // Add to blacklist
      result = addToBlacklist(targetUser.id);
      
      if (result) {
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('⛔ Blacklist Updated')
          .setDescription(`**${targetUser.username}** has been added to the blacklist.`)
          .setFooter({ text: `Action by ${message.author.username}` })
          .setTimestamp();
        
        message.reply({ embeds: [embed] });
      } else {
        message.reply('An error occurred while updating the blacklist.');
      }
    }
  }
};