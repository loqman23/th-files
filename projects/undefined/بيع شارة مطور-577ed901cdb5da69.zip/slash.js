const { Client, Intents } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const fs = require('fs');

// Function to register slash commands
async function registerCommands(client, token) {
    const commands = [
        {
            name: 'get-badge',
            description: 'to get active developer badge'
        },
    ];

    const rest = new REST({ version: '9' }).setToken(token);

    try {
        console.log('Started refreshing application (/) commands for token:', token);
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands for token:', token);
    } catch (error) {
        console.error('Failed to refresh commands for token:', token, error);
    }
}

// Function to handle interactions
function handleInteractions(client) {
    client.on('interactionCreate', async interaction => {
        if (!interaction.isCommand()) return;

        if (interaction.commandName === 'get-badge') {
            try {
                await interaction.reply({ content: '**تـم. الرجاء قم بالإنتظار مدة 24 ساعه ثم قم بزيارة هذا الموقع و مبروك عليك الشارة https://discord.com/developers/active-developer**', ephemeral: true });
            } catch (error) {
                console.error('Failed to reply to interaction:', error);
            }
        }
    });
}

// Read tokens from accounts.json
try {
    let accountsData = fs.readFileSync('accounts.json');
    let accounts = JSON.parse(accountsData);

    // Create a client for each token and register commands
    accounts.forEach(account => {
        const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
        const token = account.botToken;

        client.once('ready', async () => {
            console.log(`Bot started with name ${client.user.tag}.`);
            try {
                await registerCommands(client, token); // Register new commands
                handleInteractions(client);
            } catch (error) {
                console.error(`Error registering commands for token ${token}:`, error);
            }
        });

        client.login(token).catch(error => {
            console.error(`Error logging in with token ${token}:`, error);
            accounts = accounts.filter(acc => acc.botToken !== token); // Remove the invalid token from accounts
            fs.writeFileSync('accounts.json', JSON.stringify(accounts, null, 2)); // Update accounts.json
        });
    });
} catch (error) {
    console.error('Error reading accounts.json:', error);
}
