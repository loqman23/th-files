
![Logo](https://webimages.mongodb.com/_com_assets/cms/kuzt9r42or1fxvlq2-Meta_Generic.png)

# Mongo-Gen-v14
Made By Ghost Planet
## Features

- Generate MongoDB
- 24/7 with free

## Running Tests

To run tests, run the following command

```bash
  npm install
```
```bash
  node index.js
```
## Support

For support, Join our [Discord Server](https://discord.gg/h24pNkrGBk).


## Credits

Credits Goes to **Im Prince** & **Luna**

