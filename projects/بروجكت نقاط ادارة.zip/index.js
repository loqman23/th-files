const { Client, GatewayIntentBits } = require('discord.js');
const mongoose = require('mongoose');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers] });

//لا تنسى تحمل المكتبه mongoose و diecord.js
// توكن البوت اخر سطر
//اوامر .p .addp .removep .resetp .topp
//.pd اطفاء اوامر 
//.pt تشغيل اوامر




const ceo = "الرتبة الي تقدر تتحكم في النقاط";
const support = "رتبة الدعم الفني";

let mode = true;

//رابط المونقو
mongoose.connect('mongodb://localhost:27017/discord-points', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const pointsSchema = new mongoose.Schema({
  userId: { type: String, required: true, unique: true },
  points: { type: Number, default: 0 },
});

const Points = mongoose.model('Points', pointsSchema);

async function getPoints(userId) {
  let user = await Points.findOne({ userId });
  if (!user) {
    user = new Points({ userId, points: 0 });
    await user.save();
  }
  return user;
}

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;

  const args = message.content.split(" ");
  const command = args[0].toLowerCase();

  if (!mode) return;

  if (!message.member.roles.cache.has(support) && !message.member.roles.cache.has(ceo)) return;

  if (command === '.p') {
    const targetUser = message.mentions.members.first() || message.member;
    const userData = await getPoints(targetUser.id);
    return message.reply(`${targetUser.toString()} : **${userData.points}**`);
  }

  if (command === '.addp') {
    if (!message.member.roles.cache.has(ceo)) return;
    const targetUser = message.mentions.members.first();
    const pointsamount = parseInt(args[2]);

    if (!targetUser) return message.reply("❌");
    if (!targetUser.roles.cache.has(support)) return message.reply("❌");
    if (isNaN(pointsamount)) return message.reply("❌");

    const userData = await getPoints(targetUser.id);
    userData.points += pointsamount;
    await userData.save();

    return message.reply(`✅ ${pointsamount} -> ${targetUser.user.username}`);
  }

  if (command === '.removep') {
    if (!message.member.roles.cache.has(ceo)) return;
    const targetUser = message.mentions.members.first();
    const pointsamount = parseInt(args[2]);

    if (!targetUser) return message.reply("❌");
    if (!targetUser.roles.cache.has(support)) return message.reply("❌");
    if (isNaN(pointsamount)) return message.reply("❌");

    const userData = await getPoints(targetUser.id);
    userData.points = Math.max(0, userData.points - pointsamount);
    await userData.save();

    return message.reply(`✅ -${pointsamount} -> ${targetUser.user.username}`);
  }

  if (command === '.resetp') {
    if (!message.member.roles.cache.has(ceo)) return;

    if (args[1] === "All") {
      await Points.deleteMany({});
      return message.reply("✅");
    }

    const targetUser = message.mentions.members.first();
    if (!targetUser) return message.reply("❌");
    if (!targetUser.roles.cache.has(support)) return message.reply("❌");

    const userData = await getPoints(targetUser.id);
    userData.points = 0;
    await userData.save();

    return message.reply(`✅ ${targetUser.user.username}`);
  }

  if (command === '.topp') {
    const topUsers = await Points.find().sort({ points: -1 }).limit(10);
    if (topUsers.length === 0) return message.reply("لا يوجد بيانات");

    const topList = await Promise.all(
      topUsers.map(async (user, index) => {
        try {
          const member = await message.guild.members.fetch(user.userId);
          return `#${index + 1} - ${member.user.username}: **${user.points}**`;
        } catch {
          return `#${index + 1} - مستخدم غير معروف: **${user.points}**`;
        }
      })
    );

    return message.reply(`**TOP 10:**\n${topList.join("\n")}`);
  }

  if (command === '.pd') {
    if (!message.member.roles.cache.has(ceo)) return;
    mode = false;
    return message.reply("OFF");
  }

  if (command === '.pt') {
    if (!message.member.roles.cache.has(ceo)) return;
    mode = true;
    return message.reply("ON");
  }
});

client.login("توكنك");